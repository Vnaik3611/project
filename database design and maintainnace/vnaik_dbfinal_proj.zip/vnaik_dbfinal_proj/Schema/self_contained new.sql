-- MySQL dump 10.13  Distrib 5.7.17, for Win64 (x86_64)
--
-- Host: localhost    Database: music_store
-- ------------------------------------------------------
-- Server version	8.0.11

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `addresses`
--

DROP TABLE IF EXISTS `addresses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `addresses` (
  `address_id` int(11) NOT NULL,
  `city` varchar(45) NOT NULL,
  `state` varchar(45) NOT NULL,
  `zip_code` varchar(45) NOT NULL,
  `phone` varchar(45) DEFAULT NULL,
  `Customers_customer_id` int(11) NOT NULL,
  PRIMARY KEY (`address_id`),
  KEY `fk_addresses_Customers1_idx` (`Customers_customer_id`),
  CONSTRAINT `fk_addresses_Customers1` FOREIGN KEY (`Customers_customer_id`) REFERENCES `customers` (`customer_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `addresses`
--

LOCK TABLES `addresses` WRITE;
/*!40000 ALTER TABLE `addresses` DISABLE KEYS */;
INSERT INTO `addresses` VALUES (1,'Kitchener','ON','N2C2P6','12334455',1),(2,'Kitchener','ON','N4G6U6','64456547',2),(3,'Waterloo','BJ','N6H8F9','7568645',3),(4,'Cambridge','ON','N8D9H6','56756784',4),(5,'London','ON','N95H3F','678679848',5);
/*!40000 ALTER TABLE `addresses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `artists`
--

DROP TABLE IF EXISTS `artists`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `artists` (
  `artist_id` int(11) NOT NULL,
  `first_name` varchar(45) NOT NULL,
  `last_name` varchar(45) NOT NULL,
  `email` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`artist_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `artists`
--

LOCK TABLES `artists` WRITE;
/*!40000 ALTER TABLE `artists` DISABLE KEYS */;
INSERT INTO `artists` VALUES (1,'johnny','depp','abc@gmail.com'),(2,'AI','pacino','ai@gmail.com'),(3,'Kevin','specy','kev@gmail.com'),(4,'Russell','crwoe','rus@gmail.com'),(5,'Brad','pitt','brad@gmail.com'),(6,'Angelina','jolie','ang@gmail.com');
/*!40000 ALTER TABLE `artists` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `categories` (
  `category_id` int(11) NOT NULL,
  `category_name` varchar(45) NOT NULL,
  PRIMARY KEY (`category_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categories`
--

LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
INSERT INTO `categories` VALUES (1,'Rock'),(2,'Pop'),(3,'Jazz'),(4,'Folk'),(5,'Hip hop');
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customers`
--

DROP TABLE IF EXISTS `customers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `customers` (
  `customer_id` int(11) NOT NULL,
  `first_name` varchar(45) NOT NULL,
  `last_name` varchar(45) NOT NULL,
  `email` varchar(45) DEFAULT NULL,
  `date_of_birth` datetime NOT NULL,
  `shipping_address_id` int(11) NOT NULL,
  `billing_address_id` int(11) NOT NULL,
  PRIMARY KEY (`customer_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customers`
--

LOCK TABLES `customers` WRITE;
/*!40000 ALTER TABLE `customers` DISABLE KEYS */;
INSERT INTO `customers` VALUES (1,'John','Tremblay','john@gmail.com','1994-09-22 00:00:00',1,1),(2,'Kelly','Gagnon','kelgmail.com','1998-11-22 00:00:00',2,2),(3,'Mittal','Roy','mit@gmail.com','1995-05-11 00:00:00',3,3),(4,'Honey','Gauthier','hon@gmail.com','1993-12-15 00:00:00',4,4),(5,'Naresh','Morin','naresh@gmail.com','2000-11-08 00:00:00',5,5),(6,'Ally','Lavoie','al@gmail.com','1992-11-21 00:00:00',6,6),(7,'johnn','Fortin','john@gmail.com','1996-02-01 00:00:00',7,7),(8,'Piyu','Mora','piyu@gmail.com','1998-09-08 00:00:00',8,8),(9,'Melani','Rodríguez','mel@gmail.com','1992-03-02 00:00:00',9,9),(10,'Jelly','Morales','jel@gmail.com','2000-09-08 00:00:00',10,10);
/*!40000 ALTER TABLE `customers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `employees`
--

DROP TABLE IF EXISTS `employees`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `employees` (
  `employee_id` int(11) NOT NULL,
  `first_name` varchar(45) NOT NULL,
  `last_name` varchar(45) NOT NULL,
  `email` varchar(45) DEFAULT NULL,
  `join_of_birth` datetime NOT NULL,
  PRIMARY KEY (`employee_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `employees`
--

LOCK TABLES `employees` WRITE;
/*!40000 ALTER TABLE `employees` DISABLE KEYS */;
/*!40000 ALTER TABLE `employees` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `order_items`
--

DROP TABLE IF EXISTS `order_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `order_items` (
  `item_id` int(11) NOT NULL,
  `price` decimal(10,0) NOT NULL,
  `quantity` int(11) NOT NULL,
  `products_product_id` int(11) NOT NULL,
  `Orders_order_id` int(11) NOT NULL,
  PRIMARY KEY (`item_id`),
  KEY `fk_order_items_products1_idx` (`products_product_id`),
  KEY `fk_order_items_Orders1_idx` (`Orders_order_id`),
  CONSTRAINT `fk_order_items_Orders1` FOREIGN KEY (`Orders_order_id`) REFERENCES `orders` (`order_id`),
  CONSTRAINT `fk_order_items_products1` FOREIGN KEY (`products_product_id`) REFERENCES `products` (`product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `order_items`
--

LOCK TABLES `order_items` WRITE;
/*!40000 ALTER TABLE `order_items` DISABLE KEYS */;
INSERT INTO `order_items` VALUES (1,34,5,1,1),(2,67,4,5,3),(3,22,1,5,2),(4,22,3,6,2),(5,11,5,7,2);
/*!40000 ALTER TABLE `order_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `orders`
--

DROP TABLE IF EXISTS `orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `orders` (
  `order_id` int(11) NOT NULL,
  `order_date` datetime NOT NULL,
  `ship_amount` double NOT NULL,
  `ship_date` datetime NOT NULL,
  `ship_address_id` int(11) NOT NULL,
  `payment_mode` varchar(45) NOT NULL,
  `card_number` varchar(45) NOT NULL,
  `billing_address_id` int(11) NOT NULL,
  `Customers_customer_id` int(11) NOT NULL,
  PRIMARY KEY (`order_id`),
  KEY `fk_Orders_Customers_idx` (`Customers_customer_id`),
  CONSTRAINT `fk_Orders_Customers` FOREIGN KEY (`Customers_customer_id`) REFERENCES `customers` (`customer_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `orders`
--

LOCK TABLES `orders` WRITE;
/*!40000 ALTER TABLE `orders` DISABLE KEYS */;
INSERT INTO `orders` VALUES (1,'2019-03-23 00:00:00',12,'2019-09-27 00:00:00',1,'debit','21434235',1,1),(2,'2018-08-06 00:00:00',23,'2018-08-22 00:00:00',2,'visa','12334235',2,2),(3,'2018-04-08 00:00:00',11,'2018-12-29 00:00:00',3,'visa','23456778',3,3),(4,'2019-04-01 00:00:00',34,'2019-01-12 00:00:00',4,'debit','56747568',4,1),(5,'2019-03-28 00:00:00',22,'2019-03-19 00:00:00',5,'visa','78678435',5,1),(6,'2019-03-22 00:00:00',10,'2017-05-28 00:00:00',6,'visa','23543567',6,1),(7,'2018-04-01 00:00:00',23,'2018-04-07 00:00:00',7,'visa','24235345',7,3),(8,'2018-04-03 00:00:00',22,'2018-04-08 00:00:00',8,'visa','23425425',8,2),(9,'2018-04-07 00:00:00',55,'2018-04-10 00:00:00',9,'debit','65746457',9,5);
/*!40000 ALTER TABLE `orders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `products`
--

DROP TABLE IF EXISTS `products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `products` (
  `product_id` int(11) NOT NULL,
  `product_name` varchar(45) NOT NULL,
  `description` varchar(45) DEFAULT NULL,
  `price` decimal(10,0) NOT NULL,
  `date_added` datetime NOT NULL,
  `categories_category_id` int(11) NOT NULL,
  `Artists_artist_id` int(11) NOT NULL,
  `quantity` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`product_id`),
  KEY `fk_products_categories1_idx` (`categories_category_id`),
  KEY `fk_products_Artists1_idx` (`Artists_artist_id`),
  CONSTRAINT `fk_products_Artists1` FOREIGN KEY (`Artists_artist_id`) REFERENCES `artists` (`artist_id`),
  CONSTRAINT `fk_products_categories1` FOREIGN KEY (`categories_category_id`) REFERENCES `categories` (`category_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `products`
--

LOCK TABLES `products` WRITE;
/*!40000 ALTER TABLE `products` DISABLE KEYS */;
INSERT INTO `products` VALUES (1,'Titanic rising','sdgfdsg fhdsfh',22,'2018-05-12 00:00:00',1,1,'10'),(2,'Stevie wondor','asds dfbgd dfgsd',11,'1996-09-11 00:00:00',2,2,'15'),(3,'They might be giants','sa sdgds gfhdfh',56,'1994-01-22 00:00:00',3,1,'20'),(4,'Unbroken','Xscdf sd fhgh',22,'2000-07-23 00:00:00',3,1,'25'),(5,'Crooked shadows','aas sdvf bhfg fdsfh',33,'2018-05-11 00:00:00',1,3,'5'),(6,'By the way, i forgive you','awe erh fsdg',33,'2018-05-15 00:00:00',3,1,'14'),(7,'I am human','awe cgnhfg vrtyr',78,'2018-05-13 00:00:00',3,1,'20'),(8,'Pop evil','jjthr reeg gjgj',45,'1995-04-22 00:00:00',4,4,'5');
/*!40000 ALTER TABLE `products` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rentals`
--

DROP TABLE IF EXISTS `rentals`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `rentals` (
  `rental_id` int(11) NOT NULL,
  `rental_date` datetime NOT NULL,
  `return_date` datetime DEFAULT NULL,
  `Customers_customer_id` int(11) NOT NULL,
  `products_product_id` int(11) NOT NULL,
  PRIMARY KEY (`rental_id`),
  KEY `fk_Rentals_Customers1_idx` (`Customers_customer_id`),
  KEY `fk_Rentals_products1_idx` (`products_product_id`),
  CONSTRAINT `fk_Rentals_Customers1` FOREIGN KEY (`Customers_customer_id`) REFERENCES `customers` (`customer_id`),
  CONSTRAINT `fk_Rentals_products1` FOREIGN KEY (`products_product_id`) REFERENCES `products` (`product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rentals`
--

LOCK TABLES `rentals` WRITE;
/*!40000 ALTER TABLE `rentals` DISABLE KEYS */;
INSERT INTO `rentals` VALUES (1,'2019-04-12 00:00:00',NULL,1,2),(2,'2019-04-11 00:00:00','2019-04-12 00:00:00',2,4);
/*!40000 ALTER TABLE `rentals` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `returns`
--

DROP TABLE IF EXISTS `returns`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `returns` (
  `return_id` int(11) NOT NULL,
  `Customers_customer_id` int(11) NOT NULL,
  `products_product_id` int(11) NOT NULL,
  `return_date` datetime NOT NULL,
  PRIMARY KEY (`return_id`),
  KEY `fk_Returns_Customers1` (`Customers_customer_id`),
  KEY `fk_Returns_products1` (`products_product_id`),
  CONSTRAINT `fk_Returns_Customers1` FOREIGN KEY (`Customers_customer_id`) REFERENCES `customers` (`customer_id`),
  CONSTRAINT `fk_Returns_products1` FOREIGN KEY (`products_product_id`) REFERENCES `products` (`product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `returns`
--

LOCK TABLES `returns` WRITE;
/*!40000 ALTER TABLE `returns` DISABLE KEYS */;
/*!40000 ALTER TABLE `returns` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-04-15 13:17:10
