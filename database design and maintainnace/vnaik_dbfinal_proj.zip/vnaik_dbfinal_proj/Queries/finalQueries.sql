/* query 1 */
select count(customer_id) as NoOfCustomers from customers;

/* query 2 */

select product_name, sum(oi.quantity) as TopSoldProduct  from order_items oi
join orders o on
oi.Orders_order_id = o.order_id
join products p on oi.products_product_id=p.product_id
where o.order_date<=now() and o.order_date>date_add(now(),INTERVAL -30 DAY)
group by product_id
order by TopSoldProduct DESC
limit 1;

-- Least Sold

select  product_name, sum(oi.quantity) as LeastSoldProduct  from order_items oi
join orders o on
oi.Orders_order_id = o.order_id
join products p on oi.products_product_id=p.product_id
where o.order_date<=now() and o.order_date>date_add(now(),INTERVAL -30 DAY)
group by product_id
order by LeastSoldProduct ASC
limit 1;

/* query 3*/
 select  category_name, category_id, avg(price) as AveragePriceOfProduct from categories c 
 join products p on c.category_id = p.categories_category_id
 group by category_name;
 
/* query 4 */
select last_name, date_of_birth from customers
order by last_name,date_of_birth ASC;

/* query 5 */
select  concat(first_name,' ',last_name) as Customer_name ,sum(quantity) as PurchasedItems from order_items oi
join orders o on oi.orders_order_id = o.order_id
join customers c on c.customer_id = o.customers_customer_id
where o.order_date between date_add(now(), interval -30 day) and now()
group by customer_id
having PurchasedItems >=4;

 /* query 6*/
 select distinct count(product_name), concat(first_name ,' ',last_name) as Artist_name from artists a
 join products p on a.artist_id = p.artists_artist_id
 group by artist_id;
 
 /* query 7 */
 select distinct artist_id, concat(first_name , ' ', last_name) as artist_name, sum(product_id) from products p
 join artists a on  p.artists_artist_id=a.artist_id 
 group by artist_id;



/* self-query 1 */
select product_name, product_id, description, date_added from products
where date_added < DATE_SUB(NOW(),INTERVAL 23 YEAR);

/* self-query 2 */
select  customer_id, concat(first_name, ' ', last_name) as customer_name, payment_mode from orders o
join customers c on o.customers_customer_id = c.customer_id
where order_id = 6;

/* self-query 3  it will only display available products*/

select product_name,price 
from products
where product_id NOT IN 
						(select products_product_id 
                        from rentals 
                        where return_date IS NULL);
                        
/* self-query4 */
DELIMITER //
CREATE TRIGGER rentals_before_update 
	BEFORE UPDATE ON rentals 
	FOR EACH ROW 
BEGIN 
	IF NEW.return_date IS NOT NULL THEN
		IF NEW.return_date<NEW.rental_date THEN
			SIGNAL SQLSTATE 'HY000'
            SET MESSAGE_TEXT='return date can not be less than rental date';
		END IF;
	END IF;
    
END//

CREATE TRIGGER rentals_before_insert 
	BEFORE INSERT ON rentals 
	FOR EACH ROW 
BEGIN 
	IF NEW.return_date IS NOT NULL THEN
		IF NEW.return_date<NEW.rental_date THEN
			SIGNAL SQLSTATE 'HY000'
            SET MESSAGE_TEXT='return date can not be less than rental date';
		END IF;
	END IF;
    
END//

DELIMITER ;

SHOW TRIGGERS;