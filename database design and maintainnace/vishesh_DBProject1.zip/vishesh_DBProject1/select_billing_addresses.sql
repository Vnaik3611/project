SELECT firstName, lastName, line1, line2, city, state, zipCode 
FROM customers 
JOIN addresses  ON 
customers.billingAddressID = addresses.addressID 
WHERE customers.lastName = "Brown"; 