SELECT productName, description, listPrice 
FROM products 
WHERE description LIKE '%solid%' 
ORDER BY listPrice ASC;  