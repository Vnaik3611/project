SELECT customers.customerID, firstName, lastName 
FROM customers 
LEFT JOIN orders
ON customers.customerID = orders.customerID 
WHERE orders.customerID IS NULL; 