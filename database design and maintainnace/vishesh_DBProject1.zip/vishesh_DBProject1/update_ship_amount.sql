UPDATE orders SET shipAmount = 0 
WHERE customerID IN 
(
    SELECT customerID 
	FROM customers
	WHERE lastName = 'Sherwood' 
)