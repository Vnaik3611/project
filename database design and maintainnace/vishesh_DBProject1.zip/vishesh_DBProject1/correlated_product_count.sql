SELECT p.categoryID,  
(SELECT categoryName FROM categories WHERE categoryID = p.categoryID) AS categoryName, 
COUNT(p.categoryID) AS productCount
FROM products p 
GROUP BY categoryName 
ORDER BY categoryID 