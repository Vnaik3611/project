INSERT INTO categories VALUES 
(4, "Keyboards"), 
(5, "Brass"), 
(6, "Woodwind");