SELECT COUNT(*) AS ProductCount
FROM products 
WHERE categoryID = 
( 
    SELECT categoryID FROM categories
    WHERE categoryName = "Guitars"
)