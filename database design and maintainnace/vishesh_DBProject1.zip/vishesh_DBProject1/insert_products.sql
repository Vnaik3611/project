INSERT INTO `products`
(`categoryID`, `productCode`, `productName`, `description`, `listPrice`, `dateAdded`) 
VALUES
(4, "GO-61K", "Roland GO:Keys", "N/A", 399.00, SYSDATE()),
(5, "JTR700", "Jupiter Stdt Trumpet", "N/A", 675.00, SYSDATE()), 
(6, "CAS100", "Carlton Alto Saxophone", "N/A", 899.00, SYSDATE()) 