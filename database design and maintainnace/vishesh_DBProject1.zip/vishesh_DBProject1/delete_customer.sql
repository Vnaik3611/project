DELETE FROM customers 
WHERE emailAddress = "johnsmith@example.com";