var express = require('express');
var router = express.Router();
const ctrlMain = require('../controllers/main');
const ctrlMovie = require('../controllers/movie');
/* GET home page. */
router.get('/', function(req, res) {
  res.render('homelist', { title: 'vishesh' });
});
router.get('/movies/:movieid', ctrlMovie.movieInfo);
router.get('/favourite',ctrlMovie.favouriteMovie);
router.get('/list',ctrlMovie.movielist);

router.route('/new')
    .get(ctrlMovie.addNewMovie)
    .post(ctrlMovie.doAddNewMovie);

module.exports = router;
