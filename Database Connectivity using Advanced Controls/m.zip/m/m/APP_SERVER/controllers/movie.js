
var movieArray = [
    {
        'name': 'dhamal',
        'type': 'comedy'
    },
    {
        'name': 'baghi',
        'type': 'action'
    },
    {
        'name': 'kkhh',
        'type': 'romantic'
    }
];

const myFavMovie = 'kkhh';
const movielist = function (req, res) {
    res.render('movielist', {
        title:'Movie List',
        movies: movieArray
    });
};

const favouriteMovie = function (req, res) {
    res.render('favourite-movie', {
        title:'My favourite Movie',
        favMovie: myFavMovie
    });
};

const _renderHomePage = function (req, res, responseBody) {
    res.render('movielist', {
        movies: responseBody
    });
};

const homeList = function (req, res) {
    const path = '/api/movies';
    const requestOptions = {
        url : apiOptions.server + path,
        method : 'GET',
        json : {}
    };

    request(
        requestOptions,
        (err, response, body) => {
            if(err) console.log(err);
            _renderHomePage(req, res, body);
        }
    );
};
const _renderDetailsPage = function (req, res, responseBody) {
    res.render('movie-info', {
        currentMovie: responseBody
    });
};

const movieInfo = function (req, res) {
    const path = `/api/movies/${req.params.movieid}`;
    const requestOptions = {
        url : apiOptions.server + path,
        method : 'GET',
        json : {}
    };

    request(
        requestOptions,
        (err, response, body) => {
            _renderDetailsPage(req, res, body);
        }
    );
};
const  _renderCreatePage = function(req,res){
    res.render('create-new-movie',{
        title:"Create New Movie"
    });
};
const addNewMovie = function(req,res){
    _renderCreatePage(req,res);
};
const  doAddNewMovie = function(req,res){
    const path = '/api/movies';
    const postdata = {
        name: req.body.name,
        type: req.body.type
    };
    const  requestOptions = {
        url: apiOptions.server+path,
        method:'POST',
        json: postdata
    };
    request(
        requestOptions,(err,response,body) =>{
            if(response.statusCode === 201){
                res.redirect('/');
            }
        }
    );
};

module.exports = {
    movielist,
    favouriteMovie,
    movieInfo,
    homeList,
    doAddNewMovie,
    addNewMovie
}