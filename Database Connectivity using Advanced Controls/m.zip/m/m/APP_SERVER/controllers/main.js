const index = function (req, res) {
    res.render('index', { title: 'vishesh'});
};
const movielist = function (req, res) {
    res.render('movielist', { movies:movieArray});
};
const favouriteMovie = function (req, res) {
    res.render('favouriteMovie', { movies:myFavMovie});
};
module.exports = {
    index,
    movielist,
    favouriteMovie,
};