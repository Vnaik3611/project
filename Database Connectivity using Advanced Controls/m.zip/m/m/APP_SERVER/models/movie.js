const mongoose = require('mongoose');

var movieSchema = new mongoose.Schema({
    name: {type: String, required: true, minLength: 3},
    type: {type: String, required: true}
});

var moviemodel = mongoose.model('Movie', movieSchema);
module.exports= moviemodel;