import { Component, OnInit } from '@angular/core';
import { Movie } from "../movie";
import { MovieServiceService } from "../movie-service.service";

@Component({
  selector: 'app-create',
  templateUrl: './create.component.html',
  styleUrls: ['./create.component.css'],
  providers: [MovieServiceService]
})
export class CreateComponent implements OnInit {

  public newMovie: { name: string; type: string } = {
    name: '',
    type: ''
  };

  constructor(private movieServiceService: MovieServiceService) { }

  ngOnInit() {
  }

  public createNewMovie(newMovie: Movie): void {
    this.movieServiceService.createMovie(newMovie);
  }

}

