import { Component, OnInit } from '@angular/core';
import { ActivatedRoute , Params } from '@angular/router';
import { MovieServiceService } from '../movie-service.service';
import { Movie } from '../movie';
import { switchMap } from 'rxjs/operators';

@Component({
  selector: 'app-details-page',
  templateUrl: './details-page.component.html',
  styleUrls: ['./details-page.component.css'],
  providers: [MovieServiceService]
})
export class DetailsPageComponent implements OnInit {

  constructor(
    private movieServiceService: MovieServiceService,
    private route: ActivatedRoute
  ) { }
  newMovie: Movie;
  pageContent = {
    header : {
      title : '',
      body : ''
    }
  };

  ngOnInit(): void {
    this.route.params.pipe(
      switchMap((params: Params) => {
        return this.movieServiceService.getSingleMovie(params.foodid);
      }))
      .subscribe((newMovie: Movie) => {
        this.newMovie = newMovie;
        this.pageContent.header.title = newMovie.name;
        this.pageContent.header.body = 'Details for selected movie';
      });
  }
}
