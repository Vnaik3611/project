var express = require('express');
var router = express.Router();

const ctrlAbout = require('../controllers/about');
const ctrlDisplay = require('../controllers/list');


/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('index', { title: 'MOVIES' });
});


/* GET about page */
router.get('/about', ctrlAbout.about);
/* GET home list of movie. */
router.get('/list', ctrlDisplay.homelist);
/* GET home display. */
router.get('/display', function(req, res, next) {
  res.render('display', { title: 'Not Yet Implemented' });
});
/* GET details */
router.get('/movies/:movieid', ctrlDisplay.movieInfo);
/* GET  new product add page . */
router.route('/new')
      .get(ctrlDisplay.addNewMovie)
      .post(ctrlDisplay.doAddNewMovie);


module.exports = router;

