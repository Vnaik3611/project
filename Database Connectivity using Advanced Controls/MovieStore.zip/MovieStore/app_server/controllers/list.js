const request = require('request');
const apiOptions = { 
server : 'http://localhost:3000' 
};

//Render the HOmepage
const _renderHomepage = function(req, res, responseBody){
    res.render('list-display',{
        movies: responseBody
    });
};


// Render the List of MOvies  from API
const homelist = function(req,res){
    const path = '/api/movies';
    const requestOptions = {
        url : apiOptions.server + path,
        method : 'GET',
        json : {}
    };
    request(
        requestOptions,
        (err, response, body) => {
        _renderHomepage(req, res, body);
        }
    );
};


//Render the Details Page for Particular movies
const _renderDetailPage = function(req, res, responseBody){
    res.render('details',{
        currentMovie: responseBody
    });
};

// Calling Getsingle Movie To get MOvie details
const movieInfo = function(req, res){
    const path = `/api/movies/${req.params.movieid}`;
    const requestOptions = {
        url : apiOptions.server + path,
        method : 'GET',
        json: {}
    };
    request(
        requestOptions,
        (err, response, body) => {
            _renderDetailPage(req,res,body);
        }
    );
};

const _renderCreatePage = function(req, res){
    res.render('create',{
        title: "Create New Movie"
    });
};


//Adding a new MOvie to api
const addNewMovie = function(req, res){
    _renderCreatePage(req, res);
};

const doAddNewMovie = function(req, res){
    const path = '/api/movies';
    const postdata = {
        name:req.body.name,
       type:req.body.type,
       year:req.body.year,      
       rating:req.body.rating
    };
    const requestOptions = {
        url: apiOptions.server+path,
        method: 'POST',
        json: postdata
    };
    request(
    requestOptions,
    (err, response, body) => {
        if(response.statusCode === 201){
            res.redirect('/');
        }
    }
    );
};

module.exports = {
 homelist, movieInfo, doAddNewMovie, addNewMovie 
};




