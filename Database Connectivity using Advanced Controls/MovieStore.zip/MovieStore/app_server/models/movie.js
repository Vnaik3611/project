const mongoose = require('mongoose');


//MOvie Scehma
const movieSchema = new mongoose.Schema({
    name: {
        type: String,
        required: true, 
        minlength : 3
    },
    type:{
        type:String,
        required:true
        
    },
     year:{
        type:String,
        required:true
        
    },
    rating:{
        type:String,
        required:true 
     
    }
                                        
});
 /*   
module.exports={
    food:foodSchema
}*/

//Exporting the schema
module.exports = mongoose.model('Movie',movieSchema);