import { Injectable } from '@angular/core';
import { Movie } from './movie';
import { Http,Response } from '@angular/http';

@Injectable()
export class MovieServiceService {

    private moviesUrl = 'http://localhost:3000/api/movies';

  constructor(private http: Http) { }
    getMovies(): Promise<void | Movie[]> {
        return this.http.get(this.moviesUrl)
                    .toPromise()
                    .then(response => response.json() as Movie[])
                    .catch(this.handleError);
    }
    
    getSingleMovie(movieId: String): Promise<void | Movie>{
        return this.http.get(this.moviesUrl + '/' + movieId)
                .toPromise()
                .then(response=> response.json() as Movie)
                .catch(this.handleError);
    }
    
    createMovie(newMovie: Movie): Promise<void | Movie>{
        return this.http.post(this.moviesUrl, newMovie)
                    .toPromise()
                    .then(response => response.json() as Movie)
                    .catch(this.handleError);
    }

  deleteMovie(id) {
    return this.http.delete(this.moviesUrl+ '/' + id)
      .toPromise()
      .then(response => response.json() as Movie)
      .catch(this.handleError);
  }
    
    private handleError (error: any) {
        console.log("error");
    }

}
