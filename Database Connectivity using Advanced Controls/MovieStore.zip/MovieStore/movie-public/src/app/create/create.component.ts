import { Component, OnInit } from '@angular/core';
import { Movie } from '../movie';
import { MovieServiceService } from '../movie-service.service';
import { Router } from "@angular/router";

@Component({
  selector: 'app-create',
  templateUrl: './create.component.html',
  styleUrls: ['./create.component.css'],
  providers: [MovieServiceService]

})
export class CreateComponent implements OnInit {

    public newMovie: Movie = {
        name: '',
        type: '',
         year: '',
          rating: '',
        _id: ''
    };

  constructor(private movieServiceService: MovieServiceService,
              public router: Router) { }

  ngOnInit() {
  }
  
    public createNewMovie(newMovie: Movie):void {
      this.movieServiceService.createMovie(newMovie);
      this.router.navigate(['list']);
}
}
