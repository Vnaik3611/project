import { Component, OnInit } from '@angular/core';

export class Movie {

    _id: string;
    name: string;
    type: string;
     year: string;
    rating: string;
}
