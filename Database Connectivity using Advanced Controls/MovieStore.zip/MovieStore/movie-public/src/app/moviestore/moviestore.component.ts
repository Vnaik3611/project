import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-moviestore',
  templateUrl: './moviestore.component.html',
  styleUrls: ['./moviestore.component.css']
})
export class MoviestoreComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
