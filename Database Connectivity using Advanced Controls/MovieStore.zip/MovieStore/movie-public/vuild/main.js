(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["main"],{

/***/ "./src/$$_lazy_route_resource lazy recursive":
/*!**********************************************************!*\
  !*** ./src/$$_lazy_route_resource lazy namespace object ***!
  \**********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

function webpackEmptyAsyncContext(req) {
	// Here Promise.resolve().then() is used instead of new Promise() to prevent
	// uncaught exception popping up in devtools
	return Promise.resolve().then(function() {
		var e = new Error("Cannot find module '" + req + "'");
		e.code = 'MODULE_NOT_FOUND';
		throw e;
	});
}
webpackEmptyAsyncContext.keys = function() { return []; };
webpackEmptyAsyncContext.resolve = webpackEmptyAsyncContext;
module.exports = webpackEmptyAsyncContext;
webpackEmptyAsyncContext.id = "./src/$$_lazy_route_resource lazy recursive";

/***/ }),

/***/ "./src/app/about/about.component.css":
/*!*******************************************!*\
  !*** ./src/app/about/about.component.css ***!
  \*******************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "p{\r\n    text-align: justify;\r\n    margin:auto;\r\n    max-width: 60%;\r\n    font-size:15px;\r\n        padding-bottom: 60px;\r\n}\r\nh1{\r\n    text-align: center;\r\n    margin: 40px;\r\n}\r\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvYWJvdXQvYWJvdXQuY29tcG9uZW50LmNzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtJQUNJLG1CQUFtQjtJQUNuQixXQUFXO0lBQ1gsY0FBYztJQUNkLGNBQWM7UUFDVixvQkFBb0I7QUFDNUI7QUFDQTtJQUNJLGtCQUFrQjtJQUNsQixZQUFZO0FBQ2hCIiwiZmlsZSI6InNyYy9hcHAvYWJvdXQvYWJvdXQuY29tcG9uZW50LmNzcyIsInNvdXJjZXNDb250ZW50IjpbInB7XHJcbiAgICB0ZXh0LWFsaWduOiBqdXN0aWZ5O1xyXG4gICAgbWFyZ2luOmF1dG87XHJcbiAgICBtYXgtd2lkdGg6IDYwJTtcclxuICAgIGZvbnQtc2l6ZToxNXB4O1xyXG4gICAgICAgIHBhZGRpbmctYm90dG9tOiA2MHB4O1xyXG59XHJcbmgxe1xyXG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gICAgbWFyZ2luOiA0MHB4O1xyXG59Il19 */"

/***/ }),

/***/ "./src/app/about/about.component.html":
/*!********************************************!*\
  !*** ./src/app/about/about.component.html ***!
  \********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<h1> About Us</h1>\n\n<p>\n Founded in 1988 the original Music Store owned by Bruce Speakman and family, located in Bullhead City Arizona,  was a hub of activity for the tri state area musician’s community for many years.  Musicians of all ages and influence came to the store to purchase equipment, browse inventory and to speak with others of the same mind set. Bruce specialized in providing lessons, sales and repair of all musical equipment, along with promoting and helping local bands to network amongst themselves.  The original Music Store successfully operated for 8 years until it finally closed in 1995.  Bruce has continued to play music actively in the community since then.\n <br /><br />\n    We are pleased to announce the opening of the second generation of “The Music Store” located at 4345 Highway 95 in Fort Mohave. Owned and operated by Bruce and his wife Sharyn.  We hope to continue the traditions set in place with the original Music Store, supporting the musical community of the tri state area for years to come.\n<br /><br />\n| For those of you who visited the original Music Store, stop by and see Bruce, he will be there daily to help you with your musical needs.\n</p>\n"

/***/ }),

/***/ "./src/app/about/about.component.ts":
/*!******************************************!*\
  !*** ./src/app/about/about.component.ts ***!
  \******************************************/
/*! exports provided: AboutComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AboutComponent", function() { return AboutComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");


var AboutComponent = /** @class */ (function () {
    function AboutComponent() {
    }
    AboutComponent.prototype.ngOnInit = function () {
    };
    AboutComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-about',
            template: __webpack_require__(/*! ./about.component.html */ "./src/app/about/about.component.html"),
            styles: [__webpack_require__(/*! ./about.component.css */ "./src/app/about/about.component.css")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [])
    ], AboutComponent);
    return AboutComponent;
}());



/***/ }),

/***/ "./src/app/app.module.ts":
/*!*******************************!*\
  !*** ./src/app/app.module.ts ***!
  \*******************************/
/*! exports provided: AppModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppModule", function() { return AppModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/platform-browser */ "./node_modules/@angular/platform-browser/fesm5/platform-browser.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_http__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/http */ "./node_modules/@angular/http/fesm5/http.js");
/* harmony import */ var _home_list_home_list_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./home-list/home-list.component */ "./src/app/home-list/home-list.component.ts");
/* harmony import */ var _about_about_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./about/about.component */ "./src/app/about/about.component.ts");
/* harmony import */ var _homepage_homepage_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./homepage/homepage.component */ "./src/app/homepage/homepage.component.ts");
/* harmony import */ var _header_header_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./header/header.component */ "./src/app/header/header.component.ts");
/* harmony import */ var _framework_framework_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./framework/framework.component */ "./src/app/framework/framework.component.ts");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _create_create_component__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./create/create.component */ "./src/app/create/create.component.ts");
/* harmony import */ var _details_page_details_page_component__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./details-page/details-page.component */ "./src/app/details-page/details-page.component.ts");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _moviestore_moviestore_component__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ./moviestore/moviestore.component */ "./src/app/moviestore/moviestore.component.ts");















var AppModule = /** @class */ (function () {
    function AppModule() {
    }
    AppModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["NgModule"])({
            declarations: [
                _home_list_home_list_component__WEBPACK_IMPORTED_MODULE_4__["HomeListComponent"],
                _about_about_component__WEBPACK_IMPORTED_MODULE_5__["AboutComponent"],
                _homepage_homepage_component__WEBPACK_IMPORTED_MODULE_6__["HomepageComponent"],
                _header_header_component__WEBPACK_IMPORTED_MODULE_7__["HeaderComponent"],
                _framework_framework_component__WEBPACK_IMPORTED_MODULE_8__["FrameworkComponent"],
                _create_create_component__WEBPACK_IMPORTED_MODULE_11__["CreateComponent"],
                _details_page_details_page_component__WEBPACK_IMPORTED_MODULE_12__["DetailsPageComponent"],
                _moviestore_moviestore_component__WEBPACK_IMPORTED_MODULE_14__["MoviestoreComponent"]
            ],
            imports: [
                _angular_platform_browser__WEBPACK_IMPORTED_MODULE_1__["BrowserModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_13__["FormsModule"],
                _angular_http__WEBPACK_IMPORTED_MODULE_3__["HttpModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_10__["RouterModule"].forRoot([
                    {
                        path: 'moviestore',
                        component: _moviestore_moviestore_component__WEBPACK_IMPORTED_MODULE_14__["MoviestoreComponent"]
                    },
                    {
                        path: '',
                        component: _homepage_homepage_component__WEBPACK_IMPORTED_MODULE_6__["HomepageComponent"]
                    },
                    {
                        path: 'create',
                        component: _create_create_component__WEBPACK_IMPORTED_MODULE_11__["CreateComponent"]
                    },
                    {
                        path: 'movie/:movieid',
                        component: _details_page_details_page_component__WEBPACK_IMPORTED_MODULE_12__["DetailsPageComponent"]
                    },
                    {
                        path: 'about',
                        component: _about_about_component__WEBPACK_IMPORTED_MODULE_5__["AboutComponent"]
                    },
                ])
            ],
            providers: [{ provide: _angular_common__WEBPACK_IMPORTED_MODULE_9__["APP_BASE_HREF"], useValue: '/' }],
            bootstrap: [_framework_framework_component__WEBPACK_IMPORTED_MODULE_8__["FrameworkComponent"]]
        })
    ], AppModule);
    return AppModule;
}());



/***/ }),

/***/ "./src/app/create/create.component.css":
/*!*********************************************!*\
  !*** ./src/app/create/create.component.css ***!
  \*********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "input[type=text] {\r\n  width: 100%;\r\n  padding: 12px 20px;\r\n  margin: 8px 0;\r\n  display: inline-block;\r\n  border: 1px solid #ccc;\r\n  border-radius: 4px;\r\n  box-sizing: border-box;\r\n}\r\n\r\ninput[type=submit] {\r\n  width: 100%;\r\n  background-color: #4CAF50;\r\n  color: white;\r\n  padding: 14px 20px;\r\n  margin: 8px 0;\r\n  border: none;\r\n  border-radius: 4px;\r\n  cursor: pointer;\r\n}\r\n\r\nform{\r\n    margin: 50px;\r\n}\r\n\r\ninput[type=submit]:hover {\r\n  background-color: #2ea1c1;\r\n}\r\n\r\ndiv {\r\n  border-radius: 5px;\r\n  background-color: #237fa9;\r\n  padding: 20px;\r\n      margin: 30px;\r\n    max-width: 50%;\r\n}\r\n\r\nh3 {  \r\n    text-align: center;\r\n    color: #ffffff;\r\n\r\n}\r\n\r\nlabel{\r\n     color: #ffffff;\r\n}\r\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvY3JlYXRlL2NyZWF0ZS5jb21wb25lbnQuY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0UsV0FBVztFQUNYLGtCQUFrQjtFQUNsQixhQUFhO0VBQ2IscUJBQXFCO0VBQ3JCLHNCQUFzQjtFQUN0QixrQkFBa0I7RUFDbEIsc0JBQXNCO0FBQ3hCOztBQUVBO0VBQ0UsV0FBVztFQUNYLHlCQUF5QjtFQUN6QixZQUFZO0VBQ1osa0JBQWtCO0VBQ2xCLGFBQWE7RUFDYixZQUFZO0VBQ1osa0JBQWtCO0VBQ2xCLGVBQWU7QUFDakI7O0FBQ0E7SUFDSSxZQUFZO0FBQ2hCOztBQUNBO0VBQ0UseUJBQXlCO0FBQzNCOztBQUVBO0VBQ0Usa0JBQWtCO0VBQ2xCLHlCQUF5QjtFQUN6QixhQUFhO01BQ1QsWUFBWTtJQUNkLGNBQWM7QUFDbEI7O0FBRUE7SUFDSSxrQkFBa0I7SUFDbEIsY0FBYzs7QUFFbEI7O0FBQ0E7S0FDSyxjQUFjO0FBQ25CIiwiZmlsZSI6InNyYy9hcHAvY3JlYXRlL2NyZWF0ZS5jb21wb25lbnQuY3NzIiwic291cmNlc0NvbnRlbnQiOlsiaW5wdXRbdHlwZT10ZXh0XSB7XHJcbiAgd2lkdGg6IDEwMCU7XHJcbiAgcGFkZGluZzogMTJweCAyMHB4O1xyXG4gIG1hcmdpbjogOHB4IDA7XHJcbiAgZGlzcGxheTogaW5saW5lLWJsb2NrO1xyXG4gIGJvcmRlcjogMXB4IHNvbGlkICNjY2M7XHJcbiAgYm9yZGVyLXJhZGl1czogNHB4O1xyXG4gIGJveC1zaXppbmc6IGJvcmRlci1ib3g7XHJcbn1cclxuXHJcbmlucHV0W3R5cGU9c3VibWl0XSB7XHJcbiAgd2lkdGg6IDEwMCU7XHJcbiAgYmFja2dyb3VuZC1jb2xvcjogIzRDQUY1MDtcclxuICBjb2xvcjogd2hpdGU7XHJcbiAgcGFkZGluZzogMTRweCAyMHB4O1xyXG4gIG1hcmdpbjogOHB4IDA7XHJcbiAgYm9yZGVyOiBub25lO1xyXG4gIGJvcmRlci1yYWRpdXM6IDRweDtcclxuICBjdXJzb3I6IHBvaW50ZXI7XHJcbn1cclxuZm9ybXtcclxuICAgIG1hcmdpbjogNTBweDtcclxufVxyXG5pbnB1dFt0eXBlPXN1Ym1pdF06aG92ZXIge1xyXG4gIGJhY2tncm91bmQtY29sb3I6ICMyZWExYzE7XHJcbn1cclxuXHJcbmRpdiB7XHJcbiAgYm9yZGVyLXJhZGl1czogNXB4O1xyXG4gIGJhY2tncm91bmQtY29sb3I6ICMyMzdmYTk7XHJcbiAgcGFkZGluZzogMjBweDtcclxuICAgICAgbWFyZ2luOiAzMHB4O1xyXG4gICAgbWF4LXdpZHRoOiA1MCU7XHJcbn1cclxuXHJcbmgzIHsgIFxyXG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gICAgY29sb3I6ICNmZmZmZmY7XHJcblxyXG59XHJcbmxhYmVse1xyXG4gICAgIGNvbG9yOiAjZmZmZmZmO1xyXG59Il19 */"

/***/ }),

/***/ "./src/app/create/create.component.html":
/*!**********************************************!*\
  !*** ./src/app/create/create.component.html ***!
  \**********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n<div>\n    <h3>Add New Movie</h3>\n<form (ngSubmit)=\"createNewMovie(newMovie)\">\n    <label for=\"name\">Name</label>\n    <input [(ngModel)]=\"newMovie.name\" type=\"text\" id=\"name\" name=\"name\" required=\"required\">\n    <label for=\"type\">Type</label>\n    <input [(ngModel)]=\"newMovie.type\"  type=\"text\" id=\"type\" name=\"type\" required=\"required\">\n    <label for=\"year\">Year</label>\n    <input [(ngModel)]=\"newMovie.year\"  type=\"text\" id=\"year\" name=\"year\" required=\"required\">\n    <label for=\"rating\">Rating</label>\n    <input [(ngModel)]=\"newMovie.rating\"  type=\"text\" id=\"rating\" name=\"rating\" required=\"required\">\n    <button class=\"btn\" type=\"submit\">Create</button>\n</form>  \n</div>\n<br>\n<br>\n<br>\n\n"

/***/ }),

/***/ "./src/app/create/create.component.ts":
/*!********************************************!*\
  !*** ./src/app/create/create.component.ts ***!
  \********************************************/
/*! exports provided: CreateComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CreateComponent", function() { return CreateComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _movie_service_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../movie-service.service */ "./src/app/movie-service.service.ts");



var CreateComponent = /** @class */ (function () {
    function CreateComponent(MovieServiceService) {
        this.MovieServiceService = MovieServiceService;
        this.newMovie = {
            name: '',
            type: '',
            year: '',
            rating: '',
            _id: ''
        };
    }
    CreateComponent.prototype.ngOnInit = function () {
    };
    CreateComponent.prototype.createNewMovie = function (newMovie) {
        this.MovieServiceService.createMovie(newMovie);
    };
    CreateComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-create',
            template: __webpack_require__(/*! ./create.component.html */ "./src/app/create/create.component.html"),
            providers: [_movie_service_service__WEBPACK_IMPORTED_MODULE_2__["MovieServiceService"]],
            styles: [__webpack_require__(/*! ./create.component.css */ "./src/app/create/create.component.css")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_movie_service_service__WEBPACK_IMPORTED_MODULE_2__["MovieServiceService"]])
    ], CreateComponent);
    return CreateComponent;
}());



/***/ }),

/***/ "./src/app/details-page/details-page.component.css":
/*!*********************************************************!*\
  !*** ./src/app/details-page/details-page.component.css ***!
  \*********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "span{\r\n    color: brown;\r\n    font-style: bold;\r\n    font-size: 20px;\r\n}\r\np{\r\n    font-style: bold;\r\n    font-size: 20px;\r\n    width: 300px;\r\n}\r\n.Detail{\r\n        margin: 4% 0 4% 10%;\r\n}\r\n\r\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvZGV0YWlscy1wYWdlL2RldGFpbHMtcGFnZS5jb21wb25lbnQuY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0lBQ0ksWUFBWTtJQUNaLGdCQUFnQjtJQUNoQixlQUFlO0FBQ25CO0FBQ0E7SUFDSSxnQkFBZ0I7SUFDaEIsZUFBZTtJQUNmLFlBQVk7QUFDaEI7QUFDQTtRQUNRLG1CQUFtQjtBQUMzQiIsImZpbGUiOiJzcmMvYXBwL2RldGFpbHMtcGFnZS9kZXRhaWxzLXBhZ2UuY29tcG9uZW50LmNzcyIsInNvdXJjZXNDb250ZW50IjpbInNwYW57XHJcbiAgICBjb2xvcjogYnJvd247XHJcbiAgICBmb250LXN0eWxlOiBib2xkO1xyXG4gICAgZm9udC1zaXplOiAyMHB4O1xyXG59XHJcbnB7XHJcbiAgICBmb250LXN0eWxlOiBib2xkO1xyXG4gICAgZm9udC1zaXplOiAyMHB4O1xyXG4gICAgd2lkdGg6IDMwMHB4O1xyXG59XHJcbi5EZXRhaWx7XHJcbiAgICAgICAgbWFyZ2luOiA0JSAwIDQlIDEwJTtcclxufVxyXG4iXX0= */"

/***/ }),

/***/ "./src/app/details-page/details-page.component.html":
/*!**********************************************************!*\
  !*** ./src/app/details-page/details-page.component.html ***!
  \**********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"Detail\">\n<app-header [content]=\"pageContent.header\"></app-header>\n\n<div class=\"w3-card-4\" style=\"width:20%;margin: 20px;padding-bottom: 60px;\">\n<br>\n<p><span>Movie Name:</span> {{newMovie.name}}</p>\n<p><span>Movie Type:</span> {{newMovie.type}}</p>\n<p><span>Movie Year:</span> {{newMovie.year}}</p>\n<p><span>Movie Rating:</span> {{newMovie.rating}}</p>\n</div>\n"

/***/ }),

/***/ "./src/app/details-page/details-page.component.ts":
/*!********************************************************!*\
  !*** ./src/app/details-page/details-page.component.ts ***!
  \********************************************************/
/*! exports provided: DetailsPageComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DetailsPageComponent", function() { return DetailsPageComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _movie_service_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../movie-service.service */ "./src/app/movie-service.service.ts");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm5/operators/index.js");





var DetailsPageComponent = /** @class */ (function () {
    function DetailsPageComponent(movieServiceService, route) {
        this.movieServiceService = movieServiceService;
        this.route = route;
        this.pageContent = {
            header: {
                title: '',
                body: ''
            }
        };
    }
    DetailsPageComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.route.params.pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["switchMap"])(function (params) {
            return _this.movieServiceService.getSingleMovie(params['movieid']);
        }))
            .subscribe(function (newMovie) {
            _this.newMovie = newMovie;
            _this.pageContent.header.title = newMovie.name;
            _this.pageContent.header.body = "Details for selected movie";
        });
    };
    DetailsPageComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-details-page',
            template: __webpack_require__(/*! ./details-page.component.html */ "./src/app/details-page/details-page.component.html"),
            providers: [_movie_service_service__WEBPACK_IMPORTED_MODULE_3__["MovieServiceService"]],
            styles: [__webpack_require__(/*! ./details-page.component.css */ "./src/app/details-page/details-page.component.css")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_movie_service_service__WEBPACK_IMPORTED_MODULE_3__["MovieServiceService"],
            _angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"]])
    ], DetailsPageComponent);
    return DetailsPageComponent;
}());



/***/ }),

/***/ "./src/app/framework/framework.component.css":
/*!***************************************************!*\
  !*** ./src/app/framework/framework.component.css ***!
  \***************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "ul {\r\n  list-style-type: none;\r\n  margin: 0;\r\n  padding: 0;\r\n  overflow: hidden;\r\n  background-color: #2ea1c1;\r\n}\r\n\r\nli {\r\n  float: left;\r\n}\r\n\r\nli a {\r\n  display: block;\r\n  color: white;\r\n  text-align: center;\r\n  padding: 14px 16px;\r\n  text-decoration: none;\r\n}\r\n\r\nli a:hover:not(.active) {\r\n  background-color: #237fa9;\r\n}\r\n\r\n.active {\r\n  background-color: #237fa9;\r\n}\r\n\r\n\r\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvZnJhbWV3b3JrL2ZyYW1ld29yay5jb21wb25lbnQuY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0UscUJBQXFCO0VBQ3JCLFNBQVM7RUFDVCxVQUFVO0VBQ1YsZ0JBQWdCO0VBQ2hCLHlCQUF5QjtBQUMzQjs7QUFFQTtFQUNFLFdBQVc7QUFDYjs7QUFFQTtFQUNFLGNBQWM7RUFDZCxZQUFZO0VBQ1osa0JBQWtCO0VBQ2xCLGtCQUFrQjtFQUNsQixxQkFBcUI7QUFDdkI7O0FBRUE7RUFDRSx5QkFBeUI7QUFDM0I7O0FBRUE7RUFDRSx5QkFBeUI7QUFDM0IiLCJmaWxlIjoic3JjL2FwcC9mcmFtZXdvcmsvZnJhbWV3b3JrLmNvbXBvbmVudC5jc3MiLCJzb3VyY2VzQ29udGVudCI6WyJ1bCB7XHJcbiAgbGlzdC1zdHlsZS10eXBlOiBub25lO1xyXG4gIG1hcmdpbjogMDtcclxuICBwYWRkaW5nOiAwO1xyXG4gIG92ZXJmbG93OiBoaWRkZW47XHJcbiAgYmFja2dyb3VuZC1jb2xvcjogIzJlYTFjMTtcclxufVxyXG5cclxubGkge1xyXG4gIGZsb2F0OiBsZWZ0O1xyXG59XHJcblxyXG5saSBhIHtcclxuICBkaXNwbGF5OiBibG9jaztcclxuICBjb2xvcjogd2hpdGU7XHJcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gIHBhZGRpbmc6IDE0cHggMTZweDtcclxuICB0ZXh0LWRlY29yYXRpb246IG5vbmU7XHJcbn1cclxuXHJcbmxpIGE6aG92ZXI6bm90KC5hY3RpdmUpIHtcclxuICBiYWNrZ3JvdW5kLWNvbG9yOiAjMjM3ZmE5O1xyXG59XHJcblxyXG4uYWN0aXZlIHtcclxuICBiYWNrZ3JvdW5kLWNvbG9yOiAjMjM3ZmE5O1xyXG59XHJcblxyXG4iXX0= */"

/***/ }),

/***/ "./src/app/framework/framework.component.html":
/*!****************************************************!*\
  !*** ./src/app/framework/framework.component.html ***!
  \****************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<body>\n    <ul>\n    <li><a class=\"active\" routerLink=\"moviestore\">Movie Store</a></li>\n      <li><a  routerLink=\"\">List</a></li>\n      <li><a routerLink=\"about\">About</a></li>\n      <li><a routerLink=\"create\">Create</a></li>\n    </ul>\n    <router-outlet></router-outlet>\n</body>"

/***/ }),

/***/ "./src/app/framework/framework.component.ts":
/*!**************************************************!*\
  !*** ./src/app/framework/framework.component.ts ***!
  \**************************************************/
/*! exports provided: FrameworkComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "FrameworkComponent", function() { return FrameworkComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");


var FrameworkComponent = /** @class */ (function () {
    function FrameworkComponent() {
    }
    FrameworkComponent.prototype.ngOnInit = function () {
    };
    FrameworkComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-framework',
            template: __webpack_require__(/*! ./framework.component.html */ "./src/app/framework/framework.component.html"),
            styles: [__webpack_require__(/*! ./framework.component.css */ "./src/app/framework/framework.component.css")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [])
    ], FrameworkComponent);
    return FrameworkComponent;
}());



/***/ }),

/***/ "./src/app/header/header.component.css":
/*!*********************************************!*\
  !*** ./src/app/header/header.component.css ***!
  \*********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".header{\r\n    margin: 20px;\r\n}\r\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvaGVhZGVyL2hlYWRlci5jb21wb25lbnQuY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0lBQ0ksWUFBWTtBQUNoQiIsImZpbGUiOiJzcmMvYXBwL2hlYWRlci9oZWFkZXIuY29tcG9uZW50LmNzcyIsInNvdXJjZXNDb250ZW50IjpbIi5oZWFkZXJ7XHJcbiAgICBtYXJnaW46IDIwcHg7XHJcbn0iXX0= */"

/***/ }),

/***/ "./src/app/header/header.component.html":
/*!**********************************************!*\
  !*** ./src/app/header/header.component.html ***!
  \**********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"header\">\n<h1>{{content.title}}</h1>\n<p>{{content.body}}</p>\n    </div>"

/***/ }),

/***/ "./src/app/header/header.component.ts":
/*!********************************************!*\
  !*** ./src/app/header/header.component.ts ***!
  \********************************************/
/*! exports provided: HeaderComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HeaderComponent", function() { return HeaderComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");


var HeaderComponent = /** @class */ (function () {
    function HeaderComponent() {
    }
    HeaderComponent.prototype.ngOnInit = function () {
    };
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
    ], HeaderComponent.prototype, "content", void 0);
    HeaderComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-header',
            template: __webpack_require__(/*! ./header.component.html */ "./src/app/header/header.component.html"),
            styles: [__webpack_require__(/*! ./header.component.css */ "./src/app/header/header.component.css")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [])
    ], HeaderComponent);
    return HeaderComponent;
}());



/***/ }),

/***/ "./src/app/home-list/home-list.component.css":
/*!***************************************************!*\
  !*** ./src/app/home-list/home-list.component.css ***!
  \***************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\r\n\r\n\r\n/* W3.CSS 4.12 November 2018 by Jan Egil and Borge Refsnes */\r\nhtml{box-sizing:border-box}\r\n*,*:before,*:after{box-sizing:inherit}\r\n/* Extract from normalize.css by Nicolas Gallagher and Jonathan Neal git.io/normalize */\r\nhtml{-ms-text-size-adjust:100%;-webkit-text-size-adjust:100%}\r\nbody{margin:0}\r\narticle,aside,details,figcaption,figure,footer,header,main,menu,nav,section,summary{display:block}\r\naudio,canvas,progress,video{display:inline-block}\r\nprogress{vertical-align:baseline}\r\naudio:not([controls]){display:none;height:0}\r\n[hidden],template{display:none}\r\na{background-color:transparent;-webkit-text-decoration-skip:objects}\r\na:active,a:hover{outline-width:0}\r\nabbr[title]{border-bottom:none;text-decoration:underline;-webkit-text-decoration:underline dotted;text-decoration:underline dotted}\r\ndfn{font-style:italic}\r\nmark{background:#ff0;color:#000}\r\nsmall{font-size:80%}\r\nsub,sup{font-size:75%;line-height:0;position:relative;vertical-align:baseline}\r\nsub{bottom:-0.25em}\r\nsup{top:-0.5em}\r\nfigure{margin:1em 40px}\r\nimg{border-style:none}\r\nsvg:not(:root){overflow:hidden}\r\ncode,kbd,pre,samp{font-family:monospace,monospace;font-size:1em}\r\nhr{box-sizing:content-box;height:0;overflow:visible}\r\nbutton,input,select,textarea{font:inherit;margin:0}\r\noptgroup{font-weight:bold}\r\nbutton,input{overflow:visible}\r\nbutton,select{text-transform:none}\r\nbutton,html [type=button],[type=reset],[type=submit]{-webkit-appearance:button}\r\nbutton::-moz-focus-inner, [type=button]::-moz-focus-inner, [type=reset]::-moz-focus-inner, [type=submit]::-moz-focus-inner{border-style:none;padding:0}\r\nbutton:-moz-focusring, [type=button]:-moz-focusring, [type=reset]:-moz-focusring, [type=submit]:-moz-focusring{outline:1px dotted ButtonText}\r\nfieldset{border:1px solid #c0c0c0;margin:0 2px;padding:.35em .625em .75em}\r\nlegend{color:inherit;display:table;max-width:100%;padding:0;white-space:normal}\r\ntextarea{overflow:auto}\r\n[type=checkbox],[type=radio]{padding:0}\r\n[type=number]::-webkit-inner-spin-button,[type=number]::-webkit-outer-spin-button{height:auto}\r\n[type=search]{-webkit-appearance:textfield;outline-offset:-2px}\r\n[type=search]::-webkit-search-cancel-button,[type=search]::-webkit-search-decoration{-webkit-appearance:none}\r\n::-webkit-input-placeholder{color:inherit;opacity:0.54}\r\n::-webkit-file-upload-button{-webkit-appearance:button;font:inherit}\r\n/* End extract */\r\nhtml,body{font-family:Verdana,sans-serif;font-size:15px;line-height:1.5}\r\nhtml{overflow-x:hidden}\r\nh1{font-size:36px}\r\nh2{font-size:30px}\r\nh3{font-size:24px}\r\nh4{font-size:20px}\r\nh5{font-size:18px}\r\nh6{font-size:16px}\r\n.w3-serif{font-family:serif}\r\nh1,h2,h3,h4,h5,h6{font-family:\"Segoe UI\",Arial,sans-serif;font-weight:400;margin:10px 0}\r\n.w3-wide{letter-spacing:4px}\r\nhr{border:0;border-top:1px solid #eee;margin:20px 0}\r\n.w3-image{max-width:100%;height:auto}\r\nimg{vertical-align:middle}\r\na{color:inherit}\r\n.w3-table,.w3-table-all{border-collapse:collapse;border-spacing:0;width:100%;display:table}\r\n.w3-table-all{border:1px solid #ccc}\r\n.w3-bordered tr,.w3-table-all tr{border-bottom:1px solid #ddd}\r\n.w3-striped tbody tr:nth-child(even){background-color:#f1f1f1}\r\n.w3-table-all tr:nth-child(odd){background-color:#fff}\r\n.w3-table-all tr:nth-child(even){background-color:#f1f1f1}\r\n.w3-hoverable tbody tr:hover,.w3-ul.w3-hoverable li:hover{background-color:#ccc}\r\n.w3-centered tr th,.w3-centered tr td{text-align:center}\r\n.w3-table td,.w3-table th,.w3-table-all td,.w3-table-all th{padding:8px 8px;display:table-cell;text-align:left;vertical-align:top}\r\n.w3-table th:first-child,.w3-table td:first-child,.w3-table-all th:first-child,.w3-table-all td:first-child{padding-left:16px}\r\n.w3-btn,.w3-button{border:none;display:inline-block;padding:8px 16px;vertical-align:middle;overflow:hidden;text-decoration:none;color:inherit;background-color:inherit;text-align:center;cursor:pointer;white-space:nowrap}\r\n.w3-btn:hover{box-shadow:0 8px 16px 0 rgba(0,0,0,0.2),0 6px 20px 0 rgba(0,0,0,0.19)}\r\n.w3-btn,.w3-button{-webkit-touch-callout:none;-webkit-user-select:none;-moz-user-select:none;-ms-user-select:none;user-select:none}\r\n.w3-disabled,.w3-btn:disabled,.w3-button:disabled{cursor:not-allowed;opacity:0.3}\r\n.w3-disabled *,:disabled *{pointer-events:none}\r\n.w3-btn.w3-disabled:hover,.w3-btn:disabled:hover{box-shadow:none}\r\n.w3-badge,.w3-tag{background-color:#000;color:#fff;display:inline-block;padding-left:8px;padding-right:8px;text-align:center}\r\n.w3-badge{border-radius:50%}\r\n.w3-ul{list-style-type:none;padding:0;margin:0}\r\n.w3-ul li{padding:8px 16px;border-bottom:1px solid #ddd}\r\n.w3-ul li:last-child{border-bottom:none}\r\n.w3-tooltip,.w3-display-container{position:relative}\r\n.w3-tooltip .w3-text{display:none}\r\n.w3-tooltip:hover .w3-text{display:inline-block}\r\n.w3-ripple:active{opacity:0.5}\r\n.w3-ripple{transition:opacity 0s}\r\n.w3-input{padding:8px;display:block;border:none;border-bottom:1px solid #ccc;width:100%}\r\n.w3-select{padding:9px 0;width:100%;border:none;border-bottom:1px solid #ccc}\r\n.w3-dropdown-click,.w3-dropdown-hover{position:relative;display:inline-block;cursor:pointer}\r\n.w3-dropdown-hover:hover .w3-dropdown-content{display:block}\r\n.w3-dropdown-hover:first-child,.w3-dropdown-click:hover{background-color:#ccc;color:#000}\r\n.w3-dropdown-hover:hover > .w3-button:first-child,.w3-dropdown-click:hover > .w3-button:first-child{background-color:#ccc;color:#000}\r\n.w3-dropdown-content{cursor:auto;color:#000;background-color:#fff;display:none;position:absolute;min-width:160px;margin:0;padding:0;z-index:1}\r\n.w3-check,.w3-radio{width:24px;height:24px;position:relative;top:6px}\r\n.w3-sidebar{height:100%;width:200px;background-color:#fff;position:fixed!important;z-index:1;overflow:auto}\r\n.w3-bar-block .w3-dropdown-hover,.w3-bar-block .w3-dropdown-click{width:100%}\r\n.w3-bar-block .w3-dropdown-hover .w3-dropdown-content,.w3-bar-block .w3-dropdown-click .w3-dropdown-content{min-width:100%}\r\n.w3-bar-block .w3-dropdown-hover .w3-button,.w3-bar-block .w3-dropdown-click .w3-button{width:100%;text-align:left;padding:8px 16px}\r\n.w3-main,#main{transition:margin-left .4s}\r\n.w3-modal{z-index:3;display:none;padding-top:100px;position:fixed;left:0;top:0;width:100%;height:100%;overflow:auto;background-color:rgb(0,0,0);background-color:rgba(0,0,0,0.4)}\r\n.w3-modal-content{margin:auto;background-color:#fff;position:relative;padding:0;outline:0;width:600px}\r\n.w3-bar{width:100%;overflow:hidden}\r\n.w3-center .w3-bar{display:inline-block;width:auto}\r\n.w3-bar .w3-bar-item{padding:8px 16px;float:left;width:auto;border:none;display:block;outline:0}\r\n.w3-bar .w3-dropdown-hover,.w3-bar .w3-dropdown-click{position:static;float:left}\r\n.w3-bar .w3-button{white-space:normal}\r\n.w3-bar-block .w3-bar-item{width:100%;display:block;padding:8px 16px;text-align:left;border:none;white-space:normal;float:none;outline:0}\r\n.w3-bar-block.w3-center .w3-bar-item{text-align:center}\r\n.w3-block{display:block;width:100%}\r\n.w3-responsive{display:block;overflow-x:auto}\r\n.w3-container:after,.w3-container:before,.w3-panel:after,.w3-panel:before,.w3-row:after,.w3-row:before,.w3-row-padding:after,.w3-row-padding:before,\r\n.w3-cell-row:before,.w3-cell-row:after,.w3-clear:after,.w3-clear:before,.w3-bar:before,.w3-bar:after{content:\"\";display:table;clear:both}\r\n.w3-col,.w3-half,.w3-third,.w3-twothird,.w3-threequarter,.w3-quarter{float:left;width:100%}\r\n.w3-col.s1{width:8.33333%}\r\n.w3-col.s2{width:16.66666%}\r\n.w3-col.s3{width:24.99999%}\r\n.w3-col.s4{width:33.33333%}\r\n.w3-col.s5{width:41.66666%}\r\n.w3-col.s6{width:49.99999%}\r\n.w3-col.s7{width:58.33333%}\r\n.w3-col.s8{width:66.66666%}\r\n.w3-col.s9{width:74.99999%}\r\n.w3-col.s10{width:83.33333%}\r\n.w3-col.s11{width:91.66666%}\r\n.w3-col.s12{width:99.99999%}\r\n@media (min-width:601px){.w3-col.m1{width:8.33333%}.w3-col.m2{width:16.66666%}.w3-col.m3,.w3-quarter{width:24.99999%}.w3-col.m4,.w3-third{width:33.33333%}\r\n.w3-col.m5{width:41.66666%}.w3-col.m6,.w3-half{width:49.99999%}.w3-col.m7{width:58.33333%}.w3-col.m8,.w3-twothird{width:66.66666%}\r\n.w3-col.m9,.w3-threequarter{width:74.99999%}.w3-col.m10{width:83.33333%}.w3-col.m11{width:91.66666%}.w3-col.m12{width:99.99999%}}\r\n@media (min-width:993px){.w3-col.l1{width:8.33333%}.w3-col.l2{width:16.66666%}.w3-col.l3{width:24.99999%}.w3-col.l4{width:33.33333%}\r\n.w3-col.l5{width:41.66666%}.w3-col.l6{width:49.99999%}.w3-col.l7{width:58.33333%}.w3-col.l8{width:66.66666%}\r\n.w3-col.l9{width:74.99999%}.w3-col.l10{width:83.33333%}.w3-col.l11{width:91.66666%}.w3-col.l12{width:99.99999%}}\r\n.w3-rest{overflow:hidden}\r\n.w3-stretch{margin-left:-16px;margin-right:-16px}\r\n.w3-content,.w3-auto{margin-left:auto;margin-right:auto}\r\n.w3-content{max-width:980px}\r\n.w3-auto{max-width:1140px}\r\n.w3-cell-row{display:table;width:100%}\r\n.w3-cell{display:table-cell}\r\n.w3-cell-top{vertical-align:top}\r\n.w3-cell-middle{vertical-align:middle}\r\n.w3-cell-bottom{vertical-align:bottom}\r\n.w3-hide{display:none!important}\r\n.w3-show-block,.w3-show{display:block!important}\r\n.w3-show-inline-block{display:inline-block!important}\r\n@media (max-width:1205px){.w3-auto{max-width:95%}}\r\n@media (max-width:600px){.w3-modal-content{margin:0 10px;width:auto!important}.w3-modal{padding-top:30px}\r\n.w3-dropdown-hover.w3-mobile .w3-dropdown-content,.w3-dropdown-click.w3-mobile .w3-dropdown-content{position:relative}\t\r\n.w3-hide-small{display:none!important}.w3-mobile{display:block;width:100%!important}.w3-bar-item.w3-mobile,.w3-dropdown-hover.w3-mobile,.w3-dropdown-click.w3-mobile{text-align:center}\r\n.w3-dropdown-hover.w3-mobile,.w3-dropdown-hover.w3-mobile .w3-btn,.w3-dropdown-hover.w3-mobile .w3-button,.w3-dropdown-click.w3-mobile,.w3-dropdown-click.w3-mobile .w3-btn,.w3-dropdown-click.w3-mobile .w3-button{width:100%}}\r\n@media (max-width:768px){.w3-modal-content{width:500px}.w3-modal{padding-top:50px}}\r\n@media (min-width:993px){.w3-modal-content{width:900px}.w3-hide-large{display:none!important}.w3-sidebar.w3-collapse{display:block!important}}\r\n@media (max-width:992px) and (min-width:601px){.w3-hide-medium{display:none!important}}\r\n@media (max-width:992px){.w3-sidebar.w3-collapse{display:none}.w3-main{margin-left:0!important;margin-right:0!important}.w3-auto{max-width:100%}}\r\n.w3-top,.w3-bottom{position:fixed;width:100%;z-index:1}\r\n.w3-top{top:0}\r\n.w3-bottom{bottom:0}\r\n.w3-overlay{position:fixed;display:none;width:100%;height:100%;top:0;left:0;right:0;bottom:0;background-color:rgba(0,0,0,0.5);z-index:2}\r\n.w3-display-topleft{position:absolute;left:0;top:0}\r\n.w3-display-topright{position:absolute;right:0;top:0}\r\n.w3-display-bottomleft{position:absolute;left:0;bottom:0}\r\n.w3-display-bottomright{position:absolute;right:0;bottom:0}\r\n.w3-display-middle{position:absolute;top:50%;left:50%;-webkit-transform:translate(-50%,-50%);transform:translate(-50%,-50%);-ms-transform:translate(-50%,-50%)}\r\n.w3-display-left{position:absolute;top:50%;left:0%;-webkit-transform:translate(0%,-50%);transform:translate(0%,-50%);-ms-transform:translate(-0%,-50%)}\r\n.w3-display-right{position:absolute;top:50%;right:0%;-webkit-transform:translate(0%,-50%);transform:translate(0%,-50%);-ms-transform:translate(0%,-50%)}\r\n.w3-display-topmiddle{position:absolute;left:50%;top:0;-webkit-transform:translate(-50%,0%);transform:translate(-50%,0%);-ms-transform:translate(-50%,0%)}\r\n.w3-display-bottommiddle{position:absolute;left:50%;bottom:0;-webkit-transform:translate(-50%,0%);transform:translate(-50%,0%);-ms-transform:translate(-50%,0%)}\r\n.w3-display-container:hover .w3-display-hover{display:block}\r\n.w3-display-container:hover span.w3-display-hover{display:inline-block}\r\n.w3-display-hover{display:none}\r\n.w3-display-position{position:absolute}\r\n.w3-circle{border-radius:50%}\r\n.w3-round-small{border-radius:2px}\r\n.w3-round,.w3-round-medium{border-radius:4px}\r\n.w3-round-large{border-radius:8px}\r\n.w3-round-xlarge{border-radius:16px}\r\n.w3-round-xxlarge{border-radius:32px}\r\n.w3-row-padding,.w3-row-padding>.w3-half,.w3-row-padding>.w3-third,.w3-row-padding>.w3-twothird,.w3-row-padding>.w3-threequarter,.w3-row-padding>.w3-quarter,.w3-row-padding>.w3-col{padding:0 8px}\r\n.w3-container,.w3-panel{padding:10px}\r\n.w3-panel{margin-top:16px;margin-bottom:16px}\r\n.w3-code,.w3-codespan{font-family:Consolas,\"courier new\";font-size:16px}\r\n.w3-code{width:auto;background-color:#fff;padding:8px 12px;border-left:4px solid #4CAF50;word-wrap:break-word}\r\n.w3-codespan{color:crimson;background-color:#f1f1f1;padding-left:4px;padding-right:4px;font-size:110%}\r\n.w3-card,.w3-card-2{box-shadow:0 2px 5px 0 rgba(0,0,0,0.16),0 2px 10px 0 rgba(0,0,0,0.12)}\r\n.w3-card-4,.w3-hover-shadow:hover{box-shadow:0 4px 10px 0 rgba(0,0,0,0.2),0 4px 20px 0 rgba(0,0,0,0.19)}\r\n.w3-spin{-webkit-animation:w3-spin 2s infinite linear;animation:w3-spin 2s infinite linear}\r\n@-webkit-keyframes w3-spin{0%{-webkit-transform:rotate(0deg);transform:rotate(0deg)}100%{-webkit-transform:rotate(359deg);transform:rotate(359deg)}}\r\n@keyframes w3-spin{0%{-webkit-transform:rotate(0deg);transform:rotate(0deg)}100%{-webkit-transform:rotate(359deg);transform:rotate(359deg)}}\r\n.w3-animate-fading{-webkit-animation:fading 10s infinite;animation:fading 10s infinite}\r\n@-webkit-keyframes fading{0%{opacity:0}50%{opacity:1}100%{opacity:0}}\r\n@keyframes fading{0%{opacity:0}50%{opacity:1}100%{opacity:0}}\r\n.w3-animate-opacity{-webkit-animation:opac 0.8s;animation:opac 0.8s}\r\n@-webkit-keyframes opac{from{opacity:0} to{opacity:1}}\r\n@keyframes opac{from{opacity:0} to{opacity:1}}\r\n.w3-animate-top{position:relative;-webkit-animation:animatetop 0.4s;animation:animatetop 0.4s}\r\n@-webkit-keyframes animatetop{from{top:-300px;opacity:0} to{top:0;opacity:1}}\r\n@keyframes animatetop{from{top:-300px;opacity:0} to{top:0;opacity:1}}\r\n.w3-animate-left{position:relative;-webkit-animation:animateleft 0.4s;animation:animateleft 0.4s}\r\n@-webkit-keyframes animateleft{from{left:-300px;opacity:0} to{left:0;opacity:1}}\r\n@keyframes animateleft{from{left:-300px;opacity:0} to{left:0;opacity:1}}\r\n.w3-animate-right{position:relative;-webkit-animation:animateright 0.4s;animation:animateright 0.4s}\r\n@-webkit-keyframes animateright{from{right:-300px;opacity:0} to{right:0;opacity:1}}\r\n@keyframes animateright{from{right:-300px;opacity:0} to{right:0;opacity:1}}\r\n.w3-animate-bottom{position:relative;-webkit-animation:animatebottom 0.4s;animation:animatebottom 0.4s}\r\n@-webkit-keyframes animatebottom{from{bottom:-300px;opacity:0} to{bottom:0;opacity:1}}\r\n@keyframes animatebottom{from{bottom:-300px;opacity:0} to{bottom:0;opacity:1}}\r\n.w3-animate-zoom {-webkit-animation:animatezoom 0.6s;animation:animatezoom 0.6s}\r\n@-webkit-keyframes animatezoom{from{-webkit-transform:scale(0);transform:scale(0)} to{-webkit-transform:scale(1);transform:scale(1)}}\r\n@keyframes animatezoom{from{-webkit-transform:scale(0);transform:scale(0)} to{-webkit-transform:scale(1);transform:scale(1)}}\r\n.w3-animate-input{transition:width 0.4s ease-in-out}\r\n.w3-animate-input:focus{width:100%!important}\r\n.w3-opacity,.w3-hover-opacity:hover{opacity:0.60}\r\n.w3-opacity-off,.w3-hover-opacity-off:hover{opacity:1}\r\n.w3-opacity-max{opacity:0.25}\r\n.w3-opacity-min{opacity:0.75}\r\n.w3-greyscale-max,.w3-grayscale-max,.w3-hover-greyscale:hover,.w3-hover-grayscale:hover{-webkit-filter:grayscale(100%);filter:grayscale(100%)}\r\n.w3-greyscale,.w3-grayscale{-webkit-filter:grayscale(75%);filter:grayscale(75%)}\r\n.w3-greyscale-min,.w3-grayscale-min{-webkit-filter:grayscale(50%);filter:grayscale(50%)}\r\n.w3-sepia{-webkit-filter:sepia(75%);filter:sepia(75%)}\r\n.w3-sepia-max,.w3-hover-sepia:hover{-webkit-filter:sepia(100%);filter:sepia(100%)}\r\n.w3-sepia-min{-webkit-filter:sepia(50%);filter:sepia(50%)}\r\n.w3-tiny{font-size:10px!important}\r\n.w3-small{font-size:12px!important}\r\n.w3-medium{font-size:15px!important}\r\n.w3-large{font-size:18px!important}\r\n.w3-xlarge{font-size:24px!important}\r\n.w3-xxlarge{font-size:36px!important}\r\n.w3-xxxlarge{font-size:48px!important}\r\n.w3-jumbo{font-size:64px!important}\r\n.w3-left-align{text-align:left!important}\r\n.w3-right-align{text-align:right!important}\r\n.w3-justify{text-align:justify!important}\r\n.w3-center{text-align:center!important}\r\n.w3-border-0{border:0!important}\r\n.w3-border{border:1px solid #ccc!important}\r\n.w3-border-top{border-top:1px solid #ccc!important}\r\n.w3-border-bottom{border-bottom:1px solid #ccc!important}\r\n.w3-border-left{border-left:1px solid #ccc!important}\r\n.w3-border-right{border-right:1px solid #ccc!important}\r\n.w3-topbar{border-top:6px solid #ccc!important}\r\n.w3-bottombar{border-bottom:6px solid #ccc!important}\r\n.w3-leftbar{border-left:6px solid #ccc!important}\r\n.w3-rightbar{border-right:6px solid #ccc!important}\r\n.w3-section,.w3-code{margin-top:16px!important;margin-bottom:16px!important}\r\n.w3-margin{margin:16px!important}\r\n.w3-margin-top{margin-top:16px!important}\r\n.w3-margin-bottom{margin-bottom:16px!important}\r\n.w3-margin-left{margin-left:16px!important}\r\n.w3-margin-right{margin-right:16px!important}\r\n.w3-padding-small{padding:4px 8px!important}\r\n.w3-padding{padding:8px 16px!important}\r\n.w3-padding-large{padding:12px 24px!important}\r\n.w3-padding-16{padding-top:16px!important;padding-bottom:16px!important}\r\n.w3-padding-24{padding-top:24px!important;padding-bottom:24px!important}\r\n.w3-padding-32{padding-top:32px!important;padding-bottom:32px!important}\r\n.w3-padding-48{padding-top:48px!important;padding-bottom:48px!important}\r\n.w3-padding-64{padding-top:64px!important;padding-bottom:64px!important}\r\n.w3-left{float:left!important}\r\n.w3-right{float:right!important}\r\n.w3-button:hover{color:#000!important;background-color:#ccc!important}\r\n.w3-transparent,.w3-hover-none:hover{background-color:transparent!important}\r\n.w3-hover-none:hover{box-shadow:none!important}\r\n/* Colors */\r\n.w3-amber,.w3-hover-amber:hover{color:#000!important;background-color:#ffc107!important}\r\n.w3-aqua,.w3-hover-aqua:hover{color:#000!important;background-color:#00ffff!important}\r\n.w3-blue,.w3-hover-blue:hover{color:#fff!important;background-color:#2196F3!important}\r\n.w3-light-blue,.w3-hover-light-blue:hover{color:#000!important;background-color:#87CEEB!important}\r\n.w3-brown,.w3-hover-brown:hover{color:#fff!important;background-color:#795548!important}\r\n.w3-cyan,.w3-hover-cyan:hover{color:#000!important;background-color:#00bcd4!important}\r\n.w3-blue-grey,.w3-hover-blue-grey:hover,.w3-blue-gray,.w3-hover-blue-gray:hover{color:#fff!important;background-color:#607d8b!important}\r\n.w3-green,.w3-hover-green:hover{color:#fff!important;background-color:#4CAF50!important}\r\n.w3-light-green,.w3-hover-light-green:hover{color:#000!important;background-color:#8bc34a!important}\r\n.w3-indigo,.w3-hover-indigo:hover{color:#fff!important;background-color:#3f51b5!important}\r\n.w3-khaki,.w3-hover-khaki:hover{color:#000!important;background-color:#f0e68c!important}\r\n.w3-lime,.w3-hover-lime:hover{color:#000!important;background-color:#cddc39!important}\r\n.w3-orange,.w3-hover-orange:hover{color:#000!important;background-color:#ff9800!important}\r\n.w3-deep-orange,.w3-hover-deep-orange:hover{color:#fff!important;background-color:#ff5722!important}\r\n.w3-pink,.w3-hover-pink:hover{color:#fff!important;background-color:#e91e63!important}\r\n.w3-purple,.w3-hover-purple:hover{color:#fff!important;background-color:#9c27b0!important}\r\n.w3-deep-purple,.w3-hover-deep-purple:hover{color:#fff!important;background-color:#673ab7!important}\r\n.w3-red,.w3-hover-red:hover{color:#fff!important;background-color:#f44336!important}\r\n.w3-sand,.w3-hover-sand:hover{color:#000!important;background-color:#fdf5e6!important}\r\n.w3-teal,.w3-hover-teal:hover{color:#fff!important;background-color:#009688!important}\r\n.w3-yellow,.w3-hover-yellow:hover{color:#000!important;background-color:#ffeb3b!important}\r\n.w3-white,.w3-hover-white:hover{color:#000!important;background-color:#fff!important}\r\n.w3-black,.w3-hover-black:hover{color:#fff!important;background-color:#000!important}\r\n.w3-grey,.w3-hover-grey:hover,.w3-gray,.w3-hover-gray:hover{color:#000!important;background-color:#9e9e9e!important}\r\n.w3-light-grey,.w3-hover-light-grey:hover,.w3-light-gray,.w3-hover-light-gray:hover{color:#000!important;background-color:#f1f1f1!important}\r\n.w3-dark-grey,.w3-hover-dark-grey:hover,.w3-dark-gray,.w3-hover-dark-gray:hover{color:#fff!important;background-color:#616161!important}\r\n.w3-pale-red,.w3-hover-pale-red:hover{color:#000!important;background-color:#ffdddd!important}\r\n.w3-pale-green,.w3-hover-pale-green:hover{color:#000!important;background-color:#ddffdd!important}\r\n.w3-pale-yellow,.w3-hover-pale-yellow:hover{color:#000!important;background-color:#ffffcc!important}\r\n.w3-pale-blue,.w3-hover-pale-blue:hover{color:#000!important;background-color:#ddffff!important}\r\n.w3-text-amber,.w3-hover-text-amber:hover{color:#ffc107!important}\r\n.w3-text-aqua,.w3-hover-text-aqua:hover{color:#00ffff!important}\r\n.w3-text-blue,.w3-hover-text-blue:hover{color:#2196F3!important}\r\n.w3-text-light-blue,.w3-hover-text-light-blue:hover{color:#87CEEB!important}\r\n.w3-text-brown,.w3-hover-text-brown:hover{color:#795548!important}\r\n.w3-text-cyan,.w3-hover-text-cyan:hover{color:#00bcd4!important}\r\n.w3-text-blue-grey,.w3-hover-text-blue-grey:hover,.w3-text-blue-gray,.w3-hover-text-blue-gray:hover{color:#607d8b!important}\r\n.w3-text-green,.w3-hover-text-green:hover{color:#4CAF50!important}\r\n.w3-text-light-green,.w3-hover-text-light-green:hover{color:#8bc34a!important}\r\n.w3-text-indigo,.w3-hover-text-indigo:hover{color:#3f51b5!important}\r\n.w3-text-khaki,.w3-hover-text-khaki:hover{color:#b4aa50!important}\r\n.w3-text-lime,.w3-hover-text-lime:hover{color:#cddc39!important}\r\n.w3-text-orange,.w3-hover-text-orange:hover{color:#ff9800!important}\r\n.w3-text-deep-orange,.w3-hover-text-deep-orange:hover{color:#ff5722!important}\r\n.w3-text-pink,.w3-hover-text-pink:hover{color:#e91e63!important}\r\n.w3-text-purple,.w3-hover-text-purple:hover{color:#9c27b0!important}\r\n.w3-text-deep-purple,.w3-hover-text-deep-purple:hover{color:#673ab7!important}\r\n.w3-text-red,.w3-hover-text-red:hover{color:#f44336!important}\r\n.w3-text-sand,.w3-hover-text-sand:hover{color:#fdf5e6!important}\r\n.w3-text-teal,.w3-hover-text-teal:hover{color:#009688!important}\r\n.w3-text-yellow,.w3-hover-text-yellow:hover{color:#d2be0e!important}\r\n.w3-text-white,.w3-hover-text-white:hover{color:#fff!important}\r\n.w3-text-black,.w3-hover-text-black:hover{color:#000!important}\r\n.w3-text-grey,.w3-hover-text-grey:hover,.w3-text-gray,.w3-hover-text-gray:hover{color:#757575!important}\r\n.w3-text-light-grey,.w3-hover-text-light-grey:hover,.w3-text-light-gray,.w3-hover-text-light-gray:hover{color:#f1f1f1!important}\r\n.w3-text-dark-grey,.w3-hover-text-dark-grey:hover,.w3-text-dark-gray,.w3-hover-text-dark-gray:hover{color:#3a3a3a!important}\r\n.w3-border-amber,.w3-hover-border-amber:hover{border-color:#ffc107!important}\r\n.w3-border-aqua,.w3-hover-border-aqua:hover{border-color:#00ffff!important}\r\n.w3-border-blue,.w3-hover-border-blue:hover{border-color:#2196F3!important}\r\n.w3-border-light-blue,.w3-hover-border-light-blue:hover{border-color:#87CEEB!important}\r\n.w3-border-brown,.w3-hover-border-brown:hover{border-color:#795548!important}\r\n.w3-border-cyan,.w3-hover-border-cyan:hover{border-color:#00bcd4!important}\r\n.w3-border-blue-grey,.w3-hover-border-blue-grey:hover,.w3-border-blue-gray,.w3-hover-border-blue-gray:hover{border-color:#607d8b!important}\r\n.w3-border-green,.w3-hover-border-green:hover{border-color:#4CAF50!important}\r\n.w3-border-light-green,.w3-hover-border-light-green:hover{border-color:#8bc34a!important}\r\n.w3-border-indigo,.w3-hover-border-indigo:hover{border-color:#3f51b5!important}\r\n.w3-border-khaki,.w3-hover-border-khaki:hover{border-color:#f0e68c!important}\r\n.w3-border-lime,.w3-hover-border-lime:hover{border-color:#cddc39!important}\r\n.w3-border-orange,.w3-hover-border-orange:hover{border-color:#ff9800!important}\r\n.w3-border-deep-orange,.w3-hover-border-deep-orange:hover{border-color:#ff5722!important}\r\n.w3-border-pink,.w3-hover-border-pink:hover{border-color:#e91e63!important}\r\n.w3-border-purple,.w3-hover-border-purple:hover{border-color:#9c27b0!important}\r\n.w3-border-deep-purple,.w3-hover-border-deep-purple:hover{border-color:#673ab7!important}\r\n.w3-border-red,.w3-hover-border-red:hover{border-color:#f44336!important}\r\n.w3-border-sand,.w3-hover-border-sand:hover{border-color:#fdf5e6!important}\r\n.w3-border-teal,.w3-hover-border-teal:hover{border-color:#009688!important}\r\n.w3-border-yellow,.w3-hover-border-yellow:hover{border-color:#ffeb3b!important}\r\n.w3-border-white,.w3-hover-border-white:hover{border-color:#fff!important}\r\n.w3-border-black,.w3-hover-border-black:hover{border-color:#000!important}\r\n.w3-border-grey,.w3-hover-border-grey:hover,.w3-border-gray,.w3-hover-border-gray:hover{border-color:#9e9e9e!important}\r\n.w3-border-light-grey,.w3-hover-border-light-grey:hover,.w3-border-light-gray,.w3-hover-border-light-gray:hover{border-color:#f1f1f1!important}\r\n.w3-border-dark-grey,.w3-hover-border-dark-grey:hover,.w3-border-dark-gray,.w3-hover-border-dark-gray:hover{border-color:#616161!important}\r\n.w3-border-pale-red,.w3-hover-border-pale-red:hover{border-color:#ffe7e7!important}\r\n.w3-border-pale-green,.w3-hover-border-pale-green:hover{border-color:#e7ffe7!important}\r\n.w3-border-pale-yellow,.w3-hover-border-pale-yellow:hover{border-color:#ffffcc!important}\r\n.w3-border-pale-blue,.w3-hover-border-pale-blue:hover{border-color:#e7ffff!important}\r\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvaG9tZS1saXN0L2hvbWUtbGlzdC5jb21wb25lbnQuY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7OztBQUdBLDREQUE0RDtBQUM1RCxLQUFLLHFCQUFxQjtBQUFDLG1CQUFtQixrQkFBa0I7QUFDaEUsdUZBQXVGO0FBQ3ZGLEtBQUsseUJBQXlCLENBQUMsNkJBQTZCO0FBQUMsS0FBSyxRQUFRO0FBQzFFLG9GQUFvRixhQUFhO0FBQ2pHLDRCQUE0QixvQkFBb0I7QUFBQyxTQUFTLHVCQUF1QjtBQUNqRixzQkFBc0IsWUFBWSxDQUFDLFFBQVE7QUFBQyxrQkFBa0IsWUFBWTtBQUMxRSxFQUFFLDRCQUE0QixDQUFDLG9DQUFvQztBQUNuRSxpQkFBaUIsZUFBZTtBQUFDLFlBQVksa0JBQWtCLENBQUMseUJBQXlCLENBQUMsd0NBQStCLENBQS9CLGdDQUFnQztBQUMxSCxJQUFJLGlCQUFpQjtBQUFDLEtBQUssZUFBZSxDQUFDLFVBQVU7QUFDckQsTUFBTSxhQUFhO0FBQUMsUUFBUSxhQUFhLENBQUMsYUFBYSxDQUFDLGlCQUFpQixDQUFDLHVCQUF1QjtBQUNqRyxJQUFJLGNBQWM7QUFBQyxJQUFJLFVBQVU7QUFBQyxPQUFPLGVBQWU7QUFBQyxJQUFJLGlCQUFpQjtBQUFDLGVBQWUsZUFBZTtBQUM3RyxrQkFBa0IsK0JBQStCLENBQUMsYUFBYTtBQUFDLEdBQUcsc0JBQXNCLENBQUMsUUFBUSxDQUFDLGdCQUFnQjtBQUNuSCw2QkFBNkIsWUFBWSxDQUFDLFFBQVE7QUFBQyxTQUFTLGdCQUFnQjtBQUM1RSxhQUFhLGdCQUFnQjtBQUFDLGNBQWMsbUJBQW1CO0FBQy9ELHFEQUFxRCx5QkFBeUI7QUFDOUUsMkhBQTJILGlCQUFpQixDQUFDLFNBQVM7QUFDdEosK0dBQStHLDZCQUE2QjtBQUM1SSxTQUFTLHdCQUF3QixDQUFDLFlBQVksQ0FBQywwQkFBMEI7QUFDekUsT0FBTyxhQUFhLENBQUMsYUFBYSxDQUFDLGNBQWMsQ0FBQyxTQUFTLENBQUMsa0JBQWtCO0FBQUMsU0FBUyxhQUFhO0FBQ3JHLDZCQUE2QixTQUFTO0FBQ3RDLGtGQUFrRixXQUFXO0FBQzdGLGNBQWMsNEJBQTRCLENBQUMsbUJBQW1CO0FBQzlELHFGQUFxRix1QkFBdUI7QUFDNUcsNEJBQTRCLGFBQWEsQ0FBQyxZQUFZO0FBQ3RELDZCQUE2Qix5QkFBeUIsQ0FBQyxZQUFZO0FBQ25FLGdCQUFnQjtBQUNoQixVQUFVLDhCQUE4QixDQUFDLGNBQWMsQ0FBQyxlQUFlO0FBQUMsS0FBSyxpQkFBaUI7QUFDOUYsR0FBRyxjQUFjO0FBQUMsR0FBRyxjQUFjO0FBQUMsR0FBRyxjQUFjO0FBQUMsR0FBRyxjQUFjO0FBQUMsR0FBRyxjQUFjO0FBQUMsR0FBRyxjQUFjO0FBQUMsVUFBVSxpQkFBaUI7QUFDdkksa0JBQWtCLHVDQUF1QyxDQUFDLGVBQWUsQ0FBQyxhQUFhO0FBQUMsU0FBUyxrQkFBa0I7QUFDbkgsR0FBRyxRQUFRLENBQUMseUJBQXlCLENBQUMsYUFBYTtBQUNuRCxVQUFVLGNBQWMsQ0FBQyxXQUFXO0FBQUMsSUFBSSxxQkFBcUI7QUFBQyxFQUFFLGFBQWE7QUFDOUUsd0JBQXdCLHdCQUF3QixDQUFDLGdCQUFnQixDQUFDLFVBQVUsQ0FBQyxhQUFhO0FBQUMsY0FBYyxxQkFBcUI7QUFDOUgsaUNBQWlDLDRCQUE0QjtBQUFDLHFDQUFxQyx3QkFBd0I7QUFDM0gsZ0NBQWdDLHFCQUFxQjtBQUFDLGlDQUFpQyx3QkFBd0I7QUFDL0csMERBQTBELHFCQUFxQjtBQUFDLHNDQUFzQyxpQkFBaUI7QUFDdkksNERBQTRELGVBQWUsQ0FBQyxrQkFBa0IsQ0FBQyxlQUFlLENBQUMsa0JBQWtCO0FBQ2pJLDRHQUE0RyxpQkFBaUI7QUFDN0gsbUJBQW1CLFdBQVcsQ0FBQyxvQkFBb0IsQ0FBQyxnQkFBZ0IsQ0FBQyxxQkFBcUIsQ0FBQyxlQUFlLENBQUMsb0JBQW9CLENBQUMsYUFBYSxDQUFDLHdCQUF3QixDQUFDLGlCQUFpQixDQUFDLGNBQWMsQ0FBQyxrQkFBa0I7QUFDMU4sY0FBYyxxRUFBcUU7QUFDbkYsbUJBQW1CLDBCQUEwQixDQUFDLHdCQUF3QixDQUF5QixxQkFBcUIsQ0FBQyxvQkFBb0IsQ0FBQyxnQkFBZ0I7QUFDMUosa0RBQWtELGtCQUFrQixDQUFDLFdBQVc7QUFBQywyQkFBMkIsbUJBQW1CO0FBQy9ILGlEQUFpRCxlQUFlO0FBQ2hFLGtCQUFrQixxQkFBcUIsQ0FBQyxVQUFVLENBQUMsb0JBQW9CLENBQUMsZ0JBQWdCLENBQUMsaUJBQWlCLENBQUMsaUJBQWlCO0FBQUMsVUFBVSxpQkFBaUI7QUFDeEosT0FBTyxvQkFBb0IsQ0FBQyxTQUFTLENBQUMsUUFBUTtBQUFDLFVBQVUsZ0JBQWdCLENBQUMsNEJBQTRCO0FBQUMscUJBQXFCLGtCQUFrQjtBQUM5SSxrQ0FBa0MsaUJBQWlCO0FBQUMscUJBQXFCLFlBQVk7QUFBQywyQkFBMkIsb0JBQW9CO0FBQ3JJLGtCQUFrQixXQUFXO0FBQUMsV0FBVyxxQkFBcUI7QUFDOUQsVUFBVSxXQUFXLENBQUMsYUFBYSxDQUFDLFdBQVcsQ0FBQyw0QkFBNEIsQ0FBQyxVQUFVO0FBQ3ZGLFdBQVcsYUFBYSxDQUFDLFVBQVUsQ0FBQyxXQUFXLENBQUMsNEJBQTRCO0FBQzVFLHNDQUFzQyxpQkFBaUIsQ0FBQyxvQkFBb0IsQ0FBQyxjQUFjO0FBQzNGLDhDQUE4QyxhQUFhO0FBQzNELHdEQUF3RCxxQkFBcUIsQ0FBQyxVQUFVO0FBQ3hGLG9HQUFvRyxxQkFBcUIsQ0FBQyxVQUFVO0FBQ3BJLHFCQUFxQixXQUFXLENBQUMsVUFBVSxDQUFDLHFCQUFxQixDQUFDLFlBQVksQ0FBQyxpQkFBaUIsQ0FBQyxlQUFlLENBQUMsUUFBUSxDQUFDLFNBQVMsQ0FBQyxTQUFTO0FBQzdJLG9CQUFvQixVQUFVLENBQUMsV0FBVyxDQUFDLGlCQUFpQixDQUFDLE9BQU87QUFDcEUsWUFBWSxXQUFXLENBQUMsV0FBVyxDQUFDLHFCQUFxQixDQUFDLHdCQUF3QixDQUFDLFNBQVMsQ0FBQyxhQUFhO0FBQzFHLGtFQUFrRSxVQUFVO0FBQzVFLDRHQUE0RyxjQUFjO0FBQzFILHdGQUF3RixVQUFVLENBQUMsZUFBZSxDQUFDLGdCQUFnQjtBQUNuSSxlQUFlLDBCQUEwQjtBQUN6QyxVQUFVLFNBQVMsQ0FBQyxZQUFZLENBQUMsaUJBQWlCLENBQUMsY0FBYyxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsVUFBVSxDQUFDLFdBQVcsQ0FBQyxhQUFhLENBQUMsMkJBQTJCLENBQUMsZ0NBQWdDO0FBQ2hMLGtCQUFrQixXQUFXLENBQUMscUJBQXFCLENBQUMsaUJBQWlCLENBQUMsU0FBUyxDQUFDLFNBQVMsQ0FBQyxXQUFXO0FBQ3JHLFFBQVEsVUFBVSxDQUFDLGVBQWU7QUFBQyxtQkFBbUIsb0JBQW9CLENBQUMsVUFBVTtBQUNyRixxQkFBcUIsZ0JBQWdCLENBQUMsVUFBVSxDQUFDLFVBQVUsQ0FBQyxXQUFXLENBQUMsYUFBYSxDQUFDLFNBQVM7QUFDL0Ysc0RBQXNELGVBQWUsQ0FBQyxVQUFVO0FBQ2hGLG1CQUFtQixrQkFBa0I7QUFDckMsMkJBQTJCLFVBQVUsQ0FBQyxhQUFhLENBQUMsZ0JBQWdCLENBQUMsZUFBZSxDQUFDLFdBQVcsQ0FBQyxrQkFBa0IsQ0FBQyxVQUFVLENBQUMsU0FBUztBQUN4SSxxQ0FBcUMsaUJBQWlCO0FBQUMsVUFBVSxhQUFhLENBQUMsVUFBVTtBQUN6RixlQUFlLGFBQWEsQ0FBQyxlQUFlO0FBQzVDO3FHQUNxRyxVQUFVLENBQUMsYUFBYSxDQUFDLFVBQVU7QUFDeEkscUVBQXFFLFVBQVUsQ0FBQyxVQUFVO0FBQzFGLFdBQVcsY0FBYztBQUFDLFdBQVcsZUFBZTtBQUFDLFdBQVcsZUFBZTtBQUFDLFdBQVcsZUFBZTtBQUMxRyxXQUFXLGVBQWU7QUFBQyxXQUFXLGVBQWU7QUFBQyxXQUFXLGVBQWU7QUFBQyxXQUFXLGVBQWU7QUFDM0csV0FBVyxlQUFlO0FBQUMsWUFBWSxlQUFlO0FBQUMsWUFBWSxlQUFlO0FBQUMsWUFBWSxlQUFlO0FBQzlHLHlCQUF5QixXQUFXLGNBQWMsQ0FBQyxXQUFXLGVBQWUsQ0FBQyx1QkFBdUIsZUFBZSxDQUFDLHFCQUFxQixlQUFlO0FBQ3pKLFdBQVcsZUFBZSxDQUFDLG9CQUFvQixlQUFlLENBQUMsV0FBVyxlQUFlLENBQUMsd0JBQXdCLGVBQWU7QUFDakksNEJBQTRCLGVBQWUsQ0FBQyxZQUFZLGVBQWUsQ0FBQyxZQUFZLGVBQWUsQ0FBQyxZQUFZLGVBQWUsQ0FBQztBQUNoSSx5QkFBeUIsV0FBVyxjQUFjLENBQUMsV0FBVyxlQUFlLENBQUMsV0FBVyxlQUFlLENBQUMsV0FBVyxlQUFlO0FBQ25JLFdBQVcsZUFBZSxDQUFDLFdBQVcsZUFBZSxDQUFDLFdBQVcsZUFBZSxDQUFDLFdBQVcsZUFBZTtBQUMzRyxXQUFXLGVBQWUsQ0FBQyxZQUFZLGVBQWUsQ0FBQyxZQUFZLGVBQWUsQ0FBQyxZQUFZLGVBQWUsQ0FBQztBQUMvRyxTQUFTLGVBQWU7QUFBQyxZQUFZLGlCQUFpQixDQUFDLGtCQUFrQjtBQUN6RSxxQkFBcUIsZ0JBQWdCLENBQUMsaUJBQWlCO0FBQUMsWUFBWSxlQUFlO0FBQUMsU0FBUyxnQkFBZ0I7QUFDN0csYUFBYSxhQUFhLENBQUMsVUFBVTtBQUFDLFNBQVMsa0JBQWtCO0FBQ2pFLGFBQWEsa0JBQWtCO0FBQUMsZ0JBQWdCLHFCQUFxQjtBQUFDLGdCQUFnQixxQkFBcUI7QUFDM0csU0FBUyxzQkFBc0I7QUFBQyx3QkFBd0IsdUJBQXVCO0FBQUMsc0JBQXNCLDhCQUE4QjtBQUNwSSwwQkFBMEIsU0FBUyxhQUFhLENBQUM7QUFDakQseUJBQXlCLGtCQUFrQixhQUFhLENBQUMsb0JBQW9CLENBQUMsVUFBVSxnQkFBZ0I7QUFDeEcsb0dBQW9HLGlCQUFpQjtBQUNySCxlQUFlLHNCQUFzQixDQUFDLFdBQVcsYUFBYSxDQUFDLG9CQUFvQixDQUFDLGlGQUFpRixpQkFBaUI7QUFDdEwsb05BQW9OLFVBQVUsQ0FBQztBQUMvTix5QkFBeUIsa0JBQWtCLFdBQVcsQ0FBQyxVQUFVLGdCQUFnQixDQUFDO0FBQ2xGLHlCQUF5QixrQkFBa0IsV0FBVyxDQUFDLGVBQWUsc0JBQXNCLENBQUMsd0JBQXdCLHVCQUF1QixDQUFDO0FBQzdJLCtDQUErQyxnQkFBZ0Isc0JBQXNCLENBQUM7QUFDdEYseUJBQXlCLHdCQUF3QixZQUFZLENBQUMsU0FBUyx1QkFBdUIsQ0FBQyx3QkFBd0IsQ0FBQyxTQUFTLGNBQWMsQ0FBQztBQUNoSixtQkFBbUIsY0FBYyxDQUFDLFVBQVUsQ0FBQyxTQUFTO0FBQUMsUUFBUSxLQUFLO0FBQUMsV0FBVyxRQUFRO0FBQ3hGLFlBQVksY0FBYyxDQUFDLFlBQVksQ0FBQyxVQUFVLENBQUMsV0FBVyxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLFFBQVEsQ0FBQyxnQ0FBZ0MsQ0FBQyxTQUFTO0FBQ3ZJLG9CQUFvQixpQkFBaUIsQ0FBQyxNQUFNLENBQUMsS0FBSztBQUFDLHFCQUFxQixpQkFBaUIsQ0FBQyxPQUFPLENBQUMsS0FBSztBQUN2Ryx1QkFBdUIsaUJBQWlCLENBQUMsTUFBTSxDQUFDLFFBQVE7QUFBQyx3QkFBd0IsaUJBQWlCLENBQUMsT0FBTyxDQUFDLFFBQVE7QUFDbkgsbUJBQW1CLGlCQUFpQixDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUMsc0NBQThCLENBQTlCLDhCQUE4QixDQUFDLGtDQUFrQztBQUN2SCxpQkFBaUIsaUJBQWlCLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxvQ0FBNEIsQ0FBNUIsNEJBQTRCLENBQUMsaUNBQWlDO0FBQ2pILGtCQUFrQixpQkFBaUIsQ0FBQyxPQUFPLENBQUMsUUFBUSxDQUFDLG9DQUE0QixDQUE1Qiw0QkFBNEIsQ0FBQyxnQ0FBZ0M7QUFDbEgsc0JBQXNCLGlCQUFpQixDQUFDLFFBQVEsQ0FBQyxLQUFLLENBQUMsb0NBQTRCLENBQTVCLDRCQUE0QixDQUFDLGdDQUFnQztBQUNwSCx5QkFBeUIsaUJBQWlCLENBQUMsUUFBUSxDQUFDLFFBQVEsQ0FBQyxvQ0FBNEIsQ0FBNUIsNEJBQTRCLENBQUMsZ0NBQWdDO0FBQzFILDhDQUE4QyxhQUFhO0FBQUMsa0RBQWtELG9CQUFvQjtBQUFDLGtCQUFrQixZQUFZO0FBQ2pLLHFCQUFxQixpQkFBaUI7QUFDdEMsV0FBVyxpQkFBaUI7QUFDNUIsZ0JBQWdCLGlCQUFpQjtBQUFDLDJCQUEyQixpQkFBaUI7QUFBQyxnQkFBZ0IsaUJBQWlCO0FBQUMsaUJBQWlCLGtCQUFrQjtBQUFDLGtCQUFrQixrQkFBa0I7QUFDekwscUxBQXFMLGFBQWE7QUFDbE0sd0JBQXdCLFlBQVk7QUFBQyxVQUFVLGVBQWUsQ0FBQyxrQkFBa0I7QUFDakYsc0JBQXNCLGtDQUFrQyxDQUFDLGNBQWM7QUFDdkUsU0FBUyxVQUFVLENBQUMscUJBQXFCLENBQUMsZ0JBQWdCLENBQUMsNkJBQTZCLENBQUMsb0JBQW9CO0FBQzdHLGFBQWEsYUFBYSxDQUFDLHdCQUF3QixDQUFDLGdCQUFnQixDQUFDLGlCQUFpQixDQUFDLGNBQWM7QUFDckcsb0JBQW9CLHFFQUFxRTtBQUN6RixrQ0FBa0MscUVBQXFFO0FBQ3ZHLFNBQVMsNENBQW1DLENBQW5DLG9DQUFvQztBQUFDLDJCQUFtQixHQUFHLDhCQUFxQixDQUFyQixzQkFBc0IsQ0FBQyxLQUFLLGdDQUF1QixDQUF2Qix3QkFBd0IsQ0FBQztBQUEzRSxtQkFBbUIsR0FBRyw4QkFBcUIsQ0FBckIsc0JBQXNCLENBQUMsS0FBSyxnQ0FBdUIsQ0FBdkIsd0JBQXdCLENBQUM7QUFDekgsbUJBQW1CLHFDQUE0QixDQUE1Qiw2QkFBNkI7QUFBQywwQkFBa0IsR0FBRyxTQUFTLENBQUMsSUFBSSxTQUFTLENBQUMsS0FBSyxTQUFTLENBQUM7QUFBNUQsa0JBQWtCLEdBQUcsU0FBUyxDQUFDLElBQUksU0FBUyxDQUFDLEtBQUssU0FBUyxDQUFDO0FBQzdHLG9CQUFvQiwyQkFBa0IsQ0FBbEIsbUJBQW1CO0FBQUMsd0JBQWdCLEtBQUssU0FBUyxFQUFFLEdBQUcsU0FBUyxDQUFDO0FBQTdDLGdCQUFnQixLQUFLLFNBQVMsRUFBRSxHQUFHLFNBQVMsQ0FBQztBQUNyRixnQkFBZ0IsaUJBQWlCLENBQUMsaUNBQXdCLENBQXhCLHlCQUF5QjtBQUFDLDhCQUFzQixLQUFLLFVBQVUsQ0FBQyxTQUFTLEVBQUUsR0FBRyxLQUFLLENBQUMsU0FBUyxDQUFDO0FBQXBFLHNCQUFzQixLQUFLLFVBQVUsQ0FBQyxTQUFTLEVBQUUsR0FBRyxLQUFLLENBQUMsU0FBUyxDQUFDO0FBQ2hJLGlCQUFpQixpQkFBaUIsQ0FBQyxrQ0FBeUIsQ0FBekIsMEJBQTBCO0FBQUMsK0JBQXVCLEtBQUssV0FBVyxDQUFDLFNBQVMsRUFBRSxHQUFHLE1BQU0sQ0FBQyxTQUFTLENBQUM7QUFBdkUsdUJBQXVCLEtBQUssV0FBVyxDQUFDLFNBQVMsRUFBRSxHQUFHLE1BQU0sQ0FBQyxTQUFTLENBQUM7QUFDckksa0JBQWtCLGlCQUFpQixDQUFDLG1DQUEwQixDQUExQiwyQkFBMkI7QUFBQyxnQ0FBd0IsS0FBSyxZQUFZLENBQUMsU0FBUyxFQUFFLEdBQUcsT0FBTyxDQUFDLFNBQVMsQ0FBQztBQUExRSx3QkFBd0IsS0FBSyxZQUFZLENBQUMsU0FBUyxFQUFFLEdBQUcsT0FBTyxDQUFDLFNBQVMsQ0FBQztBQUMxSSxtQkFBbUIsaUJBQWlCLENBQUMsb0NBQTJCLENBQTNCLDRCQUE0QjtBQUFDLGlDQUF5QixLQUFLLGFBQWEsQ0FBQyxTQUFTLEVBQUUsR0FBRyxRQUFRLENBQUMsU0FBUyxDQUFDO0FBQTdFLHlCQUF5QixLQUFLLGFBQWEsQ0FBQyxTQUFTLEVBQUUsR0FBRyxRQUFRLENBQUMsU0FBUyxDQUFDO0FBQy9JLGtCQUFrQixrQ0FBeUIsQ0FBekIsMEJBQTBCO0FBQUMsK0JBQXVCLEtBQUssMEJBQWlCLENBQWpCLGtCQUFrQixFQUFFLEdBQUcsMEJBQWlCLENBQWpCLGtCQUFrQixDQUFDO0FBQXRFLHVCQUF1QixLQUFLLDBCQUFpQixDQUFqQixrQkFBa0IsRUFBRSxHQUFHLDBCQUFpQixDQUFqQixrQkFBa0IsQ0FBQztBQUNuSCxrQkFBa0IsaUNBQWlDO0FBQUMsd0JBQXdCLG9CQUFvQjtBQUNoRyxvQ0FBb0MsWUFBWTtBQUFDLDRDQUE0QyxTQUFTO0FBQ3RHLGdCQUFnQixZQUFZO0FBQUMsZ0JBQWdCLFlBQVk7QUFDekQsd0ZBQXdGLDhCQUFxQixDQUFyQixzQkFBc0I7QUFDOUcsNEJBQTRCLDZCQUFvQixDQUFwQixxQkFBcUI7QUFBQyxvQ0FBb0MsNkJBQW9CLENBQXBCLHFCQUFxQjtBQUMzRyxVQUFVLHlCQUFnQixDQUFoQixpQkFBaUI7QUFBQyxvQ0FBb0MsMEJBQWlCLENBQWpCLGtCQUFrQjtBQUFDLGNBQWMseUJBQWdCLENBQWhCLGlCQUFpQjtBQUNsSCxTQUFTLHdCQUF3QjtBQUFDLFVBQVUsd0JBQXdCO0FBQUMsV0FBVyx3QkFBd0I7QUFBQyxVQUFVLHdCQUF3QjtBQUMzSSxXQUFXLHdCQUF3QjtBQUFDLFlBQVksd0JBQXdCO0FBQUMsYUFBYSx3QkFBd0I7QUFBQyxVQUFVLHdCQUF3QjtBQUNqSixlQUFlLHlCQUF5QjtBQUFDLGdCQUFnQiwwQkFBMEI7QUFBQyxZQUFZLDRCQUE0QjtBQUFDLFdBQVcsMkJBQTJCO0FBQ25LLGFBQWEsa0JBQWtCO0FBQUMsV0FBVywrQkFBK0I7QUFDMUUsZUFBZSxtQ0FBbUM7QUFBQyxrQkFBa0Isc0NBQXNDO0FBQzNHLGdCQUFnQixvQ0FBb0M7QUFBQyxpQkFBaUIscUNBQXFDO0FBQzNHLFdBQVcsbUNBQW1DO0FBQUMsY0FBYyxzQ0FBc0M7QUFDbkcsWUFBWSxvQ0FBb0M7QUFBQyxhQUFhLHFDQUFxQztBQUNuRyxxQkFBcUIseUJBQXlCLENBQUMsNEJBQTRCO0FBQzNFLFdBQVcscUJBQXFCO0FBQUMsZUFBZSx5QkFBeUI7QUFBQyxrQkFBa0IsNEJBQTRCO0FBQ3hILGdCQUFnQiwwQkFBMEI7QUFBQyxpQkFBaUIsMkJBQTJCO0FBQ3ZGLGtCQUFrQix5QkFBeUI7QUFBQyxZQUFZLDBCQUEwQjtBQUFDLGtCQUFrQiwyQkFBMkI7QUFDaEksZUFBZSwwQkFBMEIsQ0FBQyw2QkFBNkI7QUFBQyxlQUFlLDBCQUEwQixDQUFDLDZCQUE2QjtBQUMvSSxlQUFlLDBCQUEwQixDQUFDLDZCQUE2QjtBQUFDLGVBQWUsMEJBQTBCLENBQUMsNkJBQTZCO0FBQy9JLGVBQWUsMEJBQTBCLENBQUMsNkJBQTZCO0FBQ3ZFLFNBQVMsb0JBQW9CO0FBQUMsVUFBVSxxQkFBcUI7QUFDN0QsaUJBQWlCLG9CQUFvQixDQUFDLCtCQUErQjtBQUNyRSxxQ0FBcUMsc0NBQXNDO0FBQzNFLHFCQUFxQix5QkFBeUI7QUFDOUMsV0FBVztBQUNYLGdDQUFnQyxvQkFBb0IsQ0FBQyxrQ0FBa0M7QUFDdkYsOEJBQThCLG9CQUFvQixDQUFDLGtDQUFrQztBQUNyRiw4QkFBOEIsb0JBQW9CLENBQUMsa0NBQWtDO0FBQ3JGLDBDQUEwQyxvQkFBb0IsQ0FBQyxrQ0FBa0M7QUFDakcsZ0NBQWdDLG9CQUFvQixDQUFDLGtDQUFrQztBQUN2Riw4QkFBOEIsb0JBQW9CLENBQUMsa0NBQWtDO0FBQ3JGLGdGQUFnRixvQkFBb0IsQ0FBQyxrQ0FBa0M7QUFDdkksZ0NBQWdDLG9CQUFvQixDQUFDLGtDQUFrQztBQUN2Riw0Q0FBNEMsb0JBQW9CLENBQUMsa0NBQWtDO0FBQ25HLGtDQUFrQyxvQkFBb0IsQ0FBQyxrQ0FBa0M7QUFDekYsZ0NBQWdDLG9CQUFvQixDQUFDLGtDQUFrQztBQUN2Riw4QkFBOEIsb0JBQW9CLENBQUMsa0NBQWtDO0FBQ3JGLGtDQUFrQyxvQkFBb0IsQ0FBQyxrQ0FBa0M7QUFDekYsNENBQTRDLG9CQUFvQixDQUFDLGtDQUFrQztBQUNuRyw4QkFBOEIsb0JBQW9CLENBQUMsa0NBQWtDO0FBQ3JGLGtDQUFrQyxvQkFBb0IsQ0FBQyxrQ0FBa0M7QUFDekYsNENBQTRDLG9CQUFvQixDQUFDLGtDQUFrQztBQUNuRyw0QkFBNEIsb0JBQW9CLENBQUMsa0NBQWtDO0FBQ25GLDhCQUE4QixvQkFBb0IsQ0FBQyxrQ0FBa0M7QUFDckYsOEJBQThCLG9CQUFvQixDQUFDLGtDQUFrQztBQUNyRixrQ0FBa0Msb0JBQW9CLENBQUMsa0NBQWtDO0FBQ3pGLGdDQUFnQyxvQkFBb0IsQ0FBQywrQkFBK0I7QUFDcEYsZ0NBQWdDLG9CQUFvQixDQUFDLCtCQUErQjtBQUNwRiw0REFBNEQsb0JBQW9CLENBQUMsa0NBQWtDO0FBQ25ILG9GQUFvRixvQkFBb0IsQ0FBQyxrQ0FBa0M7QUFDM0ksZ0ZBQWdGLG9CQUFvQixDQUFDLGtDQUFrQztBQUN2SSxzQ0FBc0Msb0JBQW9CLENBQUMsa0NBQWtDO0FBQzdGLDBDQUEwQyxvQkFBb0IsQ0FBQyxrQ0FBa0M7QUFDakcsNENBQTRDLG9CQUFvQixDQUFDLGtDQUFrQztBQUNuRyx3Q0FBd0Msb0JBQW9CLENBQUMsa0NBQWtDO0FBQy9GLDBDQUEwQyx1QkFBdUI7QUFDakUsd0NBQXdDLHVCQUF1QjtBQUMvRCx3Q0FBd0MsdUJBQXVCO0FBQy9ELG9EQUFvRCx1QkFBdUI7QUFDM0UsMENBQTBDLHVCQUF1QjtBQUNqRSx3Q0FBd0MsdUJBQXVCO0FBQy9ELG9HQUFvRyx1QkFBdUI7QUFDM0gsMENBQTBDLHVCQUF1QjtBQUNqRSxzREFBc0QsdUJBQXVCO0FBQzdFLDRDQUE0Qyx1QkFBdUI7QUFDbkUsMENBQTBDLHVCQUF1QjtBQUNqRSx3Q0FBd0MsdUJBQXVCO0FBQy9ELDRDQUE0Qyx1QkFBdUI7QUFDbkUsc0RBQXNELHVCQUF1QjtBQUM3RSx3Q0FBd0MsdUJBQXVCO0FBQy9ELDRDQUE0Qyx1QkFBdUI7QUFDbkUsc0RBQXNELHVCQUF1QjtBQUM3RSxzQ0FBc0MsdUJBQXVCO0FBQzdELHdDQUF3Qyx1QkFBdUI7QUFDL0Qsd0NBQXdDLHVCQUF1QjtBQUMvRCw0Q0FBNEMsdUJBQXVCO0FBQ25FLDBDQUEwQyxvQkFBb0I7QUFDOUQsMENBQTBDLG9CQUFvQjtBQUM5RCxnRkFBZ0YsdUJBQXVCO0FBQ3ZHLHdHQUF3Ryx1QkFBdUI7QUFDL0gsb0dBQW9HLHVCQUF1QjtBQUMzSCw4Q0FBOEMsOEJBQThCO0FBQzVFLDRDQUE0Qyw4QkFBOEI7QUFDMUUsNENBQTRDLDhCQUE4QjtBQUMxRSx3REFBd0QsOEJBQThCO0FBQ3RGLDhDQUE4Qyw4QkFBOEI7QUFDNUUsNENBQTRDLDhCQUE4QjtBQUMxRSw0R0FBNEcsOEJBQThCO0FBQzFJLDhDQUE4Qyw4QkFBOEI7QUFDNUUsMERBQTBELDhCQUE4QjtBQUN4RixnREFBZ0QsOEJBQThCO0FBQzlFLDhDQUE4Qyw4QkFBOEI7QUFDNUUsNENBQTRDLDhCQUE4QjtBQUMxRSxnREFBZ0QsOEJBQThCO0FBQzlFLDBEQUEwRCw4QkFBOEI7QUFDeEYsNENBQTRDLDhCQUE4QjtBQUMxRSxnREFBZ0QsOEJBQThCO0FBQzlFLDBEQUEwRCw4QkFBOEI7QUFDeEYsMENBQTBDLDhCQUE4QjtBQUN4RSw0Q0FBNEMsOEJBQThCO0FBQzFFLDRDQUE0Qyw4QkFBOEI7QUFDMUUsZ0RBQWdELDhCQUE4QjtBQUM5RSw4Q0FBOEMsMkJBQTJCO0FBQ3pFLDhDQUE4QywyQkFBMkI7QUFDekUsd0ZBQXdGLDhCQUE4QjtBQUN0SCxnSEFBZ0gsOEJBQThCO0FBQzlJLDRHQUE0Ryw4QkFBOEI7QUFDMUksb0RBQW9ELDhCQUE4QjtBQUFDLHdEQUF3RCw4QkFBOEI7QUFDekssMERBQTBELDhCQUE4QjtBQUFDLHNEQUFzRCw4QkFBOEIiLCJmaWxlIjoic3JjL2FwcC9ob21lLWxpc3QvaG9tZS1saXN0LmNvbXBvbmVudC5jc3MiLCJzb3VyY2VzQ29udGVudCI6WyJcclxuXHJcblxyXG4vKiBXMy5DU1MgNC4xMiBOb3ZlbWJlciAyMDE4IGJ5IEphbiBFZ2lsIGFuZCBCb3JnZSBSZWZzbmVzICovXHJcbmh0bWx7Ym94LXNpemluZzpib3JkZXItYm94fSosKjpiZWZvcmUsKjphZnRlcntib3gtc2l6aW5nOmluaGVyaXR9XHJcbi8qIEV4dHJhY3QgZnJvbSBub3JtYWxpemUuY3NzIGJ5IE5pY29sYXMgR2FsbGFnaGVyIGFuZCBKb25hdGhhbiBOZWFsIGdpdC5pby9ub3JtYWxpemUgKi9cclxuaHRtbHstbXMtdGV4dC1zaXplLWFkanVzdDoxMDAlOy13ZWJraXQtdGV4dC1zaXplLWFkanVzdDoxMDAlfWJvZHl7bWFyZ2luOjB9XHJcbmFydGljbGUsYXNpZGUsZGV0YWlscyxmaWdjYXB0aW9uLGZpZ3VyZSxmb290ZXIsaGVhZGVyLG1haW4sbWVudSxuYXYsc2VjdGlvbixzdW1tYXJ5e2Rpc3BsYXk6YmxvY2t9XHJcbmF1ZGlvLGNhbnZhcyxwcm9ncmVzcyx2aWRlb3tkaXNwbGF5OmlubGluZS1ibG9ja31wcm9ncmVzc3t2ZXJ0aWNhbC1hbGlnbjpiYXNlbGluZX1cclxuYXVkaW86bm90KFtjb250cm9sc10pe2Rpc3BsYXk6bm9uZTtoZWlnaHQ6MH1baGlkZGVuXSx0ZW1wbGF0ZXtkaXNwbGF5Om5vbmV9XHJcbmF7YmFja2dyb3VuZC1jb2xvcjp0cmFuc3BhcmVudDstd2Via2l0LXRleHQtZGVjb3JhdGlvbi1za2lwOm9iamVjdHN9XHJcbmE6YWN0aXZlLGE6aG92ZXJ7b3V0bGluZS13aWR0aDowfWFiYnJbdGl0bGVde2JvcmRlci1ib3R0b206bm9uZTt0ZXh0LWRlY29yYXRpb246dW5kZXJsaW5lO3RleHQtZGVjb3JhdGlvbjp1bmRlcmxpbmUgZG90dGVkfVxyXG5kZm57Zm9udC1zdHlsZTppdGFsaWN9bWFya3tiYWNrZ3JvdW5kOiNmZjA7Y29sb3I6IzAwMH1cclxuc21hbGx7Zm9udC1zaXplOjgwJX1zdWIsc3Vwe2ZvbnQtc2l6ZTo3NSU7bGluZS1oZWlnaHQ6MDtwb3NpdGlvbjpyZWxhdGl2ZTt2ZXJ0aWNhbC1hbGlnbjpiYXNlbGluZX1cclxuc3Vie2JvdHRvbTotMC4yNWVtfXN1cHt0b3A6LTAuNWVtfWZpZ3VyZXttYXJnaW46MWVtIDQwcHh9aW1ne2JvcmRlci1zdHlsZTpub25lfXN2Zzpub3QoOnJvb3Qpe292ZXJmbG93OmhpZGRlbn1cclxuY29kZSxrYmQscHJlLHNhbXB7Zm9udC1mYW1pbHk6bW9ub3NwYWNlLG1vbm9zcGFjZTtmb250LXNpemU6MWVtfWhye2JveC1zaXppbmc6Y29udGVudC1ib3g7aGVpZ2h0OjA7b3ZlcmZsb3c6dmlzaWJsZX1cclxuYnV0dG9uLGlucHV0LHNlbGVjdCx0ZXh0YXJlYXtmb250OmluaGVyaXQ7bWFyZ2luOjB9b3B0Z3JvdXB7Zm9udC13ZWlnaHQ6Ym9sZH1cclxuYnV0dG9uLGlucHV0e292ZXJmbG93OnZpc2libGV9YnV0dG9uLHNlbGVjdHt0ZXh0LXRyYW5zZm9ybTpub25lfVxyXG5idXR0b24saHRtbCBbdHlwZT1idXR0b25dLFt0eXBlPXJlc2V0XSxbdHlwZT1zdWJtaXRdey13ZWJraXQtYXBwZWFyYW5jZTpidXR0b259XHJcbmJ1dHRvbjo6LW1vei1mb2N1cy1pbm5lciwgW3R5cGU9YnV0dG9uXTo6LW1vei1mb2N1cy1pbm5lciwgW3R5cGU9cmVzZXRdOjotbW96LWZvY3VzLWlubmVyLCBbdHlwZT1zdWJtaXRdOjotbW96LWZvY3VzLWlubmVye2JvcmRlci1zdHlsZTpub25lO3BhZGRpbmc6MH1cclxuYnV0dG9uOi1tb3otZm9jdXNyaW5nLCBbdHlwZT1idXR0b25dOi1tb3otZm9jdXNyaW5nLCBbdHlwZT1yZXNldF06LW1vei1mb2N1c3JpbmcsIFt0eXBlPXN1Ym1pdF06LW1vei1mb2N1c3Jpbmd7b3V0bGluZToxcHggZG90dGVkIEJ1dHRvblRleHR9XHJcbmZpZWxkc2V0e2JvcmRlcjoxcHggc29saWQgI2MwYzBjMDttYXJnaW46MCAycHg7cGFkZGluZzouMzVlbSAuNjI1ZW0gLjc1ZW19XHJcbmxlZ2VuZHtjb2xvcjppbmhlcml0O2Rpc3BsYXk6dGFibGU7bWF4LXdpZHRoOjEwMCU7cGFkZGluZzowO3doaXRlLXNwYWNlOm5vcm1hbH10ZXh0YXJlYXtvdmVyZmxvdzphdXRvfVxyXG5bdHlwZT1jaGVja2JveF0sW3R5cGU9cmFkaW9de3BhZGRpbmc6MH1cclxuW3R5cGU9bnVtYmVyXTo6LXdlYmtpdC1pbm5lci1zcGluLWJ1dHRvbixbdHlwZT1udW1iZXJdOjotd2Via2l0LW91dGVyLXNwaW4tYnV0dG9ue2hlaWdodDphdXRvfVxyXG5bdHlwZT1zZWFyY2hdey13ZWJraXQtYXBwZWFyYW5jZTp0ZXh0ZmllbGQ7b3V0bGluZS1vZmZzZXQ6LTJweH1cclxuW3R5cGU9c2VhcmNoXTo6LXdlYmtpdC1zZWFyY2gtY2FuY2VsLWJ1dHRvbixbdHlwZT1zZWFyY2hdOjotd2Via2l0LXNlYXJjaC1kZWNvcmF0aW9uey13ZWJraXQtYXBwZWFyYW5jZTpub25lfVxyXG46Oi13ZWJraXQtaW5wdXQtcGxhY2Vob2xkZXJ7Y29sb3I6aW5oZXJpdDtvcGFjaXR5OjAuNTR9XHJcbjo6LXdlYmtpdC1maWxlLXVwbG9hZC1idXR0b257LXdlYmtpdC1hcHBlYXJhbmNlOmJ1dHRvbjtmb250OmluaGVyaXR9XHJcbi8qIEVuZCBleHRyYWN0ICovXHJcbmh0bWwsYm9keXtmb250LWZhbWlseTpWZXJkYW5hLHNhbnMtc2VyaWY7Zm9udC1zaXplOjE1cHg7bGluZS1oZWlnaHQ6MS41fWh0bWx7b3ZlcmZsb3cteDpoaWRkZW59XHJcbmgxe2ZvbnQtc2l6ZTozNnB4fWgye2ZvbnQtc2l6ZTozMHB4fWgze2ZvbnQtc2l6ZToyNHB4fWg0e2ZvbnQtc2l6ZToyMHB4fWg1e2ZvbnQtc2l6ZToxOHB4fWg2e2ZvbnQtc2l6ZToxNnB4fS53My1zZXJpZntmb250LWZhbWlseTpzZXJpZn1cclxuaDEsaDIsaDMsaDQsaDUsaDZ7Zm9udC1mYW1pbHk6XCJTZWdvZSBVSVwiLEFyaWFsLHNhbnMtc2VyaWY7Zm9udC13ZWlnaHQ6NDAwO21hcmdpbjoxMHB4IDB9LnczLXdpZGV7bGV0dGVyLXNwYWNpbmc6NHB4fVxyXG5ocntib3JkZXI6MDtib3JkZXItdG9wOjFweCBzb2xpZCAjZWVlO21hcmdpbjoyMHB4IDB9XHJcbi53My1pbWFnZXttYXgtd2lkdGg6MTAwJTtoZWlnaHQ6YXV0b31pbWd7dmVydGljYWwtYWxpZ246bWlkZGxlfWF7Y29sb3I6aW5oZXJpdH1cclxuLnczLXRhYmxlLC53My10YWJsZS1hbGx7Ym9yZGVyLWNvbGxhcHNlOmNvbGxhcHNlO2JvcmRlci1zcGFjaW5nOjA7d2lkdGg6MTAwJTtkaXNwbGF5OnRhYmxlfS53My10YWJsZS1hbGx7Ym9yZGVyOjFweCBzb2xpZCAjY2NjfVxyXG4udzMtYm9yZGVyZWQgdHIsLnczLXRhYmxlLWFsbCB0cntib3JkZXItYm90dG9tOjFweCBzb2xpZCAjZGRkfS53My1zdHJpcGVkIHRib2R5IHRyOm50aC1jaGlsZChldmVuKXtiYWNrZ3JvdW5kLWNvbG9yOiNmMWYxZjF9XHJcbi53My10YWJsZS1hbGwgdHI6bnRoLWNoaWxkKG9kZCl7YmFja2dyb3VuZC1jb2xvcjojZmZmfS53My10YWJsZS1hbGwgdHI6bnRoLWNoaWxkKGV2ZW4pe2JhY2tncm91bmQtY29sb3I6I2YxZjFmMX1cclxuLnczLWhvdmVyYWJsZSB0Ym9keSB0cjpob3ZlciwudzMtdWwudzMtaG92ZXJhYmxlIGxpOmhvdmVye2JhY2tncm91bmQtY29sb3I6I2NjY30udzMtY2VudGVyZWQgdHIgdGgsLnczLWNlbnRlcmVkIHRyIHRke3RleHQtYWxpZ246Y2VudGVyfVxyXG4udzMtdGFibGUgdGQsLnczLXRhYmxlIHRoLC53My10YWJsZS1hbGwgdGQsLnczLXRhYmxlLWFsbCB0aHtwYWRkaW5nOjhweCA4cHg7ZGlzcGxheTp0YWJsZS1jZWxsO3RleHQtYWxpZ246bGVmdDt2ZXJ0aWNhbC1hbGlnbjp0b3B9XHJcbi53My10YWJsZSB0aDpmaXJzdC1jaGlsZCwudzMtdGFibGUgdGQ6Zmlyc3QtY2hpbGQsLnczLXRhYmxlLWFsbCB0aDpmaXJzdC1jaGlsZCwudzMtdGFibGUtYWxsIHRkOmZpcnN0LWNoaWxke3BhZGRpbmctbGVmdDoxNnB4fVxyXG4udzMtYnRuLC53My1idXR0b257Ym9yZGVyOm5vbmU7ZGlzcGxheTppbmxpbmUtYmxvY2s7cGFkZGluZzo4cHggMTZweDt2ZXJ0aWNhbC1hbGlnbjptaWRkbGU7b3ZlcmZsb3c6aGlkZGVuO3RleHQtZGVjb3JhdGlvbjpub25lO2NvbG9yOmluaGVyaXQ7YmFja2dyb3VuZC1jb2xvcjppbmhlcml0O3RleHQtYWxpZ246Y2VudGVyO2N1cnNvcjpwb2ludGVyO3doaXRlLXNwYWNlOm5vd3JhcH1cclxuLnczLWJ0bjpob3Zlcntib3gtc2hhZG93OjAgOHB4IDE2cHggMCByZ2JhKDAsMCwwLDAuMiksMCA2cHggMjBweCAwIHJnYmEoMCwwLDAsMC4xOSl9XHJcbi53My1idG4sLnczLWJ1dHRvbnstd2Via2l0LXRvdWNoLWNhbGxvdXQ6bm9uZTstd2Via2l0LXVzZXItc2VsZWN0Om5vbmU7LWtodG1sLXVzZXItc2VsZWN0Om5vbmU7LW1vei11c2VyLXNlbGVjdDpub25lOy1tcy11c2VyLXNlbGVjdDpub25lO3VzZXItc2VsZWN0Om5vbmV9ICAgXHJcbi53My1kaXNhYmxlZCwudzMtYnRuOmRpc2FibGVkLC53My1idXR0b246ZGlzYWJsZWR7Y3Vyc29yOm5vdC1hbGxvd2VkO29wYWNpdHk6MC4zfS53My1kaXNhYmxlZCAqLDpkaXNhYmxlZCAqe3BvaW50ZXItZXZlbnRzOm5vbmV9XHJcbi53My1idG4udzMtZGlzYWJsZWQ6aG92ZXIsLnczLWJ0bjpkaXNhYmxlZDpob3Zlcntib3gtc2hhZG93Om5vbmV9XHJcbi53My1iYWRnZSwudzMtdGFne2JhY2tncm91bmQtY29sb3I6IzAwMDtjb2xvcjojZmZmO2Rpc3BsYXk6aW5saW5lLWJsb2NrO3BhZGRpbmctbGVmdDo4cHg7cGFkZGluZy1yaWdodDo4cHg7dGV4dC1hbGlnbjpjZW50ZXJ9LnczLWJhZGdle2JvcmRlci1yYWRpdXM6NTAlfVxyXG4udzMtdWx7bGlzdC1zdHlsZS10eXBlOm5vbmU7cGFkZGluZzowO21hcmdpbjowfS53My11bCBsaXtwYWRkaW5nOjhweCAxNnB4O2JvcmRlci1ib3R0b206MXB4IHNvbGlkICNkZGR9LnczLXVsIGxpOmxhc3QtY2hpbGR7Ym9yZGVyLWJvdHRvbTpub25lfVxyXG4udzMtdG9vbHRpcCwudzMtZGlzcGxheS1jb250YWluZXJ7cG9zaXRpb246cmVsYXRpdmV9LnczLXRvb2x0aXAgLnczLXRleHR7ZGlzcGxheTpub25lfS53My10b29sdGlwOmhvdmVyIC53My10ZXh0e2Rpc3BsYXk6aW5saW5lLWJsb2NrfVxyXG4udzMtcmlwcGxlOmFjdGl2ZXtvcGFjaXR5OjAuNX0udzMtcmlwcGxle3RyYW5zaXRpb246b3BhY2l0eSAwc31cclxuLnczLWlucHV0e3BhZGRpbmc6OHB4O2Rpc3BsYXk6YmxvY2s7Ym9yZGVyOm5vbmU7Ym9yZGVyLWJvdHRvbToxcHggc29saWQgI2NjYzt3aWR0aDoxMDAlfVxyXG4udzMtc2VsZWN0e3BhZGRpbmc6OXB4IDA7d2lkdGg6MTAwJTtib3JkZXI6bm9uZTtib3JkZXItYm90dG9tOjFweCBzb2xpZCAjY2NjfVxyXG4udzMtZHJvcGRvd24tY2xpY2ssLnczLWRyb3Bkb3duLWhvdmVye3Bvc2l0aW9uOnJlbGF0aXZlO2Rpc3BsYXk6aW5saW5lLWJsb2NrO2N1cnNvcjpwb2ludGVyfVxyXG4udzMtZHJvcGRvd24taG92ZXI6aG92ZXIgLnczLWRyb3Bkb3duLWNvbnRlbnR7ZGlzcGxheTpibG9ja31cclxuLnczLWRyb3Bkb3duLWhvdmVyOmZpcnN0LWNoaWxkLC53My1kcm9wZG93bi1jbGljazpob3ZlcntiYWNrZ3JvdW5kLWNvbG9yOiNjY2M7Y29sb3I6IzAwMH1cclxuLnczLWRyb3Bkb3duLWhvdmVyOmhvdmVyID4gLnczLWJ1dHRvbjpmaXJzdC1jaGlsZCwudzMtZHJvcGRvd24tY2xpY2s6aG92ZXIgPiAudzMtYnV0dG9uOmZpcnN0LWNoaWxke2JhY2tncm91bmQtY29sb3I6I2NjYztjb2xvcjojMDAwfVxyXG4udzMtZHJvcGRvd24tY29udGVudHtjdXJzb3I6YXV0bztjb2xvcjojMDAwO2JhY2tncm91bmQtY29sb3I6I2ZmZjtkaXNwbGF5Om5vbmU7cG9zaXRpb246YWJzb2x1dGU7bWluLXdpZHRoOjE2MHB4O21hcmdpbjowO3BhZGRpbmc6MDt6LWluZGV4OjF9XHJcbi53My1jaGVjaywudzMtcmFkaW97d2lkdGg6MjRweDtoZWlnaHQ6MjRweDtwb3NpdGlvbjpyZWxhdGl2ZTt0b3A6NnB4fVxyXG4udzMtc2lkZWJhcntoZWlnaHQ6MTAwJTt3aWR0aDoyMDBweDtiYWNrZ3JvdW5kLWNvbG9yOiNmZmY7cG9zaXRpb246Zml4ZWQhaW1wb3J0YW50O3otaW5kZXg6MTtvdmVyZmxvdzphdXRvfVxyXG4udzMtYmFyLWJsb2NrIC53My1kcm9wZG93bi1ob3ZlciwudzMtYmFyLWJsb2NrIC53My1kcm9wZG93bi1jbGlja3t3aWR0aDoxMDAlfVxyXG4udzMtYmFyLWJsb2NrIC53My1kcm9wZG93bi1ob3ZlciAudzMtZHJvcGRvd24tY29udGVudCwudzMtYmFyLWJsb2NrIC53My1kcm9wZG93bi1jbGljayAudzMtZHJvcGRvd24tY29udGVudHttaW4td2lkdGg6MTAwJX1cclxuLnczLWJhci1ibG9jayAudzMtZHJvcGRvd24taG92ZXIgLnczLWJ1dHRvbiwudzMtYmFyLWJsb2NrIC53My1kcm9wZG93bi1jbGljayAudzMtYnV0dG9ue3dpZHRoOjEwMCU7dGV4dC1hbGlnbjpsZWZ0O3BhZGRpbmc6OHB4IDE2cHh9XHJcbi53My1tYWluLCNtYWlue3RyYW5zaXRpb246bWFyZ2luLWxlZnQgLjRzfVxyXG4udzMtbW9kYWx7ei1pbmRleDozO2Rpc3BsYXk6bm9uZTtwYWRkaW5nLXRvcDoxMDBweDtwb3NpdGlvbjpmaXhlZDtsZWZ0OjA7dG9wOjA7d2lkdGg6MTAwJTtoZWlnaHQ6MTAwJTtvdmVyZmxvdzphdXRvO2JhY2tncm91bmQtY29sb3I6cmdiKDAsMCwwKTtiYWNrZ3JvdW5kLWNvbG9yOnJnYmEoMCwwLDAsMC40KX1cclxuLnczLW1vZGFsLWNvbnRlbnR7bWFyZ2luOmF1dG87YmFja2dyb3VuZC1jb2xvcjojZmZmO3Bvc2l0aW9uOnJlbGF0aXZlO3BhZGRpbmc6MDtvdXRsaW5lOjA7d2lkdGg6NjAwcHh9XHJcbi53My1iYXJ7d2lkdGg6MTAwJTtvdmVyZmxvdzpoaWRkZW59LnczLWNlbnRlciAudzMtYmFye2Rpc3BsYXk6aW5saW5lLWJsb2NrO3dpZHRoOmF1dG99XHJcbi53My1iYXIgLnczLWJhci1pdGVte3BhZGRpbmc6OHB4IDE2cHg7ZmxvYXQ6bGVmdDt3aWR0aDphdXRvO2JvcmRlcjpub25lO2Rpc3BsYXk6YmxvY2s7b3V0bGluZTowfVxyXG4udzMtYmFyIC53My1kcm9wZG93bi1ob3ZlciwudzMtYmFyIC53My1kcm9wZG93bi1jbGlja3twb3NpdGlvbjpzdGF0aWM7ZmxvYXQ6bGVmdH1cclxuLnczLWJhciAudzMtYnV0dG9ue3doaXRlLXNwYWNlOm5vcm1hbH1cclxuLnczLWJhci1ibG9jayAudzMtYmFyLWl0ZW17d2lkdGg6MTAwJTtkaXNwbGF5OmJsb2NrO3BhZGRpbmc6OHB4IDE2cHg7dGV4dC1hbGlnbjpsZWZ0O2JvcmRlcjpub25lO3doaXRlLXNwYWNlOm5vcm1hbDtmbG9hdDpub25lO291dGxpbmU6MH1cclxuLnczLWJhci1ibG9jay53My1jZW50ZXIgLnczLWJhci1pdGVte3RleHQtYWxpZ246Y2VudGVyfS53My1ibG9ja3tkaXNwbGF5OmJsb2NrO3dpZHRoOjEwMCV9XHJcbi53My1yZXNwb25zaXZle2Rpc3BsYXk6YmxvY2s7b3ZlcmZsb3cteDphdXRvfVxyXG4udzMtY29udGFpbmVyOmFmdGVyLC53My1jb250YWluZXI6YmVmb3JlLC53My1wYW5lbDphZnRlciwudzMtcGFuZWw6YmVmb3JlLC53My1yb3c6YWZ0ZXIsLnczLXJvdzpiZWZvcmUsLnczLXJvdy1wYWRkaW5nOmFmdGVyLC53My1yb3ctcGFkZGluZzpiZWZvcmUsXHJcbi53My1jZWxsLXJvdzpiZWZvcmUsLnczLWNlbGwtcm93OmFmdGVyLC53My1jbGVhcjphZnRlciwudzMtY2xlYXI6YmVmb3JlLC53My1iYXI6YmVmb3JlLC53My1iYXI6YWZ0ZXJ7Y29udGVudDpcIlwiO2Rpc3BsYXk6dGFibGU7Y2xlYXI6Ym90aH1cclxuLnczLWNvbCwudzMtaGFsZiwudzMtdGhpcmQsLnczLXR3b3RoaXJkLC53My10aHJlZXF1YXJ0ZXIsLnczLXF1YXJ0ZXJ7ZmxvYXQ6bGVmdDt3aWR0aDoxMDAlfVxyXG4udzMtY29sLnMxe3dpZHRoOjguMzMzMzMlfS53My1jb2wuczJ7d2lkdGg6MTYuNjY2NjYlfS53My1jb2wuczN7d2lkdGg6MjQuOTk5OTklfS53My1jb2wuczR7d2lkdGg6MzMuMzMzMzMlfVxyXG4udzMtY29sLnM1e3dpZHRoOjQxLjY2NjY2JX0udzMtY29sLnM2e3dpZHRoOjQ5Ljk5OTk5JX0udzMtY29sLnM3e3dpZHRoOjU4LjMzMzMzJX0udzMtY29sLnM4e3dpZHRoOjY2LjY2NjY2JX1cclxuLnczLWNvbC5zOXt3aWR0aDo3NC45OTk5OSV9LnczLWNvbC5zMTB7d2lkdGg6ODMuMzMzMzMlfS53My1jb2wuczExe3dpZHRoOjkxLjY2NjY2JX0udzMtY29sLnMxMnt3aWR0aDo5OS45OTk5OSV9XHJcbkBtZWRpYSAobWluLXdpZHRoOjYwMXB4KXsudzMtY29sLm0xe3dpZHRoOjguMzMzMzMlfS53My1jb2wubTJ7d2lkdGg6MTYuNjY2NjYlfS53My1jb2wubTMsLnczLXF1YXJ0ZXJ7d2lkdGg6MjQuOTk5OTklfS53My1jb2wubTQsLnczLXRoaXJke3dpZHRoOjMzLjMzMzMzJX1cclxuLnczLWNvbC5tNXt3aWR0aDo0MS42NjY2NiV9LnczLWNvbC5tNiwudzMtaGFsZnt3aWR0aDo0OS45OTk5OSV9LnczLWNvbC5tN3t3aWR0aDo1OC4zMzMzMyV9LnczLWNvbC5tOCwudzMtdHdvdGhpcmR7d2lkdGg6NjYuNjY2NjYlfVxyXG4udzMtY29sLm05LC53My10aHJlZXF1YXJ0ZXJ7d2lkdGg6NzQuOTk5OTklfS53My1jb2wubTEwe3dpZHRoOjgzLjMzMzMzJX0udzMtY29sLm0xMXt3aWR0aDo5MS42NjY2NiV9LnczLWNvbC5tMTJ7d2lkdGg6OTkuOTk5OTklfX1cclxuQG1lZGlhIChtaW4td2lkdGg6OTkzcHgpey53My1jb2wubDF7d2lkdGg6OC4zMzMzMyV9LnczLWNvbC5sMnt3aWR0aDoxNi42NjY2NiV9LnczLWNvbC5sM3t3aWR0aDoyNC45OTk5OSV9LnczLWNvbC5sNHt3aWR0aDozMy4zMzMzMyV9XHJcbi53My1jb2wubDV7d2lkdGg6NDEuNjY2NjYlfS53My1jb2wubDZ7d2lkdGg6NDkuOTk5OTklfS53My1jb2wubDd7d2lkdGg6NTguMzMzMzMlfS53My1jb2wubDh7d2lkdGg6NjYuNjY2NjYlfVxyXG4udzMtY29sLmw5e3dpZHRoOjc0Ljk5OTk5JX0udzMtY29sLmwxMHt3aWR0aDo4My4zMzMzMyV9LnczLWNvbC5sMTF7d2lkdGg6OTEuNjY2NjYlfS53My1jb2wubDEye3dpZHRoOjk5Ljk5OTk5JX19XHJcbi53My1yZXN0e292ZXJmbG93OmhpZGRlbn0udzMtc3RyZXRjaHttYXJnaW4tbGVmdDotMTZweDttYXJnaW4tcmlnaHQ6LTE2cHh9XHJcbi53My1jb250ZW50LC53My1hdXRve21hcmdpbi1sZWZ0OmF1dG87bWFyZ2luLXJpZ2h0OmF1dG99LnczLWNvbnRlbnR7bWF4LXdpZHRoOjk4MHB4fS53My1hdXRve21heC13aWR0aDoxMTQwcHh9XHJcbi53My1jZWxsLXJvd3tkaXNwbGF5OnRhYmxlO3dpZHRoOjEwMCV9LnczLWNlbGx7ZGlzcGxheTp0YWJsZS1jZWxsfVxyXG4udzMtY2VsbC10b3B7dmVydGljYWwtYWxpZ246dG9wfS53My1jZWxsLW1pZGRsZXt2ZXJ0aWNhbC1hbGlnbjptaWRkbGV9LnczLWNlbGwtYm90dG9te3ZlcnRpY2FsLWFsaWduOmJvdHRvbX1cclxuLnczLWhpZGV7ZGlzcGxheTpub25lIWltcG9ydGFudH0udzMtc2hvdy1ibG9jaywudzMtc2hvd3tkaXNwbGF5OmJsb2NrIWltcG9ydGFudH0udzMtc2hvdy1pbmxpbmUtYmxvY2t7ZGlzcGxheTppbmxpbmUtYmxvY2shaW1wb3J0YW50fVxyXG5AbWVkaWEgKG1heC13aWR0aDoxMjA1cHgpey53My1hdXRve21heC13aWR0aDo5NSV9fVxyXG5AbWVkaWEgKG1heC13aWR0aDo2MDBweCl7LnczLW1vZGFsLWNvbnRlbnR7bWFyZ2luOjAgMTBweDt3aWR0aDphdXRvIWltcG9ydGFudH0udzMtbW9kYWx7cGFkZGluZy10b3A6MzBweH1cclxuLnczLWRyb3Bkb3duLWhvdmVyLnczLW1vYmlsZSAudzMtZHJvcGRvd24tY29udGVudCwudzMtZHJvcGRvd24tY2xpY2sudzMtbW9iaWxlIC53My1kcm9wZG93bi1jb250ZW50e3Bvc2l0aW9uOnJlbGF0aXZlfVx0XHJcbi53My1oaWRlLXNtYWxse2Rpc3BsYXk6bm9uZSFpbXBvcnRhbnR9LnczLW1vYmlsZXtkaXNwbGF5OmJsb2NrO3dpZHRoOjEwMCUhaW1wb3J0YW50fS53My1iYXItaXRlbS53My1tb2JpbGUsLnczLWRyb3Bkb3duLWhvdmVyLnczLW1vYmlsZSwudzMtZHJvcGRvd24tY2xpY2sudzMtbW9iaWxle3RleHQtYWxpZ246Y2VudGVyfVxyXG4udzMtZHJvcGRvd24taG92ZXIudzMtbW9iaWxlLC53My1kcm9wZG93bi1ob3Zlci53My1tb2JpbGUgLnczLWJ0biwudzMtZHJvcGRvd24taG92ZXIudzMtbW9iaWxlIC53My1idXR0b24sLnczLWRyb3Bkb3duLWNsaWNrLnczLW1vYmlsZSwudzMtZHJvcGRvd24tY2xpY2sudzMtbW9iaWxlIC53My1idG4sLnczLWRyb3Bkb3duLWNsaWNrLnczLW1vYmlsZSAudzMtYnV0dG9ue3dpZHRoOjEwMCV9fVxyXG5AbWVkaWEgKG1heC13aWR0aDo3NjhweCl7LnczLW1vZGFsLWNvbnRlbnR7d2lkdGg6NTAwcHh9LnczLW1vZGFse3BhZGRpbmctdG9wOjUwcHh9fVxyXG5AbWVkaWEgKG1pbi13aWR0aDo5OTNweCl7LnczLW1vZGFsLWNvbnRlbnR7d2lkdGg6OTAwcHh9LnczLWhpZGUtbGFyZ2V7ZGlzcGxheTpub25lIWltcG9ydGFudH0udzMtc2lkZWJhci53My1jb2xsYXBzZXtkaXNwbGF5OmJsb2NrIWltcG9ydGFudH19XHJcbkBtZWRpYSAobWF4LXdpZHRoOjk5MnB4KSBhbmQgKG1pbi13aWR0aDo2MDFweCl7LnczLWhpZGUtbWVkaXVte2Rpc3BsYXk6bm9uZSFpbXBvcnRhbnR9fVxyXG5AbWVkaWEgKG1heC13aWR0aDo5OTJweCl7LnczLXNpZGViYXIudzMtY29sbGFwc2V7ZGlzcGxheTpub25lfS53My1tYWlue21hcmdpbi1sZWZ0OjAhaW1wb3J0YW50O21hcmdpbi1yaWdodDowIWltcG9ydGFudH0udzMtYXV0b3ttYXgtd2lkdGg6MTAwJX19XHJcbi53My10b3AsLnczLWJvdHRvbXtwb3NpdGlvbjpmaXhlZDt3aWR0aDoxMDAlO3otaW5kZXg6MX0udzMtdG9we3RvcDowfS53My1ib3R0b217Ym90dG9tOjB9XHJcbi53My1vdmVybGF5e3Bvc2l0aW9uOmZpeGVkO2Rpc3BsYXk6bm9uZTt3aWR0aDoxMDAlO2hlaWdodDoxMDAlO3RvcDowO2xlZnQ6MDtyaWdodDowO2JvdHRvbTowO2JhY2tncm91bmQtY29sb3I6cmdiYSgwLDAsMCwwLjUpO3otaW5kZXg6Mn1cclxuLnczLWRpc3BsYXktdG9wbGVmdHtwb3NpdGlvbjphYnNvbHV0ZTtsZWZ0OjA7dG9wOjB9LnczLWRpc3BsYXktdG9wcmlnaHR7cG9zaXRpb246YWJzb2x1dGU7cmlnaHQ6MDt0b3A6MH1cclxuLnczLWRpc3BsYXktYm90dG9tbGVmdHtwb3NpdGlvbjphYnNvbHV0ZTtsZWZ0OjA7Ym90dG9tOjB9LnczLWRpc3BsYXktYm90dG9tcmlnaHR7cG9zaXRpb246YWJzb2x1dGU7cmlnaHQ6MDtib3R0b206MH1cclxuLnczLWRpc3BsYXktbWlkZGxle3Bvc2l0aW9uOmFic29sdXRlO3RvcDo1MCU7bGVmdDo1MCU7dHJhbnNmb3JtOnRyYW5zbGF0ZSgtNTAlLC01MCUpOy1tcy10cmFuc2Zvcm06dHJhbnNsYXRlKC01MCUsLTUwJSl9XHJcbi53My1kaXNwbGF5LWxlZnR7cG9zaXRpb246YWJzb2x1dGU7dG9wOjUwJTtsZWZ0OjAlO3RyYW5zZm9ybTp0cmFuc2xhdGUoMCUsLTUwJSk7LW1zLXRyYW5zZm9ybTp0cmFuc2xhdGUoLTAlLC01MCUpfVxyXG4udzMtZGlzcGxheS1yaWdodHtwb3NpdGlvbjphYnNvbHV0ZTt0b3A6NTAlO3JpZ2h0OjAlO3RyYW5zZm9ybTp0cmFuc2xhdGUoMCUsLTUwJSk7LW1zLXRyYW5zZm9ybTp0cmFuc2xhdGUoMCUsLTUwJSl9XHJcbi53My1kaXNwbGF5LXRvcG1pZGRsZXtwb3NpdGlvbjphYnNvbHV0ZTtsZWZ0OjUwJTt0b3A6MDt0cmFuc2Zvcm06dHJhbnNsYXRlKC01MCUsMCUpOy1tcy10cmFuc2Zvcm06dHJhbnNsYXRlKC01MCUsMCUpfVxyXG4udzMtZGlzcGxheS1ib3R0b21taWRkbGV7cG9zaXRpb246YWJzb2x1dGU7bGVmdDo1MCU7Ym90dG9tOjA7dHJhbnNmb3JtOnRyYW5zbGF0ZSgtNTAlLDAlKTstbXMtdHJhbnNmb3JtOnRyYW5zbGF0ZSgtNTAlLDAlKX1cclxuLnczLWRpc3BsYXktY29udGFpbmVyOmhvdmVyIC53My1kaXNwbGF5LWhvdmVye2Rpc3BsYXk6YmxvY2t9LnczLWRpc3BsYXktY29udGFpbmVyOmhvdmVyIHNwYW4udzMtZGlzcGxheS1ob3ZlcntkaXNwbGF5OmlubGluZS1ibG9ja30udzMtZGlzcGxheS1ob3ZlcntkaXNwbGF5Om5vbmV9XHJcbi53My1kaXNwbGF5LXBvc2l0aW9ue3Bvc2l0aW9uOmFic29sdXRlfVxyXG4udzMtY2lyY2xle2JvcmRlci1yYWRpdXM6NTAlfVxyXG4udzMtcm91bmQtc21hbGx7Ym9yZGVyLXJhZGl1czoycHh9LnczLXJvdW5kLC53My1yb3VuZC1tZWRpdW17Ym9yZGVyLXJhZGl1czo0cHh9LnczLXJvdW5kLWxhcmdle2JvcmRlci1yYWRpdXM6OHB4fS53My1yb3VuZC14bGFyZ2V7Ym9yZGVyLXJhZGl1czoxNnB4fS53My1yb3VuZC14eGxhcmdle2JvcmRlci1yYWRpdXM6MzJweH1cclxuLnczLXJvdy1wYWRkaW5nLC53My1yb3ctcGFkZGluZz4udzMtaGFsZiwudzMtcm93LXBhZGRpbmc+LnczLXRoaXJkLC53My1yb3ctcGFkZGluZz4udzMtdHdvdGhpcmQsLnczLXJvdy1wYWRkaW5nPi53My10aHJlZXF1YXJ0ZXIsLnczLXJvdy1wYWRkaW5nPi53My1xdWFydGVyLC53My1yb3ctcGFkZGluZz4udzMtY29se3BhZGRpbmc6MCA4cHh9XHJcbi53My1jb250YWluZXIsLnczLXBhbmVse3BhZGRpbmc6MTBweH0udzMtcGFuZWx7bWFyZ2luLXRvcDoxNnB4O21hcmdpbi1ib3R0b206MTZweH1cclxuLnczLWNvZGUsLnczLWNvZGVzcGFue2ZvbnQtZmFtaWx5OkNvbnNvbGFzLFwiY291cmllciBuZXdcIjtmb250LXNpemU6MTZweH1cclxuLnczLWNvZGV7d2lkdGg6YXV0bztiYWNrZ3JvdW5kLWNvbG9yOiNmZmY7cGFkZGluZzo4cHggMTJweDtib3JkZXItbGVmdDo0cHggc29saWQgIzRDQUY1MDt3b3JkLXdyYXA6YnJlYWstd29yZH1cclxuLnczLWNvZGVzcGFue2NvbG9yOmNyaW1zb247YmFja2dyb3VuZC1jb2xvcjojZjFmMWYxO3BhZGRpbmctbGVmdDo0cHg7cGFkZGluZy1yaWdodDo0cHg7Zm9udC1zaXplOjExMCV9XHJcbi53My1jYXJkLC53My1jYXJkLTJ7Ym94LXNoYWRvdzowIDJweCA1cHggMCByZ2JhKDAsMCwwLDAuMTYpLDAgMnB4IDEwcHggMCByZ2JhKDAsMCwwLDAuMTIpfVxyXG4udzMtY2FyZC00LC53My1ob3Zlci1zaGFkb3c6aG92ZXJ7Ym94LXNoYWRvdzowIDRweCAxMHB4IDAgcmdiYSgwLDAsMCwwLjIpLDAgNHB4IDIwcHggMCByZ2JhKDAsMCwwLDAuMTkpfVxyXG4udzMtc3BpbnthbmltYXRpb246dzMtc3BpbiAycyBpbmZpbml0ZSBsaW5lYXJ9QGtleWZyYW1lcyB3My1zcGluezAle3RyYW5zZm9ybTpyb3RhdGUoMGRlZyl9MTAwJXt0cmFuc2Zvcm06cm90YXRlKDM1OWRlZyl9fVxyXG4udzMtYW5pbWF0ZS1mYWRpbmd7YW5pbWF0aW9uOmZhZGluZyAxMHMgaW5maW5pdGV9QGtleWZyYW1lcyBmYWRpbmd7MCV7b3BhY2l0eTowfTUwJXtvcGFjaXR5OjF9MTAwJXtvcGFjaXR5OjB9fVxyXG4udzMtYW5pbWF0ZS1vcGFjaXR5e2FuaW1hdGlvbjpvcGFjIDAuOHN9QGtleWZyYW1lcyBvcGFje2Zyb217b3BhY2l0eTowfSB0b3tvcGFjaXR5OjF9fVxyXG4udzMtYW5pbWF0ZS10b3B7cG9zaXRpb246cmVsYXRpdmU7YW5pbWF0aW9uOmFuaW1hdGV0b3AgMC40c31Aa2V5ZnJhbWVzIGFuaW1hdGV0b3B7ZnJvbXt0b3A6LTMwMHB4O29wYWNpdHk6MH0gdG97dG9wOjA7b3BhY2l0eToxfX1cclxuLnczLWFuaW1hdGUtbGVmdHtwb3NpdGlvbjpyZWxhdGl2ZTthbmltYXRpb246YW5pbWF0ZWxlZnQgMC40c31Aa2V5ZnJhbWVzIGFuaW1hdGVsZWZ0e2Zyb217bGVmdDotMzAwcHg7b3BhY2l0eTowfSB0b3tsZWZ0OjA7b3BhY2l0eToxfX1cclxuLnczLWFuaW1hdGUtcmlnaHR7cG9zaXRpb246cmVsYXRpdmU7YW5pbWF0aW9uOmFuaW1hdGVyaWdodCAwLjRzfUBrZXlmcmFtZXMgYW5pbWF0ZXJpZ2h0e2Zyb217cmlnaHQ6LTMwMHB4O29wYWNpdHk6MH0gdG97cmlnaHQ6MDtvcGFjaXR5OjF9fVxyXG4udzMtYW5pbWF0ZS1ib3R0b217cG9zaXRpb246cmVsYXRpdmU7YW5pbWF0aW9uOmFuaW1hdGVib3R0b20gMC40c31Aa2V5ZnJhbWVzIGFuaW1hdGVib3R0b217ZnJvbXtib3R0b206LTMwMHB4O29wYWNpdHk6MH0gdG97Ym90dG9tOjA7b3BhY2l0eToxfX1cclxuLnczLWFuaW1hdGUtem9vbSB7YW5pbWF0aW9uOmFuaW1hdGV6b29tIDAuNnN9QGtleWZyYW1lcyBhbmltYXRlem9vbXtmcm9te3RyYW5zZm9ybTpzY2FsZSgwKX0gdG97dHJhbnNmb3JtOnNjYWxlKDEpfX1cclxuLnczLWFuaW1hdGUtaW5wdXR7dHJhbnNpdGlvbjp3aWR0aCAwLjRzIGVhc2UtaW4tb3V0fS53My1hbmltYXRlLWlucHV0OmZvY3Vze3dpZHRoOjEwMCUhaW1wb3J0YW50fVxyXG4udzMtb3BhY2l0eSwudzMtaG92ZXItb3BhY2l0eTpob3ZlcntvcGFjaXR5OjAuNjB9LnczLW9wYWNpdHktb2ZmLC53My1ob3Zlci1vcGFjaXR5LW9mZjpob3ZlcntvcGFjaXR5OjF9XHJcbi53My1vcGFjaXR5LW1heHtvcGFjaXR5OjAuMjV9LnczLW9wYWNpdHktbWlue29wYWNpdHk6MC43NX1cclxuLnczLWdyZXlzY2FsZS1tYXgsLnczLWdyYXlzY2FsZS1tYXgsLnczLWhvdmVyLWdyZXlzY2FsZTpob3ZlciwudzMtaG92ZXItZ3JheXNjYWxlOmhvdmVye2ZpbHRlcjpncmF5c2NhbGUoMTAwJSl9XHJcbi53My1ncmV5c2NhbGUsLnczLWdyYXlzY2FsZXtmaWx0ZXI6Z3JheXNjYWxlKDc1JSl9LnczLWdyZXlzY2FsZS1taW4sLnczLWdyYXlzY2FsZS1taW57ZmlsdGVyOmdyYXlzY2FsZSg1MCUpfVxyXG4udzMtc2VwaWF7ZmlsdGVyOnNlcGlhKDc1JSl9LnczLXNlcGlhLW1heCwudzMtaG92ZXItc2VwaWE6aG92ZXJ7ZmlsdGVyOnNlcGlhKDEwMCUpfS53My1zZXBpYS1taW57ZmlsdGVyOnNlcGlhKDUwJSl9XHJcbi53My10aW55e2ZvbnQtc2l6ZToxMHB4IWltcG9ydGFudH0udzMtc21hbGx7Zm9udC1zaXplOjEycHghaW1wb3J0YW50fS53My1tZWRpdW17Zm9udC1zaXplOjE1cHghaW1wb3J0YW50fS53My1sYXJnZXtmb250LXNpemU6MThweCFpbXBvcnRhbnR9XHJcbi53My14bGFyZ2V7Zm9udC1zaXplOjI0cHghaW1wb3J0YW50fS53My14eGxhcmdle2ZvbnQtc2l6ZTozNnB4IWltcG9ydGFudH0udzMteHh4bGFyZ2V7Zm9udC1zaXplOjQ4cHghaW1wb3J0YW50fS53My1qdW1ib3tmb250LXNpemU6NjRweCFpbXBvcnRhbnR9XHJcbi53My1sZWZ0LWFsaWdue3RleHQtYWxpZ246bGVmdCFpbXBvcnRhbnR9LnczLXJpZ2h0LWFsaWdue3RleHQtYWxpZ246cmlnaHQhaW1wb3J0YW50fS53My1qdXN0aWZ5e3RleHQtYWxpZ246anVzdGlmeSFpbXBvcnRhbnR9LnczLWNlbnRlcnt0ZXh0LWFsaWduOmNlbnRlciFpbXBvcnRhbnR9XHJcbi53My1ib3JkZXItMHtib3JkZXI6MCFpbXBvcnRhbnR9LnczLWJvcmRlcntib3JkZXI6MXB4IHNvbGlkICNjY2MhaW1wb3J0YW50fVxyXG4udzMtYm9yZGVyLXRvcHtib3JkZXItdG9wOjFweCBzb2xpZCAjY2NjIWltcG9ydGFudH0udzMtYm9yZGVyLWJvdHRvbXtib3JkZXItYm90dG9tOjFweCBzb2xpZCAjY2NjIWltcG9ydGFudH1cclxuLnczLWJvcmRlci1sZWZ0e2JvcmRlci1sZWZ0OjFweCBzb2xpZCAjY2NjIWltcG9ydGFudH0udzMtYm9yZGVyLXJpZ2h0e2JvcmRlci1yaWdodDoxcHggc29saWQgI2NjYyFpbXBvcnRhbnR9XHJcbi53My10b3BiYXJ7Ym9yZGVyLXRvcDo2cHggc29saWQgI2NjYyFpbXBvcnRhbnR9LnczLWJvdHRvbWJhcntib3JkZXItYm90dG9tOjZweCBzb2xpZCAjY2NjIWltcG9ydGFudH1cclxuLnczLWxlZnRiYXJ7Ym9yZGVyLWxlZnQ6NnB4IHNvbGlkICNjY2MhaW1wb3J0YW50fS53My1yaWdodGJhcntib3JkZXItcmlnaHQ6NnB4IHNvbGlkICNjY2MhaW1wb3J0YW50fVxyXG4udzMtc2VjdGlvbiwudzMtY29kZXttYXJnaW4tdG9wOjE2cHghaW1wb3J0YW50O21hcmdpbi1ib3R0b206MTZweCFpbXBvcnRhbnR9XHJcbi53My1tYXJnaW57bWFyZ2luOjE2cHghaW1wb3J0YW50fS53My1tYXJnaW4tdG9we21hcmdpbi10b3A6MTZweCFpbXBvcnRhbnR9LnczLW1hcmdpbi1ib3R0b217bWFyZ2luLWJvdHRvbToxNnB4IWltcG9ydGFudH1cclxuLnczLW1hcmdpbi1sZWZ0e21hcmdpbi1sZWZ0OjE2cHghaW1wb3J0YW50fS53My1tYXJnaW4tcmlnaHR7bWFyZ2luLXJpZ2h0OjE2cHghaW1wb3J0YW50fVxyXG4udzMtcGFkZGluZy1zbWFsbHtwYWRkaW5nOjRweCA4cHghaW1wb3J0YW50fS53My1wYWRkaW5ne3BhZGRpbmc6OHB4IDE2cHghaW1wb3J0YW50fS53My1wYWRkaW5nLWxhcmdle3BhZGRpbmc6MTJweCAyNHB4IWltcG9ydGFudH1cclxuLnczLXBhZGRpbmctMTZ7cGFkZGluZy10b3A6MTZweCFpbXBvcnRhbnQ7cGFkZGluZy1ib3R0b206MTZweCFpbXBvcnRhbnR9LnczLXBhZGRpbmctMjR7cGFkZGluZy10b3A6MjRweCFpbXBvcnRhbnQ7cGFkZGluZy1ib3R0b206MjRweCFpbXBvcnRhbnR9XHJcbi53My1wYWRkaW5nLTMye3BhZGRpbmctdG9wOjMycHghaW1wb3J0YW50O3BhZGRpbmctYm90dG9tOjMycHghaW1wb3J0YW50fS53My1wYWRkaW5nLTQ4e3BhZGRpbmctdG9wOjQ4cHghaW1wb3J0YW50O3BhZGRpbmctYm90dG9tOjQ4cHghaW1wb3J0YW50fVxyXG4udzMtcGFkZGluZy02NHtwYWRkaW5nLXRvcDo2NHB4IWltcG9ydGFudDtwYWRkaW5nLWJvdHRvbTo2NHB4IWltcG9ydGFudH1cclxuLnczLWxlZnR7ZmxvYXQ6bGVmdCFpbXBvcnRhbnR9LnczLXJpZ2h0e2Zsb2F0OnJpZ2h0IWltcG9ydGFudH1cclxuLnczLWJ1dHRvbjpob3Zlcntjb2xvcjojMDAwIWltcG9ydGFudDtiYWNrZ3JvdW5kLWNvbG9yOiNjY2MhaW1wb3J0YW50fVxyXG4udzMtdHJhbnNwYXJlbnQsLnczLWhvdmVyLW5vbmU6aG92ZXJ7YmFja2dyb3VuZC1jb2xvcjp0cmFuc3BhcmVudCFpbXBvcnRhbnR9XHJcbi53My1ob3Zlci1ub25lOmhvdmVye2JveC1zaGFkb3c6bm9uZSFpbXBvcnRhbnR9XHJcbi8qIENvbG9ycyAqL1xyXG4udzMtYW1iZXIsLnczLWhvdmVyLWFtYmVyOmhvdmVye2NvbG9yOiMwMDAhaW1wb3J0YW50O2JhY2tncm91bmQtY29sb3I6I2ZmYzEwNyFpbXBvcnRhbnR9XHJcbi53My1hcXVhLC53My1ob3Zlci1hcXVhOmhvdmVye2NvbG9yOiMwMDAhaW1wb3J0YW50O2JhY2tncm91bmQtY29sb3I6IzAwZmZmZiFpbXBvcnRhbnR9XHJcbi53My1ibHVlLC53My1ob3Zlci1ibHVlOmhvdmVye2NvbG9yOiNmZmYhaW1wb3J0YW50O2JhY2tncm91bmQtY29sb3I6IzIxOTZGMyFpbXBvcnRhbnR9XHJcbi53My1saWdodC1ibHVlLC53My1ob3Zlci1saWdodC1ibHVlOmhvdmVye2NvbG9yOiMwMDAhaW1wb3J0YW50O2JhY2tncm91bmQtY29sb3I6Izg3Q0VFQiFpbXBvcnRhbnR9XHJcbi53My1icm93biwudzMtaG92ZXItYnJvd246aG92ZXJ7Y29sb3I6I2ZmZiFpbXBvcnRhbnQ7YmFja2dyb3VuZC1jb2xvcjojNzk1NTQ4IWltcG9ydGFudH1cclxuLnczLWN5YW4sLnczLWhvdmVyLWN5YW46aG92ZXJ7Y29sb3I6IzAwMCFpbXBvcnRhbnQ7YmFja2dyb3VuZC1jb2xvcjojMDBiY2Q0IWltcG9ydGFudH1cclxuLnczLWJsdWUtZ3JleSwudzMtaG92ZXItYmx1ZS1ncmV5OmhvdmVyLC53My1ibHVlLWdyYXksLnczLWhvdmVyLWJsdWUtZ3JheTpob3Zlcntjb2xvcjojZmZmIWltcG9ydGFudDtiYWNrZ3JvdW5kLWNvbG9yOiM2MDdkOGIhaW1wb3J0YW50fVxyXG4udzMtZ3JlZW4sLnczLWhvdmVyLWdyZWVuOmhvdmVye2NvbG9yOiNmZmYhaW1wb3J0YW50O2JhY2tncm91bmQtY29sb3I6IzRDQUY1MCFpbXBvcnRhbnR9XHJcbi53My1saWdodC1ncmVlbiwudzMtaG92ZXItbGlnaHQtZ3JlZW46aG92ZXJ7Y29sb3I6IzAwMCFpbXBvcnRhbnQ7YmFja2dyb3VuZC1jb2xvcjojOGJjMzRhIWltcG9ydGFudH1cclxuLnczLWluZGlnbywudzMtaG92ZXItaW5kaWdvOmhvdmVye2NvbG9yOiNmZmYhaW1wb3J0YW50O2JhY2tncm91bmQtY29sb3I6IzNmNTFiNSFpbXBvcnRhbnR9XHJcbi53My1raGFraSwudzMtaG92ZXIta2hha2k6aG92ZXJ7Y29sb3I6IzAwMCFpbXBvcnRhbnQ7YmFja2dyb3VuZC1jb2xvcjojZjBlNjhjIWltcG9ydGFudH1cclxuLnczLWxpbWUsLnczLWhvdmVyLWxpbWU6aG92ZXJ7Y29sb3I6IzAwMCFpbXBvcnRhbnQ7YmFja2dyb3VuZC1jb2xvcjojY2RkYzM5IWltcG9ydGFudH1cclxuLnczLW9yYW5nZSwudzMtaG92ZXItb3JhbmdlOmhvdmVye2NvbG9yOiMwMDAhaW1wb3J0YW50O2JhY2tncm91bmQtY29sb3I6I2ZmOTgwMCFpbXBvcnRhbnR9XHJcbi53My1kZWVwLW9yYW5nZSwudzMtaG92ZXItZGVlcC1vcmFuZ2U6aG92ZXJ7Y29sb3I6I2ZmZiFpbXBvcnRhbnQ7YmFja2dyb3VuZC1jb2xvcjojZmY1NzIyIWltcG9ydGFudH1cclxuLnczLXBpbmssLnczLWhvdmVyLXBpbms6aG92ZXJ7Y29sb3I6I2ZmZiFpbXBvcnRhbnQ7YmFja2dyb3VuZC1jb2xvcjojZTkxZTYzIWltcG9ydGFudH1cclxuLnczLXB1cnBsZSwudzMtaG92ZXItcHVycGxlOmhvdmVye2NvbG9yOiNmZmYhaW1wb3J0YW50O2JhY2tncm91bmQtY29sb3I6IzljMjdiMCFpbXBvcnRhbnR9XHJcbi53My1kZWVwLXB1cnBsZSwudzMtaG92ZXItZGVlcC1wdXJwbGU6aG92ZXJ7Y29sb3I6I2ZmZiFpbXBvcnRhbnQ7YmFja2dyb3VuZC1jb2xvcjojNjczYWI3IWltcG9ydGFudH1cclxuLnczLXJlZCwudzMtaG92ZXItcmVkOmhvdmVye2NvbG9yOiNmZmYhaW1wb3J0YW50O2JhY2tncm91bmQtY29sb3I6I2Y0NDMzNiFpbXBvcnRhbnR9XHJcbi53My1zYW5kLC53My1ob3Zlci1zYW5kOmhvdmVye2NvbG9yOiMwMDAhaW1wb3J0YW50O2JhY2tncm91bmQtY29sb3I6I2ZkZjVlNiFpbXBvcnRhbnR9XHJcbi53My10ZWFsLC53My1ob3Zlci10ZWFsOmhvdmVye2NvbG9yOiNmZmYhaW1wb3J0YW50O2JhY2tncm91bmQtY29sb3I6IzAwOTY4OCFpbXBvcnRhbnR9XHJcbi53My15ZWxsb3csLnczLWhvdmVyLXllbGxvdzpob3Zlcntjb2xvcjojMDAwIWltcG9ydGFudDtiYWNrZ3JvdW5kLWNvbG9yOiNmZmViM2IhaW1wb3J0YW50fVxyXG4udzMtd2hpdGUsLnczLWhvdmVyLXdoaXRlOmhvdmVye2NvbG9yOiMwMDAhaW1wb3J0YW50O2JhY2tncm91bmQtY29sb3I6I2ZmZiFpbXBvcnRhbnR9XHJcbi53My1ibGFjaywudzMtaG92ZXItYmxhY2s6aG92ZXJ7Y29sb3I6I2ZmZiFpbXBvcnRhbnQ7YmFja2dyb3VuZC1jb2xvcjojMDAwIWltcG9ydGFudH1cclxuLnczLWdyZXksLnczLWhvdmVyLWdyZXk6aG92ZXIsLnczLWdyYXksLnczLWhvdmVyLWdyYXk6aG92ZXJ7Y29sb3I6IzAwMCFpbXBvcnRhbnQ7YmFja2dyb3VuZC1jb2xvcjojOWU5ZTllIWltcG9ydGFudH1cclxuLnczLWxpZ2h0LWdyZXksLnczLWhvdmVyLWxpZ2h0LWdyZXk6aG92ZXIsLnczLWxpZ2h0LWdyYXksLnczLWhvdmVyLWxpZ2h0LWdyYXk6aG92ZXJ7Y29sb3I6IzAwMCFpbXBvcnRhbnQ7YmFja2dyb3VuZC1jb2xvcjojZjFmMWYxIWltcG9ydGFudH1cclxuLnczLWRhcmstZ3JleSwudzMtaG92ZXItZGFyay1ncmV5OmhvdmVyLC53My1kYXJrLWdyYXksLnczLWhvdmVyLWRhcmstZ3JheTpob3Zlcntjb2xvcjojZmZmIWltcG9ydGFudDtiYWNrZ3JvdW5kLWNvbG9yOiM2MTYxNjEhaW1wb3J0YW50fVxyXG4udzMtcGFsZS1yZWQsLnczLWhvdmVyLXBhbGUtcmVkOmhvdmVye2NvbG9yOiMwMDAhaW1wb3J0YW50O2JhY2tncm91bmQtY29sb3I6I2ZmZGRkZCFpbXBvcnRhbnR9XHJcbi53My1wYWxlLWdyZWVuLC53My1ob3Zlci1wYWxlLWdyZWVuOmhvdmVye2NvbG9yOiMwMDAhaW1wb3J0YW50O2JhY2tncm91bmQtY29sb3I6I2RkZmZkZCFpbXBvcnRhbnR9XHJcbi53My1wYWxlLXllbGxvdywudzMtaG92ZXItcGFsZS15ZWxsb3c6aG92ZXJ7Y29sb3I6IzAwMCFpbXBvcnRhbnQ7YmFja2dyb3VuZC1jb2xvcjojZmZmZmNjIWltcG9ydGFudH1cclxuLnczLXBhbGUtYmx1ZSwudzMtaG92ZXItcGFsZS1ibHVlOmhvdmVye2NvbG9yOiMwMDAhaW1wb3J0YW50O2JhY2tncm91bmQtY29sb3I6I2RkZmZmZiFpbXBvcnRhbnR9XHJcbi53My10ZXh0LWFtYmVyLC53My1ob3Zlci10ZXh0LWFtYmVyOmhvdmVye2NvbG9yOiNmZmMxMDchaW1wb3J0YW50fVxyXG4udzMtdGV4dC1hcXVhLC53My1ob3Zlci10ZXh0LWFxdWE6aG92ZXJ7Y29sb3I6IzAwZmZmZiFpbXBvcnRhbnR9XHJcbi53My10ZXh0LWJsdWUsLnczLWhvdmVyLXRleHQtYmx1ZTpob3Zlcntjb2xvcjojMjE5NkYzIWltcG9ydGFudH1cclxuLnczLXRleHQtbGlnaHQtYmx1ZSwudzMtaG92ZXItdGV4dC1saWdodC1ibHVlOmhvdmVye2NvbG9yOiM4N0NFRUIhaW1wb3J0YW50fVxyXG4udzMtdGV4dC1icm93biwudzMtaG92ZXItdGV4dC1icm93bjpob3Zlcntjb2xvcjojNzk1NTQ4IWltcG9ydGFudH1cclxuLnczLXRleHQtY3lhbiwudzMtaG92ZXItdGV4dC1jeWFuOmhvdmVye2NvbG9yOiMwMGJjZDQhaW1wb3J0YW50fVxyXG4udzMtdGV4dC1ibHVlLWdyZXksLnczLWhvdmVyLXRleHQtYmx1ZS1ncmV5OmhvdmVyLC53My10ZXh0LWJsdWUtZ3JheSwudzMtaG92ZXItdGV4dC1ibHVlLWdyYXk6aG92ZXJ7Y29sb3I6IzYwN2Q4YiFpbXBvcnRhbnR9XHJcbi53My10ZXh0LWdyZWVuLC53My1ob3Zlci10ZXh0LWdyZWVuOmhvdmVye2NvbG9yOiM0Q0FGNTAhaW1wb3J0YW50fVxyXG4udzMtdGV4dC1saWdodC1ncmVlbiwudzMtaG92ZXItdGV4dC1saWdodC1ncmVlbjpob3Zlcntjb2xvcjojOGJjMzRhIWltcG9ydGFudH1cclxuLnczLXRleHQtaW5kaWdvLC53My1ob3Zlci10ZXh0LWluZGlnbzpob3Zlcntjb2xvcjojM2Y1MWI1IWltcG9ydGFudH1cclxuLnczLXRleHQta2hha2ksLnczLWhvdmVyLXRleHQta2hha2k6aG92ZXJ7Y29sb3I6I2I0YWE1MCFpbXBvcnRhbnR9XHJcbi53My10ZXh0LWxpbWUsLnczLWhvdmVyLXRleHQtbGltZTpob3Zlcntjb2xvcjojY2RkYzM5IWltcG9ydGFudH1cclxuLnczLXRleHQtb3JhbmdlLC53My1ob3Zlci10ZXh0LW9yYW5nZTpob3Zlcntjb2xvcjojZmY5ODAwIWltcG9ydGFudH1cclxuLnczLXRleHQtZGVlcC1vcmFuZ2UsLnczLWhvdmVyLXRleHQtZGVlcC1vcmFuZ2U6aG92ZXJ7Y29sb3I6I2ZmNTcyMiFpbXBvcnRhbnR9XHJcbi53My10ZXh0LXBpbmssLnczLWhvdmVyLXRleHQtcGluazpob3Zlcntjb2xvcjojZTkxZTYzIWltcG9ydGFudH1cclxuLnczLXRleHQtcHVycGxlLC53My1ob3Zlci10ZXh0LXB1cnBsZTpob3Zlcntjb2xvcjojOWMyN2IwIWltcG9ydGFudH1cclxuLnczLXRleHQtZGVlcC1wdXJwbGUsLnczLWhvdmVyLXRleHQtZGVlcC1wdXJwbGU6aG92ZXJ7Y29sb3I6IzY3M2FiNyFpbXBvcnRhbnR9XHJcbi53My10ZXh0LXJlZCwudzMtaG92ZXItdGV4dC1yZWQ6aG92ZXJ7Y29sb3I6I2Y0NDMzNiFpbXBvcnRhbnR9XHJcbi53My10ZXh0LXNhbmQsLnczLWhvdmVyLXRleHQtc2FuZDpob3Zlcntjb2xvcjojZmRmNWU2IWltcG9ydGFudH1cclxuLnczLXRleHQtdGVhbCwudzMtaG92ZXItdGV4dC10ZWFsOmhvdmVye2NvbG9yOiMwMDk2ODghaW1wb3J0YW50fVxyXG4udzMtdGV4dC15ZWxsb3csLnczLWhvdmVyLXRleHQteWVsbG93OmhvdmVye2NvbG9yOiNkMmJlMGUhaW1wb3J0YW50fVxyXG4udzMtdGV4dC13aGl0ZSwudzMtaG92ZXItdGV4dC13aGl0ZTpob3Zlcntjb2xvcjojZmZmIWltcG9ydGFudH1cclxuLnczLXRleHQtYmxhY2ssLnczLWhvdmVyLXRleHQtYmxhY2s6aG92ZXJ7Y29sb3I6IzAwMCFpbXBvcnRhbnR9XHJcbi53My10ZXh0LWdyZXksLnczLWhvdmVyLXRleHQtZ3JleTpob3ZlciwudzMtdGV4dC1ncmF5LC53My1ob3Zlci10ZXh0LWdyYXk6aG92ZXJ7Y29sb3I6Izc1NzU3NSFpbXBvcnRhbnR9XHJcbi53My10ZXh0LWxpZ2h0LWdyZXksLnczLWhvdmVyLXRleHQtbGlnaHQtZ3JleTpob3ZlciwudzMtdGV4dC1saWdodC1ncmF5LC53My1ob3Zlci10ZXh0LWxpZ2h0LWdyYXk6aG92ZXJ7Y29sb3I6I2YxZjFmMSFpbXBvcnRhbnR9XHJcbi53My10ZXh0LWRhcmstZ3JleSwudzMtaG92ZXItdGV4dC1kYXJrLWdyZXk6aG92ZXIsLnczLXRleHQtZGFyay1ncmF5LC53My1ob3Zlci10ZXh0LWRhcmstZ3JheTpob3Zlcntjb2xvcjojM2EzYTNhIWltcG9ydGFudH1cclxuLnczLWJvcmRlci1hbWJlciwudzMtaG92ZXItYm9yZGVyLWFtYmVyOmhvdmVye2JvcmRlci1jb2xvcjojZmZjMTA3IWltcG9ydGFudH1cclxuLnczLWJvcmRlci1hcXVhLC53My1ob3Zlci1ib3JkZXItYXF1YTpob3Zlcntib3JkZXItY29sb3I6IzAwZmZmZiFpbXBvcnRhbnR9XHJcbi53My1ib3JkZXItYmx1ZSwudzMtaG92ZXItYm9yZGVyLWJsdWU6aG92ZXJ7Ym9yZGVyLWNvbG9yOiMyMTk2RjMhaW1wb3J0YW50fVxyXG4udzMtYm9yZGVyLWxpZ2h0LWJsdWUsLnczLWhvdmVyLWJvcmRlci1saWdodC1ibHVlOmhvdmVye2JvcmRlci1jb2xvcjojODdDRUVCIWltcG9ydGFudH1cclxuLnczLWJvcmRlci1icm93biwudzMtaG92ZXItYm9yZGVyLWJyb3duOmhvdmVye2JvcmRlci1jb2xvcjojNzk1NTQ4IWltcG9ydGFudH1cclxuLnczLWJvcmRlci1jeWFuLC53My1ob3Zlci1ib3JkZXItY3lhbjpob3Zlcntib3JkZXItY29sb3I6IzAwYmNkNCFpbXBvcnRhbnR9XHJcbi53My1ib3JkZXItYmx1ZS1ncmV5LC53My1ob3Zlci1ib3JkZXItYmx1ZS1ncmV5OmhvdmVyLC53My1ib3JkZXItYmx1ZS1ncmF5LC53My1ob3Zlci1ib3JkZXItYmx1ZS1ncmF5OmhvdmVye2JvcmRlci1jb2xvcjojNjA3ZDhiIWltcG9ydGFudH1cclxuLnczLWJvcmRlci1ncmVlbiwudzMtaG92ZXItYm9yZGVyLWdyZWVuOmhvdmVye2JvcmRlci1jb2xvcjojNENBRjUwIWltcG9ydGFudH1cclxuLnczLWJvcmRlci1saWdodC1ncmVlbiwudzMtaG92ZXItYm9yZGVyLWxpZ2h0LWdyZWVuOmhvdmVye2JvcmRlci1jb2xvcjojOGJjMzRhIWltcG9ydGFudH1cclxuLnczLWJvcmRlci1pbmRpZ28sLnczLWhvdmVyLWJvcmRlci1pbmRpZ286aG92ZXJ7Ym9yZGVyLWNvbG9yOiMzZjUxYjUhaW1wb3J0YW50fVxyXG4udzMtYm9yZGVyLWtoYWtpLC53My1ob3Zlci1ib3JkZXIta2hha2k6aG92ZXJ7Ym9yZGVyLWNvbG9yOiNmMGU2OGMhaW1wb3J0YW50fVxyXG4udzMtYm9yZGVyLWxpbWUsLnczLWhvdmVyLWJvcmRlci1saW1lOmhvdmVye2JvcmRlci1jb2xvcjojY2RkYzM5IWltcG9ydGFudH1cclxuLnczLWJvcmRlci1vcmFuZ2UsLnczLWhvdmVyLWJvcmRlci1vcmFuZ2U6aG92ZXJ7Ym9yZGVyLWNvbG9yOiNmZjk4MDAhaW1wb3J0YW50fVxyXG4udzMtYm9yZGVyLWRlZXAtb3JhbmdlLC53My1ob3Zlci1ib3JkZXItZGVlcC1vcmFuZ2U6aG92ZXJ7Ym9yZGVyLWNvbG9yOiNmZjU3MjIhaW1wb3J0YW50fVxyXG4udzMtYm9yZGVyLXBpbmssLnczLWhvdmVyLWJvcmRlci1waW5rOmhvdmVye2JvcmRlci1jb2xvcjojZTkxZTYzIWltcG9ydGFudH1cclxuLnczLWJvcmRlci1wdXJwbGUsLnczLWhvdmVyLWJvcmRlci1wdXJwbGU6aG92ZXJ7Ym9yZGVyLWNvbG9yOiM5YzI3YjAhaW1wb3J0YW50fVxyXG4udzMtYm9yZGVyLWRlZXAtcHVycGxlLC53My1ob3Zlci1ib3JkZXItZGVlcC1wdXJwbGU6aG92ZXJ7Ym9yZGVyLWNvbG9yOiM2NzNhYjchaW1wb3J0YW50fVxyXG4udzMtYm9yZGVyLXJlZCwudzMtaG92ZXItYm9yZGVyLXJlZDpob3Zlcntib3JkZXItY29sb3I6I2Y0NDMzNiFpbXBvcnRhbnR9XHJcbi53My1ib3JkZXItc2FuZCwudzMtaG92ZXItYm9yZGVyLXNhbmQ6aG92ZXJ7Ym9yZGVyLWNvbG9yOiNmZGY1ZTYhaW1wb3J0YW50fVxyXG4udzMtYm9yZGVyLXRlYWwsLnczLWhvdmVyLWJvcmRlci10ZWFsOmhvdmVye2JvcmRlci1jb2xvcjojMDA5Njg4IWltcG9ydGFudH1cclxuLnczLWJvcmRlci15ZWxsb3csLnczLWhvdmVyLWJvcmRlci15ZWxsb3c6aG92ZXJ7Ym9yZGVyLWNvbG9yOiNmZmViM2IhaW1wb3J0YW50fVxyXG4udzMtYm9yZGVyLXdoaXRlLC53My1ob3Zlci1ib3JkZXItd2hpdGU6aG92ZXJ7Ym9yZGVyLWNvbG9yOiNmZmYhaW1wb3J0YW50fVxyXG4udzMtYm9yZGVyLWJsYWNrLC53My1ob3Zlci1ib3JkZXItYmxhY2s6aG92ZXJ7Ym9yZGVyLWNvbG9yOiMwMDAhaW1wb3J0YW50fVxyXG4udzMtYm9yZGVyLWdyZXksLnczLWhvdmVyLWJvcmRlci1ncmV5OmhvdmVyLC53My1ib3JkZXItZ3JheSwudzMtaG92ZXItYm9yZGVyLWdyYXk6aG92ZXJ7Ym9yZGVyLWNvbG9yOiM5ZTllOWUhaW1wb3J0YW50fVxyXG4udzMtYm9yZGVyLWxpZ2h0LWdyZXksLnczLWhvdmVyLWJvcmRlci1saWdodC1ncmV5OmhvdmVyLC53My1ib3JkZXItbGlnaHQtZ3JheSwudzMtaG92ZXItYm9yZGVyLWxpZ2h0LWdyYXk6aG92ZXJ7Ym9yZGVyLWNvbG9yOiNmMWYxZjEhaW1wb3J0YW50fVxyXG4udzMtYm9yZGVyLWRhcmstZ3JleSwudzMtaG92ZXItYm9yZGVyLWRhcmstZ3JleTpob3ZlciwudzMtYm9yZGVyLWRhcmstZ3JheSwudzMtaG92ZXItYm9yZGVyLWRhcmstZ3JheTpob3Zlcntib3JkZXItY29sb3I6IzYxNjE2MSFpbXBvcnRhbnR9XHJcbi53My1ib3JkZXItcGFsZS1yZWQsLnczLWhvdmVyLWJvcmRlci1wYWxlLXJlZDpob3Zlcntib3JkZXItY29sb3I6I2ZmZTdlNyFpbXBvcnRhbnR9LnczLWJvcmRlci1wYWxlLWdyZWVuLC53My1ob3Zlci1ib3JkZXItcGFsZS1ncmVlbjpob3Zlcntib3JkZXItY29sb3I6I2U3ZmZlNyFpbXBvcnRhbnR9XHJcbi53My1ib3JkZXItcGFsZS15ZWxsb3csLnczLWhvdmVyLWJvcmRlci1wYWxlLXllbGxvdzpob3Zlcntib3JkZXItY29sb3I6I2ZmZmZjYyFpbXBvcnRhbnR9LnczLWJvcmRlci1wYWxlLWJsdWUsLnczLWhvdmVyLWJvcmRlci1wYWxlLWJsdWU6aG92ZXJ7Ym9yZGVyLWNvbG9yOiNlN2ZmZmYhaW1wb3J0YW50fSJdfQ== */"

/***/ }),

/***/ "./src/app/home-list/home-list.component.html":
/*!****************************************************!*\
  !*** ./src/app/home-list/home-list.component.html ***!
  \****************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n\n\n  <div  *ngFor= \"let movie of movies\"  class=\"panel-group\" style=\"margin: auto;margin-bottom: 20px;max-width: 60%;\" id=\"accordion\">\n    <div  class=\"panel panel-info\">\n      <div class=\"panel-heading\">\n        <h4 class=\"panel-title\">\n          <a data-toggle=\"collapse\" data-parent=\"#accordion\" routerLink=\"/movie/{{movie._id}}\">{{movie.name}}</a>\n        </h4>\n      </div>\n      <div id=\"collapse1\" class=\"panel-collapse collapse in\">\n        <div class=\"panel-body\">Lorem ipsum dolor sit amet, consectetur adipisicing elit,\n        sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,\n        quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</div>\n      </div>\n    </div>\n   \n  </div> "

/***/ }),

/***/ "./src/app/home-list/home-list.component.ts":
/*!**************************************************!*\
  !*** ./src/app/home-list/home-list.component.ts ***!
  \**************************************************/
/*! exports provided: HomeListComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HomeListComponent", function() { return HomeListComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _movie_service_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../movie-service.service */ "./src/app/movie-service.service.ts");



var HomeListComponent = /** @class */ (function () {
    function HomeListComponent(movieService) {
        this.movieService = movieService;
    }
    HomeListComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.movieService
            .getMovies()
            .then(function (movies) {
            _this.movies = movies.map(function (movie) {
                return movie;
            });
        });
    };
    HomeListComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-home-list',
            template: __webpack_require__(/*! ./home-list.component.html */ "./src/app/home-list/home-list.component.html"),
            providers: [_movie_service_service__WEBPACK_IMPORTED_MODULE_2__["MovieServiceService"]],
            styles: [__webpack_require__(/*! ./home-list.component.css */ "./src/app/home-list/home-list.component.css")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_movie_service_service__WEBPACK_IMPORTED_MODULE_2__["MovieServiceService"]])
    ], HomeListComponent);
    return HomeListComponent;
}());



/***/ }),

/***/ "./src/app/homepage/homepage.component.css":
/*!*************************************************!*\
  !*** ./src/app/homepage/homepage.component.css ***!
  \*************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".bodyContent{\r\n    padding: 20px;\r\n}\r\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvaG9tZXBhZ2UvaG9tZXBhZ2UuY29tcG9uZW50LmNzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtJQUNJLGFBQWE7QUFDakIiLCJmaWxlIjoic3JjL2FwcC9ob21lcGFnZS9ob21lcGFnZS5jb21wb25lbnQuY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLmJvZHlDb250ZW50e1xyXG4gICAgcGFkZGluZzogMjBweDtcclxufSJdfQ== */"

/***/ }),

/***/ "./src/app/homepage/homepage.component.html":
/*!**************************************************!*\
  !*** ./src/app/homepage/homepage.component.html ***!
  \**************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<body>\n<div class=\"bodyContent\">\n<app-header class=\"context\" [content]=\"pageContent.header\"></app-header>\n<app-home-list></app-home-list>\n</div>\n</body>"

/***/ }),

/***/ "./src/app/homepage/homepage.component.ts":
/*!************************************************!*\
  !*** ./src/app/homepage/homepage.component.ts ***!
  \************************************************/
/*! exports provided: HomepageComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HomepageComponent", function() { return HomepageComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");


var HomepageComponent = /** @class */ (function () {
    function HomepageComponent() {
        this.pageContent = {
            header: {
                title: 'Now Showing',
                body: 'Latest 2019 Bollywood Movies'
            }
        };
    }
    HomepageComponent.prototype.ngOnInit = function () { };
    HomepageComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-homepage',
            template: __webpack_require__(/*! ./homepage.component.html */ "./src/app/homepage/homepage.component.html"),
            styles: [__webpack_require__(/*! ./homepage.component.css */ "./src/app/homepage/homepage.component.css")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [])
    ], HomepageComponent);
    return HomepageComponent;
}());



/***/ }),

/***/ "./src/app/movie-service.service.ts":
/*!******************************************!*\
  !*** ./src/app/movie-service.service.ts ***!
  \******************************************/
/*! exports provided: MovieServiceService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MovieServiceService", function() { return MovieServiceService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/http */ "./node_modules/@angular/http/fesm5/http.js");



var MovieServiceService = /** @class */ (function () {
    function MovieServiceService(http) {
        this.http = http;
        this.moviesUrl = 'http://localhost:3000/api/movies';
    }
    MovieServiceService.prototype.getMovies = function () {
        return this.http.get(this.moviesUrl)
            .toPromise()
            .then(function (response) { return response.json(); })
            .catch(this.handleError);
    };
    MovieServiceService.prototype.getSingleMovie = function (movieId) {
        return this.http.get(this.moviesUrl + '/' + movieId)
            .toPromise()
            .then(function (response) { return response.json(); })
            .catch(this.handleError);
    };
    MovieServiceService.prototype.createMovie = function (newMovie) {
        return this.http.post(this.moviesUrl, newMovie)
            .toPromise()
            .then(function (response) { return response.json(); })
            .catch(this.handleError);
    };
    MovieServiceService.prototype.handleError = function (error) {
        console.log("error");
    };
    MovieServiceService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_http__WEBPACK_IMPORTED_MODULE_2__["Http"]])
    ], MovieServiceService);
    return MovieServiceService;
}());



/***/ }),

/***/ "./src/app/moviestore/moviestore.component.css":
/*!*****************************************************!*\
  !*** ./src/app/moviestore/moviestore.component.css ***!
  \*****************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "div.gallery {\r\n  border: 1px solid #ccc;\r\n}\r\n\r\ndiv.gallery:hover {\r\n  border: 1px solid #777;\r\n}\r\n\r\ndiv.gallery img {\r\n  width: 100%;\r\n  height: auto;\r\n}\r\n\r\ndiv.desc {\r\n  padding: 15px;\r\n  text-align: center;\r\n    background-color: #2ea1c1;\r\n    color: white;\r\n}\r\n\r\n* {\r\n  box-sizing: border-box;\r\n}\r\n\r\n.responsive {\r\n  padding: 0 6px;\r\n  float: left;\r\n  width: 20%;\r\n    margin: 38px;\r\n}\r\n\r\n@media only screen and (max-width: 700px) {\r\n  .responsive {\r\n    width: 49.99999%;\r\n    margin: 6px 0;\r\n  }\r\n}\r\n\r\n@media only screen and (max-width: 500px) {\r\n  .responsive {\r\n    width: 100%;\r\n  }\r\n}\r\n\r\n.clearfix:after {\r\n  content: \"\";\r\n  display: table;\r\n  clear: both;\r\n}\r\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvbW92aWVzdG9yZS9tb3ZpZXN0b3JlLmNvbXBvbmVudC5jc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSxzQkFBc0I7QUFDeEI7O0FBRUE7RUFDRSxzQkFBc0I7QUFDeEI7O0FBRUE7RUFDRSxXQUFXO0VBQ1gsWUFBWTtBQUNkOztBQUVBO0VBQ0UsYUFBYTtFQUNiLGtCQUFrQjtJQUNoQix5QkFBeUI7SUFDekIsWUFBWTtBQUNoQjs7QUFFQTtFQUNFLHNCQUFzQjtBQUN4Qjs7QUFFQTtFQUNFLGNBQWM7RUFDZCxXQUFXO0VBQ1gsVUFBVTtJQUNSLFlBQVk7QUFDaEI7O0FBRUE7RUFDRTtJQUNFLGdCQUFnQjtJQUNoQixhQUFhO0VBQ2Y7QUFDRjs7QUFFQTtFQUNFO0lBQ0UsV0FBVztFQUNiO0FBQ0Y7O0FBRUE7RUFDRSxXQUFXO0VBQ1gsY0FBYztFQUNkLFdBQVc7QUFDYiIsImZpbGUiOiJzcmMvYXBwL21vdmllc3RvcmUvbW92aWVzdG9yZS5jb21wb25lbnQuY3NzIiwic291cmNlc0NvbnRlbnQiOlsiZGl2LmdhbGxlcnkge1xyXG4gIGJvcmRlcjogMXB4IHNvbGlkICNjY2M7XHJcbn1cclxuXHJcbmRpdi5nYWxsZXJ5OmhvdmVyIHtcclxuICBib3JkZXI6IDFweCBzb2xpZCAjNzc3O1xyXG59XHJcblxyXG5kaXYuZ2FsbGVyeSBpbWcge1xyXG4gIHdpZHRoOiAxMDAlO1xyXG4gIGhlaWdodDogYXV0bztcclxufVxyXG5cclxuZGl2LmRlc2Mge1xyXG4gIHBhZGRpbmc6IDE1cHg7XHJcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogIzJlYTFjMTtcclxuICAgIGNvbG9yOiB3aGl0ZTtcclxufVxyXG5cclxuKiB7XHJcbiAgYm94LXNpemluZzogYm9yZGVyLWJveDtcclxufVxyXG5cclxuLnJlc3BvbnNpdmUge1xyXG4gIHBhZGRpbmc6IDAgNnB4O1xyXG4gIGZsb2F0OiBsZWZ0O1xyXG4gIHdpZHRoOiAyMCU7XHJcbiAgICBtYXJnaW46IDM4cHg7XHJcbn1cclxuXHJcbkBtZWRpYSBvbmx5IHNjcmVlbiBhbmQgKG1heC13aWR0aDogNzAwcHgpIHtcclxuICAucmVzcG9uc2l2ZSB7XHJcbiAgICB3aWR0aDogNDkuOTk5OTklO1xyXG4gICAgbWFyZ2luOiA2cHggMDtcclxuICB9XHJcbn1cclxuXHJcbkBtZWRpYSBvbmx5IHNjcmVlbiBhbmQgKG1heC13aWR0aDogNTAwcHgpIHtcclxuICAucmVzcG9uc2l2ZSB7XHJcbiAgICB3aWR0aDogMTAwJTtcclxuICB9XHJcbn1cclxuXHJcbi5jbGVhcmZpeDphZnRlciB7XHJcbiAgY29udGVudDogXCJcIjtcclxuICBkaXNwbGF5OiB0YWJsZTtcclxuICBjbGVhcjogYm90aDtcclxufSJdfQ== */"

/***/ }),

/***/ "./src/app/moviestore/moviestore.component.html":
/*!******************************************************!*\
  !*** ./src/app/moviestore/moviestore.component.html ***!
  \******************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<h2 style=\"    margin-left: 40px;\">Coming Soon</h2>\n<h4 style=\"    margin-left: 40px;\">Thriller and Entertainment Forever</h4>\n\n<div class=\"responsive\">\n  <div class=\"gallery\">\n    <a target=\"_blank\" href=\"img_5terre.jpg\">\n      <img src=\"https://m.media-amazon.com/images/M/MV5BMDVjZGE2ZTEtYzI3Zi00MzY1LTg5ZGItNWRmZDY4MzM2OTM0XkEyXkFqcGdeQXVyNDExMzMxNjE@._V1_UY209_CR0,0,140,209_AL_.jpg\" alt=\"Cinque Terre\" width=\"600\" height=\"400\">\n    </a>\n    <div class=\"desc\">Master Z</div>\n  </div>\n</div>\n\n\n<div class=\"responsive\">\n  <div class=\"gallery\">\n    <a target=\"_blank\" href=\"img_forest.jpg\">\n      <img src=\"https://m.media-amazon.com/images/M/MV5BOTYwODFjOTktNjdmMi00MDRhLTg4NGMtNGY1NTU0NDYwY2QzXkEyXkFqcGdeQXVyMDA4NzMyOA@@._V1_UY209_CR0,0,140,209_AL_.jpg\" alt=\"Forest\" width=\"600\" height=\"400\">\n    </a>\n    <div class=\"desc\">A Dark Place</div>\n  </div>\n</div>\n\n<div class=\"responsive\">\n  <div class=\"gallery\">\n    <a target=\"_blank\" href=\"img_lights.jpg\">\n      <img src=\"https://m.media-amazon.com/images/M/MV5BMTE0YWFmOTMtYTU2ZS00ZTIxLWE3OTEtYTNiYzBkZjViZThiXkEyXkFqcGdeQXVyODMzMzQ4OTI@._V1_UY209_CR0,0,140,209_AL_.jpg\" alt=\"Northern Lights\" width=\"600\" height=\"400\">\n    </a>\n    <div class=\"desc\">Captain Marvel</div>\n  </div>\n</div>\n\n<div class=\"responsive\">\n  <div class=\"gallery\">\n    <a target=\"_blank\" href=\"img_mountains.jpg\">\n      <img src=\"https://m.media-amazon.com/images/M/MV5BMTU2ODk2ODEzMV5BMl5BanBnXkFtZTgwMzk1OTk4NjM@._V1_UX140_CR0,0,140,209_AL_.jpg\" alt=\"Mountains\" width=\"600\" height=\"400\">\n    </a>\n    <div class=\"desc\">Break Through</div>\n  </div>\n</div>\n\n<div class=\"clearfix\"></div>\n\n<div style=\"padding:6px;    margin-left: 40px;\">\n  <p>Find showtimes, watch trailers, browse photos, track your Watchlist and rate your favorite movies and TV shows on your phone or tablet!</p>\n  <p>Which of these top rated Indian movies of the 2000s is your favorite? Discuss here after voting.</p>\n</div>\n"

/***/ }),

/***/ "./src/app/moviestore/moviestore.component.ts":
/*!****************************************************!*\
  !*** ./src/app/moviestore/moviestore.component.ts ***!
  \****************************************************/
/*! exports provided: MoviestoreComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MoviestoreComponent", function() { return MoviestoreComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");


var MoviestoreComponent = /** @class */ (function () {
    function MoviestoreComponent() {
    }
    MoviestoreComponent.prototype.ngOnInit = function () {
    };
    MoviestoreComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-moviestore',
            template: __webpack_require__(/*! ./moviestore.component.html */ "./src/app/moviestore/moviestore.component.html"),
            styles: [__webpack_require__(/*! ./moviestore.component.css */ "./src/app/moviestore/moviestore.component.css")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [])
    ], MoviestoreComponent);
    return MoviestoreComponent;
}());



/***/ }),

/***/ "./src/environments/environment.ts":
/*!*****************************************!*\
  !*** ./src/environments/environment.ts ***!
  \*****************************************/
/*! exports provided: environment */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "environment", function() { return environment; });
// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.
var environment = {
    production: false
};
/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.


/***/ }),

/***/ "./src/main.ts":
/*!*********************!*\
  !*** ./src/main.ts ***!
  \*********************/
/*! no exports provided */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/platform-browser-dynamic */ "./node_modules/@angular/platform-browser-dynamic/fesm5/platform-browser-dynamic.js");
/* harmony import */ var _app_app_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./app/app.module */ "./src/app/app.module.ts");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./environments/environment */ "./src/environments/environment.ts");




if (_environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].production) {
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["enableProdMode"])();
}
Object(_angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_1__["platformBrowserDynamic"])().bootstrapModule(_app_app_module__WEBPACK_IMPORTED_MODULE_2__["AppModule"])
    .catch(function (err) { return console.error(err); });


/***/ }),

/***/ 0:
/*!***************************!*\
  !*** multi ./src/main.ts ***!
  \***************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(/*! C:\Users\NSutariya4919\Downloads\MovieStore\movie-public\src\main.ts */"./src/main.ts");


/***/ })

},[[0,"runtime","vendor"]]]);
//# sourceMappingURL=main.js.map