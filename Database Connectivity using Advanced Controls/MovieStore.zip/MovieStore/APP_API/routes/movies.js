//Importing the Express
const express = require('express');

const router = express.Router();

const ctrlMovie = require('../controllers/movie');


//LIst of movies
router.get('/movies',ctrlMovie.getMovies);

//Posting to DB
router.post('/movies',ctrlMovie.createMovie);


//Details of Movie
router.get('/movies/:movieid',ctrlMovie.getSingleMovie);

//Edit the movie
router.put('/movies/:movieid',ctrlMovie.updateMovie);

//Delete the moveie
router.delete('/movies/:movieid',ctrlMovie.deleteMovie);



module.exports = router;