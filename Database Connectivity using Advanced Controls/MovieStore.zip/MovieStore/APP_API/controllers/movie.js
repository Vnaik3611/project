const mongoose = require('mongoose');

//importing th model scehma
const Movie = mongoose.model('Movie');


// Getting a List of MOvies
const getMovies=function(req,res){
    Movie.find().exec(function(err, moviedata) {
        if(err){
          res
          .status(404)
        .json(err);
    return;
    }
    res
    .status(200)
    .json(moviedata);
    });
};

//Posting a MOvie To Database
const createMovie=function(req,res){
   Movie.create({
       name:req.body.name,
       type:req.body.type,
       year:req.body.year,      
       rating:req.body.rating
      
   }, (err, moviedata)=>{
      if (err) {
       res
       .status(400)
       .json(err);
   } else {
       res
       .status(201)
       .json(moviedata);
   }
   });
};

//Gettting details of aSingle Movie when User Clicks a MOvie NAme
const getSingleMovie=function(req,res){
    res
    Movie.findById(req.params.movieid)
    .exec((err,movie) => {
        if(!movie){
            return res 
               .status(404)
               .json({"message": "movie not found"});
        } else if (err) {
            return res 
                  .status(404)
                  .json(err);
        }
        res 
            .status(200)
            .json(movie);
        });
    };
       
const createMovies=function(req,res){
    res
    .status(200)
    .json({"status":"success"});
};

//Updating the Database value 
const updateMovie=function(req,res){
    if(!req.params.movieid){
        res
        .status(404)
        .json({"message": "Not found, movieid is required"});
        return;
    }
Movie.findById(req.params.movieid)
    .exec((err, moviedata)=>{
        if(!moviedata){
            res
            .json(404)
            .status({"message": "movieid not found"});
            return;
        } else if (err){
            res 
            .status(400)
            .json(err);
            return;
        }
    moviedata.name = req.body.name;
    moviedata.type = req.body.type;
     moviedata.year = req.body.year;
     moviedata.rating = req.body.rating;
    moviedata.save((err,moviedata) => {
        if(err){
            res
            .status(404)
            .json(err);
        } else{
            res
            .status(200)
            .json(moviedata);
         }
    });
    });

};


//Delete particular MOvie
const deleteMovie=function(req,res){
   const movieid = req.params.movieid;
   
    if (movieid){
        Movie
        .findByIdAndRemove(movieid)
        .exec((err,moviedata) =>{
        if(err){
            res
            .status(404)
            .json(err);
        return;
        }
    res
    .status(204)
    .json(null);
     });
    }
    else{
        res
        .status(404)
        .json({"message": "No movieid"});
    }
};
   

//Exporting  all functions
module.exports={
    getMovies,
    createMovie,
    getSingleMovie,
    updateMovie,
    deleteMovie
};



module.exports = {
    getMovies,
    createMovie,
    updateMovie,
    deleteMovie,
    getSingleMovie
};

