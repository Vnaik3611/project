package com.example.littleindia;

import android.os.Parcel;
import android.os.Parcelable;

import java.util.ArrayList;

public class Product implements Parcelable {

    private String Name,Price;
    private int Image;
    private float Rating;
    private ArrayList<String> ingridents;

    public Product(){

    }
    protected Product(Parcel in) {
        Name = in.readString();
        Price = in.readString();
        Image = in.readInt();
        Rating = in.readFloat();
        ingridents = in.createStringArrayList();
    }

    public static final Creator<Product> CREATOR = new Creator<Product>() {
        @Override
        public Product createFromParcel(Parcel in) {
            return new Product(in);
        }

        @Override
        public Product[] newArray(int size) {
            return new Product[size];
        }
    };

    public String getName() {
        return Name;
    }

    public void setName(String name) {
        Name = name;
    }

    public String getPrice() {
        return Price;
    }

    public void setPrice(String price) {
        Price = price;
    }

    public int getImage() {
        return Image;
    }

    public void setImage(int image) {
        Image = image;
    }

    public float getRating() {
        return Rating;
    }

    public void setRating(float rating) {
        Rating = rating;
    }

    public ArrayList<String> getIngridents() {
        return ingridents;
    }

    public void setIngridents(ArrayList<String> ingridents) {
        this.ingridents = ingridents;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(Name);
        dest.writeString(Price);
        dest.writeInt(Image);
        dest.writeFloat(Rating);
        dest.writeStringList(ingridents);
    }
}
