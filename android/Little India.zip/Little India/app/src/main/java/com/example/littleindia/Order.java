package com.example.littleindia;

import android.os.Parcel;
import android.os.Parcelable;

import java.util.ArrayList;

import javax.security.auth.PrivateCredentialPermission;

public class Order implements Parcelable {

    private Product product;
    private String name,email,address,paymentMode,date;

    public Order(){

    }

    protected Order(Parcel in) {
        product = in.readParcelable(Product.class.getClassLoader());
        name = in.readString();
        email = in.readString();
        address = in.readString();
        paymentMode = in.readString();
        date = in.readString();
    }

    public static final Creator<Order> CREATOR = new Creator<Order>() {
        @Override
        public Order createFromParcel(Parcel in) {
            return new Order(in);
        }

        @Override
        public Order[] newArray(int size) {
            return new Order[size];
        }
    };

    public Product getProduct() {
        return product;
    }

    public void setProduct(Product product) {
        this.product = product;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getPaymentMode() {
        return paymentMode;
    }

    public void setPaymentMode(String paymentMode) {
        this.paymentMode = paymentMode;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeParcelable(product, flags);
        dest.writeString(name);
        dest.writeString(email);
        dest.writeString(address);
        dest.writeString(paymentMode);
        dest.writeString(date);
    }
}
