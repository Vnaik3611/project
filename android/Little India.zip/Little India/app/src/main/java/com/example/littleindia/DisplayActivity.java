package com.example.littleindia;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;

public class DisplayActivity extends AppCompatActivity {

    Product mProduct;
    TextView mTvPrDetName, mTvPrDetPrice;
    RatingBar mRatingBar;
    ImageView mIvPrDetImage;
    RecyclerView mRvIngri;
    IngreAdapter ingreAdapter;
    LinearLayoutManager linearLayoutManager;
    Button mBtnBuy;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_display);
        getSupportActionBar().setTitle("Product Details");
        mProduct = new Product();
        Bundle bundle = getIntent().getExtras();
        mProduct = bundle.getParcelable("product");

        mTvPrDetName = findViewById(R.id.tvPrDetName);
        mTvPrDetPrice = findViewById(R.id.tvPrDetPrice);
        mRatingBar = findViewById(R.id.ratingPrDet);
        mIvPrDetImage = findViewById(R.id.ivProductDetPrImg);
        mRvIngri = findViewById(R.id.rvPrDetIngridients);
        linearLayoutManager=new LinearLayoutManager(this);
        linearLayoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        ingreAdapter=new IngreAdapter();
        mBtnBuy=findViewById(R.id.btnPrDetBuy);

        mIvPrDetImage.setImageResource(mProduct.getImage());
        mTvPrDetPrice.setText("Price :- $ " + mProduct.getPrice());
        mRatingBar.setRating(mProduct.getRating());
        mTvPrDetName.setText(mProduct.getName());

        mRvIngri.setAdapter(ingreAdapter);
        mRvIngri.setLayoutManager(linearLayoutManager);

        mBtnBuy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Bundle bundle=new Bundle();
                bundle.putParcelable("product",mProduct);
                startActivity(new Intent(DisplayActivity.this,CheckoutActivity.class).putExtras(bundle));
            }
        });

    }

    class IngriViewHolder extends RecyclerView.ViewHolder {
        TextView mTvIngri;

        public IngriViewHolder(@NonNull View itemView) {
            super(itemView);
            mTvIngri=itemView.findViewById(R.id.tvIngri);
        }
    }

    class IngreAdapter extends RecyclerView.Adapter<IngriViewHolder>
    {

        @NonNull
        @Override
        public IngriViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
            View view= LayoutInflater.from(DisplayActivity.this).inflate(R.layout.ingre_item_layout,viewGroup,false);
            IngriViewHolder ingriViewHolder =new IngriViewHolder(view);
            return ingriViewHolder;
        }

        @Override
        public void onBindViewHolder(@NonNull IngriViewHolder ingriViewHolder, int i) {

            ingriViewHolder.mTvIngri.setText(mProduct.getIngridents().get(i));
        }

        @Override
        public int getItemCount() {
            return mProduct.getIngridents().size();
        }
    }

    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu,menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        if(item.getItemId()==R.id.menu_OH)
        {
            startActivity(new Intent(DisplayActivity.this,OrderHistoryActivity.class));
        }

        return super.onOptionsItemSelected(item);
    }
}
