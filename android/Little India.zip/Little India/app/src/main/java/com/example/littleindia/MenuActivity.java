package com.example.littleindia;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.TextView;

import java.util.ArrayList;

public class MenuActivity extends AppCompatActivity {


    ArrayList<Product> mProducts;
    RecyclerView mRvProducts;
    ProductAdapter productAdapter;
    LinearLayoutManager linearLayoutManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);

        getSupportActionBar().setTitle("Menu");

        mProducts = new ArrayList<>();
        mRvProducts = findViewById(R.id.rvProducts);
        linearLayoutManager = new LinearLayoutManager(this);
        linearLayoutManager.setOrientation(LinearLayoutManager.VERTICAL);

        Product product = new Product();
        ArrayList<String> ingredients=new ArrayList<>();
        ingredients.add("Chicken");
        ingredients.add("Yogurt");
        ingredients.add("Honey");
        ingredients.add("Tandoori masala");
        product.setName("Chicken Tandoori");
        product.setPrice("15");
        product.setImage(R.drawable.chicken_tandori);
        product.setRating(4);
        product.setIngridents(ingredients);

        Product product1 = new Product();
        ArrayList<String> ingredients1=new ArrayList<>();
        ingredients1.add("Paneer");
        ingredients1.add("Cream");
        ingredients1.add("Tomatoes");
        ingredients1.add("Spices");
        product1.setName("Sahi Paneer");
        product1.setPrice("10");
        product1.setImage(R.drawable.shahi_paneer);
        product1.setRating((float) 3.5);
        product1.setIngridents(ingredients1);

        Product product3 = new Product();
        ArrayList<String> ingredients3=new ArrayList<>();
        ingredients3.add("Large Potatoes");
        ingredients3.add("Paneer");
        ingredients3.add("Maida");
        ingredients3.add("Onions");
        ingredients3.add("Malai");
        product3.setName("Malai Kofta");
        product3.setPrice("20");
        product3.setImage(R.drawable.malai_kofta);
        product3.setRating((float) 5);
        product3.setIngridents(ingredients3);

        Product product4 = new Product();
        ArrayList<String> ingredients4=new ArrayList<>();
        ingredients4.add("Rajma");
        ingredients4.add("Urad dal");
        product4.setName("Daal Makhni");
        product4.setPrice("15");
        product4.setImage(R.drawable.dal_makhani);
        product4.setRating((float) 5);
        product4.setIngridents(ingredients4);

        Product product5 = new Product();
        ArrayList<String> ingredients5=new ArrayList<>();
        ingredients5.add("Yogurt");
        ingredients5.add("Cream");
        ingredients5.add("Chicken");
        product5.setName("Chicken Korma");
        product5.setPrice("25");
        product5.setImage(R.drawable.chicken_korma);
        product5.setRating((float) 1.5);
        product5.setIngridents(ingredients5);

        mProducts.add(product);
        mProducts.add(product1);
        mProducts.add(product3);
        mProducts.add(product4);
        mProducts.add(product5);

        productAdapter = new ProductAdapter();
        mRvProducts.setAdapter(productAdapter);
        mRvProducts.setLayoutManager(linearLayoutManager);

    }

    public class ProductViewHolder extends RecyclerView.ViewHolder {

        TextView mProductName, mProductPrice;
        ImageView mIvProduct, mIvViewProduct;
        RatingBar mRatings;

        public ProductViewHolder(@NonNull View itemView) {
            super(itemView);

            mProductName = itemView.findViewById(R.id.tvOHProductName);
            mProductPrice = itemView.findViewById(R.id.tvOhPrice);
            mIvProduct = itemView.findViewById(R.id.ivOHProductImg);
            mIvViewProduct = itemView.findViewById(R.id.ivViewProduct);
            mRatings = itemView.findViewById(R.id.productRatings);

        }
    }

    public class ProductAdapter extends RecyclerView.Adapter<ProductViewHolder> {

        @NonNull
        @Override
        public ProductViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
            View view = LayoutInflater.from(MenuActivity.this).inflate(R.layout.product_item_layout, viewGroup, false);
            ProductViewHolder productViewHolder = new ProductViewHolder(view);
            return productViewHolder;
        }

        @Override
        public void onBindViewHolder(@NonNull ProductViewHolder productViewHolder, int i) {

            final Product product = mProducts.get(i);
            productViewHolder.mProductName.setText(product.getName());
            productViewHolder.mProductPrice.setText("Price :- $ " + product.getPrice());
            productViewHolder.mIvProduct.setImageResource(product.getImage());
            productViewHolder.mRatings.setRating(product.getRating());

            productViewHolder.mIvViewProduct.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                   Bundle bundle=new Bundle();
                   bundle.putParcelable("product",product);
                    startActivity(new Intent(MenuActivity.this,DisplayActivity.class).putExtras(bundle));
                }
            });

        }

        @Override
        public int getItemCount() {
            return mProducts.size();
        }
    }
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu,menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        if(item.getItemId()==R.id.menu_OH)
        {
            startActivity(new Intent(MenuActivity.this,OrderHistoryActivity.class));
        }

        return super.onOptionsItemSelected(item);
    }
}
