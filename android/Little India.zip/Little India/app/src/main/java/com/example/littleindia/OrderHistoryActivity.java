package com.example.littleindia;

import android.content.Intent;
import android.content.SharedPreferences;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.TextView;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.util.ArrayList;

public class OrderHistoryActivity extends AppCompatActivity {

    ArrayList<Order> orders;
    SharedPreferences sharedPreferences;
    RecyclerView mRvOh;
    LinearLayoutManager linearLayoutManager;
    OHAapter ohAapter;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_order_history);
        getSupportActionBar().setTitle("Order History");

        sharedPreferences = getSharedPreferences("OH", MODE_PRIVATE);
        orders = new ArrayList<>();
        mRvOh = findViewById(R.id.rvOh);
        linearLayoutManager = new LinearLayoutManager(this);
        linearLayoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        ohAapter = new OHAapter();


        Gson gson = new Gson();
        String response = sharedPreferences.getString("Orders", "");
        orders = gson.fromJson(response,
                new TypeToken<ArrayList<Order>>() {
                }.getType());

        if (orders != null && orders.size() != 0) {
            mRvOh.setAdapter(ohAapter);
            mRvOh.setLayoutManager(linearLayoutManager);

        }

    }

    class OHViewHOlder extends RecyclerView.ViewHolder {
        TextView mOHProductName, mOHProductPrice, mOHOrderdate, mTvOhIngri;
        ImageView mOHIvProduct;
        RatingBar mOHRatings;
        RecyclerView mRvOHIngri;
        LinearLayoutManager linearLayoutManagerIngri;

        public OHViewHOlder(@NonNull View itemView) {
            super(itemView);

            mOHProductName = itemView.findViewById(R.id.tvOHProductName);
            mTvOhIngri = itemView.findViewById(R.id.tvOhIngri);
            mOHProductPrice = itemView.findViewById(R.id.tvOhPrice);
            mOHIvProduct = itemView.findViewById(R.id.ivOHProductImg);
            mOHOrderdate = itemView.findViewById(R.id.tvOHDate);
            mOHRatings = itemView.findViewById(R.id.ohProductRatings);
            mRvOHIngri = itemView.findViewById(R.id.rvOhIngri);
            linearLayoutManagerIngri = new LinearLayoutManager(OrderHistoryActivity.this);
            linearLayoutManagerIngri.setOrientation(LinearLayoutManager.VERTICAL);

        }
    }

    class OHAapter extends RecyclerView.Adapter<OHViewHOlder> {

        @NonNull
        @Override
        public OHViewHOlder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
            View view = LayoutInflater.from(OrderHistoryActivity.this).inflate(R.layout.order_history_item_layout, viewGroup, false);
            OHViewHOlder ohViewHOlder = new OHViewHOlder(view);
            return ohViewHOlder;
        }

        @Override
        public void onBindViewHolder(@NonNull final OHViewHOlder ohViewHOlder, int i) {
            final Order order = orders.get(i);
            ohViewHOlder.mOHRatings.setRating(order.getProduct().getRating());
            ohViewHOlder.mOHProductName.setText(order.getProduct().getName());
            ohViewHOlder.mOHProductPrice.setText("Price :- $ " + order.getProduct().getPrice());
            ohViewHOlder.mOHIvProduct.setImageResource(order.getProduct().getImage());
            ohViewHOlder.mOHOrderdate.setText("Date :- " + order.getDate());

            ohViewHOlder.mTvOhIngri.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (ohViewHOlder.mRvOHIngri.getVisibility() == View.VISIBLE) {
                        Animation animation = AnimationUtils.loadAnimation(OrderHistoryActivity.this, R.anim.slide_up);
                        ohViewHOlder.mRvOHIngri.setAnimation(animation);
                        ohViewHOlder.mRvOHIngri.setVisibility(View.GONE);
                    } else {
                        Animation animation = AnimationUtils.loadAnimation(OrderHistoryActivity.this, R.anim.slide_down);
                        IngreAdapter ingreAdapter = new IngreAdapter(order.getProduct().getIngridents());
                        ohViewHOlder.mRvOHIngri.setAdapter(ingreAdapter);
                        ohViewHOlder.mRvOHIngri.setLayoutManager(ohViewHOlder.linearLayoutManagerIngri);
                        ohViewHOlder.mRvOHIngri.setVisibility(View.VISIBLE);
                        ohViewHOlder.mRvOHIngri.setAnimation(animation);
                    }
                }
            });
        }

        @Override
        public int getItemCount() {
            return orders.size();
        }
    }

    class IngriViewHolder extends RecyclerView.ViewHolder {
        TextView mTvIngri;

        public IngriViewHolder(@NonNull View itemView) {
            super(itemView);
            mTvIngri = itemView.findViewById(R.id.tvIngri);
        }
    }

    class IngreAdapter extends RecyclerView.Adapter<IngriViewHolder> {
        ArrayList<String> ingredients;

        public IngreAdapter(ArrayList<String> ingredients) {
            this.ingredients = ingredients;
        }

        @NonNull
        @Override
        public IngriViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
            View view = LayoutInflater.from(OrderHistoryActivity.this).inflate(R.layout.ingre_item_layout, viewGroup, false);
            IngriViewHolder ingriViewHolder = new IngriViewHolder(view);
            return ingriViewHolder;
        }

        @Override
        public void onBindViewHolder(@NonNull IngriViewHolder ingriViewHolder, int i) {

            ingriViewHolder.mTvIngri.setText(ingredients.get(i));
        }

        @Override
        public int getItemCount() {
            return ingredients.size();
        }
    }

    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_home, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if(item.getItemId()==R.id.menu_product)
        {
            startActivity(new Intent(OrderHistoryActivity.this,MenuActivity.class));
        }
        return super.onOptionsItemSelected(item);
    }
}
