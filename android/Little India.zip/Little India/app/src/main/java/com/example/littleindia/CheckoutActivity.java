package com.example.littleindia;

import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.TextView;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

public class CheckoutActivity extends AppCompatActivity {

    Product mProduct;
    Button mBtnConfmOdr;
    EditText mEtname, mEtEmail, mEtAddress;
    RadioGroup mRgPaymentMode;
    TextView mTvPrice;
    ArrayList<Order> orders;
    SharedPreferences sharedPreferences;
    SharedPreferences.Editor editor;
    Gson gson;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_checkout);
        getSupportActionBar().setTitle("Check Out");

        mProduct = new Product();
        Bundle bundle = getIntent().getExtras();
        mProduct = bundle.getParcelable("product");

        mBtnConfmOdr = findViewById(R.id.btnChkOutConfmOdr);
        mEtAddress = findViewById(R.id.etChkOutAddress);
        mEtEmail = findViewById(R.id.etChkOutEmail);
        mEtname = findViewById(R.id.etChkOutName);
        mRgPaymentMode = findViewById(R.id.rgChkOut);
        orders = new ArrayList<>();
        mTvPrice = findViewById(R.id.tvCheckOutTotal);
        gson = new Gson();
        sharedPreferences = getSharedPreferences("OH", MODE_PRIVATE);
        if (sharedPreferences.getString("Orders", null) != null) {
            orders = gson.fromJson(sharedPreferences.getString("Orders", ""),
                    new TypeToken<ArrayList<Order>>() {
                    }.getType());
        }
        editor = sharedPreferences.edit();

        mTvPrice.setText("Total :- $ " + mProduct.getPrice());

        mBtnConfmOdr.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (mEtname.getText().toString().equalsIgnoreCase("")) {
                    mEtname.setError("Enter Name");
                } else if (mEtEmail.getText().toString().equalsIgnoreCase("")) {
                    mEtEmail.setError("Enter Email");
                } else if (mEtAddress.getText().toString().equalsIgnoreCase("")) {
                    mEtAddress.setError("Enter Address");
                } else {
                    BookOrder(mProduct);
                }

            }
        });
    }

    private void BookOrder(Product mProduct) {
        String date = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date());
        Order order = new Order();
        order.setAddress(mEtAddress.getText().toString());
        order.setEmail(mEtEmail.getText().toString());
        order.setName(mEtname.getText().toString());
        order.setDate(date);
        order.setPaymentMode(mRgPaymentMode.getCheckedRadioButtonId() == R.id.rbChkOutCash ? "Cash" : "Debit/Credit");
        order.setProduct(mProduct);
        orders.add(order);

        String jsonOrders = gson.toJson(orders);
        editor.remove("Orders").commit();
        editor.putString("Orders", jsonOrders);
        editor.commit();

        startActivity(new Intent(CheckoutActivity.this, OrderHistoryActivity.class));
        finish();

    }

    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        if (item.getItemId() == R.id.menu_OH) {
            startActivity(new Intent(CheckoutActivity.this, OrderHistoryActivity.class));
        }

        return super.onOptionsItemSelected(item);
    }
}
