var margin = {
        top: 10,
        right: 20,
        bottom: 100,
        left: 50
    },
    width = 800 - margin.right - margin.left,
    height = 550 - margin.top - margin.bottom;

var svg = d3.select("body")
    .append("svg")
    .attr({
        "width": width + margin.right + margin.left,
        "height": height + margin.top + margin.bottom
    })
    .append("g")
    .attr("transform", "translate(" + margin.left + "," + margin.right + ")");


// define x and y scales
var xScale = d3.scale.ordinal()
    .rangeRoundBands([0, width], 0.2, 0.2);

var yScale = d3.scale.linear()
    .range([height, 100]);

// define x axis and y axis
var xAxis = d3.svg.axis()
    .scale(xScale)
    .orient("bottom");

var yAxis = d3.svg.axis()
    .scale(yScale)
    .orient("left");

d3.csv("data/countries.csv", function(error, data) {
    if (error) console.log("Data did not load properly!");

    data.forEach(function(d) {
        d.Country = d.Country;
        d.Area = +d.Area;

    });

    // sort the Area values
    data.sort(function(a, b) {
        return b.Area + a.Area;
    });

    // Specify the domains of the x and y scales
    xScale.domain(data.map(function(d) {
        return d.Country;
    }));
    yScale.domain([0, d3.max(data, function(d) {
        return d.Area;
    })]);

    svg.selectAll('rect')
        .data(data)
        .enter()
        .append('rect')
        .attr("height", 0)
        .attr("y", height)
        .transition().duration(1500)
        .delay(function(d, i) {
            return i * 20;
        })
        .attr({
            "x": function(d) {
                return xScale(d.Country);
            },
            "y": function(d) {
                return yScale(d.Area);
            },
            "width": xScale.rangeBand(),
            "height": function(d) {
                return height - yScale(d.Area);
            }
        }).style("fill","skyblue");

    svg.selectAll('text')
        .data(data)
        .enter()
        .append('text')

        .text(function(d) {
            return d.Area;
        })
        .attr({
            "x": function(d) {
                return xScale(d.Country) + xScale.rangeBand() / 2;
            },
            "y": function(d) {
                return yScale(d.Area) + 20;
            },
            "font-family": 'sans-serif',
            "font-size": '15px',
            "font-weight": 'bold',
            "fill": '',
            "text-anchor": 'middle'
        });

    // Draw xAxis and position the label
    svg.append("g")
        .attr("class", "x axis")
        .attr("transform", "translate(0," + height + ")")
        .call(xAxis)
        .selectAll("text")
        .attr("dx", "-.2em")
        .attr("dy", "0.75em")
        .attr("transform", "rotate(-70)")
        .style("text-anchor", "end")
        .attr("font-size", "10px");


    // Draw yAxis and postion the label
    svg.append("g")
        .attr("class", "y axis")
        .call(yAxis)
        .append("text")
        .attr("transform", "rotate(-90)")
        .attr("x", -height / 1.5)
        .attr("dy", "-3em")
        .style("text-anchor", "middle")
        .text("Largest 15 Countries in Area(sq kms)");
});