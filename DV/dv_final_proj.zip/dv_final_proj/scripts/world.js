let worldsmallestcont = ["Algeria"];
let worldlargestcont = ["Russia"];
let worldtencount = [];
var PromiseWrapper = (xhr, d) => new Promise(resolve => xhr(d, (p) => resolve(p)));
Promise
    .all([
        PromiseWrapper(d3.json, "./data/world.geojson"),
        PromiseWrapper(d3.csv, "./data/countries.csv")
    ])
    .then(resolve => {
        createMap(resolve[0], resolve[1]);
    });
function createMap(countries, worldCup) {
    worldCup.forEach(data => {
        //worldsmallestcont.push(data.Country);
        //worldlargestcont.push(data.Country);
        worldtencount.push(data.Country);
    });
    console.log(worldlargestcont, worldtencount, worldsmallestcont);
    var aprojection = d3.geoMercator()
        .scale(120)
        .translate([250, 250])
        .center([20, 0]);
    var geoPath = d3.geoPath().projection(aprojection);
    d3.select("svg")
        .selectAll("path")
        .data(countries.features)
        .enter()
        .append("path")
        .attr("d", geoPath)
        .attr("class", "country")
        .style("fill", "black");
}

function setToBlack() {
    d3.select("svg")
        .selectAll("path.country")
        .style("fill", "black");
}

function smallestcont() {
    setToBlack();
    d3.select("svg")
        .selectAll("path.country")
        .filter(function(p, q) {
            console.log(p, q);
            return worldsmallestcont.indexOf(p.properties.name) > -1
        })
        .style("fill", "pink");
}

function tencount() {
    setToBlack();
    d3.select("svg")
        .selectAll("path.country")
        .filter(function(p, q) {
            console.log(p, q);
            return worldtencount.indexOf(p.properties.name) > -1
        })
        .style("fill", "yellow");
}

function largestcont() {
    setToBlack();
    d3.select("svg")
        .selectAll("path.country")
        .filter(function(p, q) {
            console.log(p, q);
            return worldlargestcont.indexOf(p.properties.name) > -1
        })
        .style("fill", "green");
}