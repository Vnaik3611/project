﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

public partial class VISITOR_admin_login : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        SqlConnection cn = new SqlConnection(@"Data Source = (LocalDB)\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\Database2.mdf;Integrated Security = True");
        SqlCommand cmd = new SqlCommand();
        cn.Open();
        cmd.Connection = cn;
        cmd.CommandText = "Select * From admin_login Where username='" + TXTUSERNAME.Text + "' and password='" + TXTPASSWORD.Text + "'";
        

        SqlDataReader dr = cmd.ExecuteReader();
        
        if (dr.Read())
        {
          
           Response.Redirect("~/admin/admin.aspx");
        }
        else
        {
            Response.Redirect("admin_login.aspx");
        }
        cn.Close();
    }
}