﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

public partial class VISITOR_FEEDBACK : System.Web.UI.Page
{
    database d = new database();
    DataSet da = new DataSet();
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void TXTCONTACT_TextChanged(object sender, EventArgs e)
    {

    }
    protected void BTNSUBMIT_Click(object sender, EventArgs e)
    {
        try
        {
            d.insertQuery("insert into feedback values ('" + TXTNAME.Text + "','" + TXTemailID.Text + "','" + TXTCONTACT.Text + "','" + tXTFEEDBACK.Text + "' )");
           
            lblmessage.Text = ("your feedback send sucessfully thanks........");
        }
        catch (Exception ex)
        {
            lblmessage.Text= ex.Message;
        }
        }
    protected void Button1_Click(object sender, EventArgs e)
    {
       

    }
}
