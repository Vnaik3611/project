﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

public partial class VISITOR_agent_login : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void BTNLOGIN_Click(object sender, EventArgs e) 
    {
        SqlConnection cn = new SqlConnection(@"Data Source = (LocalDB)\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\Database2.mdf;Integrated Security = True");
        SqlCommand cmd = new SqlCommand();
        cn.Open();
        cmd.Connection = cn;
        cmd.CommandText = "Select * From agent_password Where agent_name='" +(TXTUSERNAME.Text) + "' and agent_password='" + TXTPASSWORD.Text + "'";

        SqlDataReader dr = cmd.ExecuteReader();
        

        if (dr.Read())
        {
            Session.Add("username", TXTUSERNAME.Text); 
            Response.Redirect("~/agent/AGENT_MASTER.aspx");
        }
        else
        {
            Response.Redirect("agent_login.aspx");
        }
        cn.Close();
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        TXTPASSWORD.Text = "";
        TXTUSERNAME.Text = "";

    }
}
