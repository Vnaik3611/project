﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

public partial class VISITOR_agent_inquiry : System.Web.UI.Page
{
    database d = new database();
    DataSet da = new DataSet();
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        try
        {
            d.insertQuery("insert into AGENT_INQUIRY values ('" + TXTNAME.Text + "','" + TXTCOMPANY_NAME.Text + "','" + TXTADDRESS.Text + "','" + TXTCITY.Text + "'," + TXTZIPCODE.Text + ",'" + CMBCOUNTRY.Text + "'," + TXTMOBILE_NO.Text + ",'" + TXTEMAILID.Text + "','" + txtcomment.Text + "')");
            LBLMESSAGE.Text = ("YOUR INQUIRY SUCESSFULLY SEND.......");
        }
        catch (Exception ex)
        {
            LBLMESSAGE.Text = ex.Message;
        }
        }
    protected void Button1_Click(object sender, EventArgs e)
    {
        TXTNAME.Text = "";
        TXTCOMPANY_NAME.Text = "";
        TXTADDRESS.Text = "";
        TXTCITY.Text = "";
        TXTZIPCODE.Text = "";
        TXTMOBILE_NO.Text  = "";
        TXTEMAILID.Text = "";
        txtcomment.Text = "";
       

 
    }
    protected void CMBCOUNTRY_SelectedIndexChanged(object sender, EventArgs e)
    {
       
    }
}
