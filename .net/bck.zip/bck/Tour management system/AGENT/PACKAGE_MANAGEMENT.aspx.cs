﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

public partial class AGENT_PACKAGE_MANAGEMENT : System.Web.UI.Page
{
    database d = new database();
    DataSet da = new DataSet();
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void BTNSUBMIT_Click(object sender, EventArgs e)
    {
        d.insertQuery("insert into AGPACKAGE_MANAGEMENT values ('" + TXTAGENTNAME.Text + "'," + TXTAGENTMOBILE.Text + ",'" + txtcompanyname.Text +"','" + DRPPACKAGE_TYPE.Text + "','" + DRPCATEGORY.Text  + "','" + TXTPLACE.Text + "','"+ drpday1.SelectedValue + drpday2.SelectedValue + "'," + TXTAMOUNT.Text + ")");
        da = d.FillData("select * from AGPACKAGE_MANAGEMENT", da);
        GridView1.DataBind();

    }
    protected void BTNCLEAR_Click(object sender, EventArgs e)
    {
        TXTAGENTNAME.Text = "";
        txtcompanyname.Text = "";
        TXTAGENTMOBILE.Text = "";
        TXTPLACE.Text = "";
        TXTAMOUNT.Text = "";

    }
}
