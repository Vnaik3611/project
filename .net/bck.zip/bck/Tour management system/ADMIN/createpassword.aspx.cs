﻿using System;
using System.Text;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Net.Mail;
public partial class ADMIN_createpassword : System.Web.UI.Page
{
    database d = new database();
    DataSet da = new DataSet();
    protected void Page_Load(object sender, EventArgs e)
    {
        string s1;
        string[] s2 = new string[2];
        s1 = Request.QueryString["id"];
        s2 = s1.Split(',');
        txtid.Text = s2[0].ToString();
        txragname.Text = s2[1].ToString();


    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        int minPassSize = 6;
        int maxPassSize = 10;
        StringBuilder stringBuilder = new StringBuilder();

        char[] charArray = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789".ToCharArray();

        int newPassLength = new Random().Next(minPassSize, maxPassSize);

        char character;
        Random rnd = new Random(DateTime.Now.Millisecond);

        for (int i = 0; i < newPassLength; i++)
        {

            character = charArray[rnd.Next(0, (charArray.Length - 1))];

            stringBuilder.Append(character);
        }
        txtagpassword.Text = stringBuilder.ToString();
        btnsave.Enabled = true;


    }

    protected void btnsave_Click(object sender, EventArgs e)
    {
        try
        {

            d.insertQuery("insert into Agent_password values ('" + txtid.Text + "','" + txragname.Text + "','" + txtagpassword.Text + "')");
            da = d.FillData("select email_id from agent_inquiry where id=' " + txtid.Text + "'", da);

            string urlBase = Request.Url.GetLeftPart(UriPartial.Authority) +
                 Request.ApplicationPath;
            System.Net.Mail.SmtpClient smtpClient = new System.Net.Mail.SmtpClient("smtp.gmail.com", 587);
            smtpClient.Credentials = new System.Net.NetworkCredential("visheshnaik12@gmail.com", "Vi$hesh3097");
            System.Net.Mail.MailMessage message = new System.Net.Mail.MailMessage("visheshnaik12@gmail.com", da.Tables[0].Rows[0].ItemArray[0].ToString(), "Activation", "");
            message.IsBodyHtml = true;
            message.Body = "Welocme to  Travel Agencies <Br> We appreciate your interest in our Business.<br> Your UserName is:" + txragname.Text + "<BR> Password is:" + txtagpassword.Text;
            message.Subject = "astha travels registration";
            smtpClient.EnableSsl = false;
           // smtpClient.Send(message);

            Lblmessage.Text = "password sucessfully set on agent ";
        }
        catch (Exception ex)
        {
            Lblmessage.Text = ex.Message;

        }
          

    }
}
 
