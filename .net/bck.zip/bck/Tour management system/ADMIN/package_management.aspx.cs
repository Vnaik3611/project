﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

public partial class ADMIN_package_management : System.Web.UI.Page
{
    database d = new database();
    DataSet da = new DataSet();

    protected void Page_Load(object sender, EventArgs e)
    {

        //d.FillData("select * from package_management", da);
        //GridView1.DataSource = da.Tables[0];
        //GridView1.DataBind();
        
    }
    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    protected void BTNADD_Click(object sender, EventArgs e)
    {



    
            d.insertQuery("insert into package_management values ('" + drppackagetype.Text + "','" + drpcategory.Text + "','" + TXTPLACE.Text + "'," + drpdays.SelectedValue + drpdays2.SelectedValue + ",'" + TXTAMOUNT.Text + "')");
            da = d.FillData("select * from package_management", da);
            GridView1.DataBind();
 
       
        
    }
    protected void GridView1_SelectedIndexChanged1(object sender, EventArgs e)
    {
        
    }
    protected void btnclear_Click(object sender, EventArgs e)
    {
        
        TXTPLACE.Text = "";
        TXTAMOUNT.Text = "";
    }
}
