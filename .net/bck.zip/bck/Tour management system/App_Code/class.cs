﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;


public class database
{
    


        public static SqlCommand cmd;
        public static SqlConnection cn;
        public static string cnstr = @"Data Source = (LocalDB)\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\Database2.mdf;Integrated Security = True";
        public static void conopen()
        {
            cn = new SqlConnection(cnstr);
            if (cn.State == ConnectionState.Open)
            {
                cn.Close();
            }
            cn.Open();
        }
        public static void conclose()
        {
            cn = new SqlConnection(cnstr);
            if (cn.State == ConnectionState.Closed)
            {

            }
            cn.Close();
        }
        public void insertQuery(string s)
        {
            conopen();
            cmd = new SqlCommand();
            cmd.CommandText = s;
            cmd.Connection = cn;
            cmd.ExecuteNonQuery();
            conclose();
        }
        public void updatequery(string s)
        {
            conopen();
            cmd = new SqlCommand();
            cmd.CommandText = s;
            cmd.Connection = cn;
            cmd.ExecuteNonQuery();
            conclose();
        }
        public string UniqueId(string s)
        {
            string id;
            conopen();
            cmd = new SqlCommand();
            cmd.CommandText = s;
            cmd.Connection = cn;
            id = cmd.ExecuteScalar().ToString();
            conclose();
            if (id == "")
            {
                id = "1";
            }
            else
                id = (int.Parse(id) + 1).ToString();

            return (id);
        }
   
        public DataSet FillData(string s, DataSet ds) 
        {

            conopen();
            cmd = new SqlCommand();
            cmd.CommandText = s;
            cmd.Connection = cn;
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(ds);
            return ds;
            conclose();
        }

    }

