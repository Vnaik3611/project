﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace easy

{
    class Program
    {
        static void Main(string[] args)
        {
            string roundtrip = "";
            do
            {


                try
                {
                    Console.WriteLine("Welcome To our Multiplex");
                    Console.WriteLine("We are presently Showing :");
                    Console.WriteLine("\t 1. Rush  (15)");
                    Console.WriteLine("\t 2. How I Live Now  (15)");
                    Console.WriteLine("\t 3. Thor: The Dark World (12A)");
                    Console.WriteLine("\t 4. Filth  (18)");
                    Console.WriteLine("\t 5. Planes  (U)");
                    int film, age;
                    do
                    {
                        Console.Write("Enter the number of film numbers you wish to see:" + " ");
                        film = int.Parse(Console.ReadLine());
                        if ((film < 1) || (film > 5))
                        {
                            Console.WriteLine("Please enter the number as per above given movie films");
                        }
                    } while ((film < 1) || (film > 5));



                    do
                    {
                        Console.Write("Please enter your age:" + " ");
                        try
                        {
                            age = int.Parse(Console.ReadLine());
                            if ((age < 3) || (age > 120))
                            {
                                Console.WriteLine("Your age must be in 3 to 120");
                            }
                        }
                        catch (Exception e)
                        {
                            Console.WriteLine("Enter a valid age");
                            age = 1;
                        }
                        
                    } while ((age < 3) || (age > 120));

                    if (age < 0)
                    {
                        Console.WriteLine("Please enter a positive number value ");
                    }

                    else if (film == 1 && age >= 15)
                    {
                        Console.WriteLine("Enjoy the Movie (Rush)");
                    }
                    else if (film == 2 && age >= 15)
                    {
                        Console.WriteLine("Enjoy the Movie (How I live Now)");
                    }

                    else if (film == 3 && age >= 12)
                    {
                        Console.WriteLine("Enjoy the Movie (The Dark World)");
                    }
                    else if (film == 4 && age >= 18)
                    {
                        Console.WriteLine("Enjoy the Movie (Filth)");
                    }
                    else if (film == 5 && age >= 4)
                    {
                        Console.WriteLine("Enjoy the Movie (Planes)");
                    }
                    else
                    {
                        Console.WriteLine("Access Denied : You are too Young");

                    }


                    Console.Write("Another Customer (Y/N)" + " ");
                    roundtrip = Console.ReadLine().ToUpper();
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.Message + "Please enter a number value only");
                    Console.Write("Press Y to continue" + " ");
                    roundtrip = Console.ReadLine().ToUpper();
                }
                

            } while (roundtrip == "Y");

        }       
    }
}
