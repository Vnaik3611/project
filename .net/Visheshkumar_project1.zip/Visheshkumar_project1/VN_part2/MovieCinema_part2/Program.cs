﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace hard
{
    class Program

    {

        private static readonly int v;

        static void Main(string[] args)
        {

            String repeat, filmcountstring;
            int i, filmcount;
            string[] Movie = new string[5];
            string[] ages = new string[5] { "(12)", "(12A)", "(15)", "(18)", "(U)" };
            Console.WriteLine("How many movies are playing?");
            filmcountstring = Console.ReadLine();
            filmcount = int.Parse(filmcountstring);

            for (i = 0; i < filmcount; i++)
            {
                {
                    Console.Write("\nEnter the name of the movie with age restriction: ");
                    Movie[i] = Console.ReadLine();
                }

            }
            Console.WriteLine(".....Welcome to our Multiplex....." +
                           "\n We are Presently Showing:\n");

            for (i = 0; i < filmcount; i++)
            {
                Console.WriteLine((i + 1) + "." + Movie[i]);
            }





            do
            {
                
                    




                    try
                    {
                    Console.WriteLine("Enter the movie you want to see: ");
                    int choice = Convert.ToInt32(Console.ReadLine()) - 1;
                    int age;
                        do
                        {
                            Console.WriteLine("Enter Age:");
                            age = Convert.ToInt32(Console.ReadLine());
                        } while (age < 0 || age > 100);

                        var value = Movie[choice];
                        if (value.EndsWith("(12)"))
                        {
                            if (age < 12)
                            {
                                Console.WriteLine("You Chose: " + Movie[choice] + "\nAccess Denied - You are too young");

                            }
                            else
                            {

                                Console.WriteLine("You Chose: " + Movie[choice] + "\nEnjoy Your Movie");
                            }

                        }
                        else if (value.EndsWith("(15)"))
                        {
                            if (age < 15)
                            {
                                Console.WriteLine("Access Denied - You are too young");
                            }
                            else
                            {
                                Console.WriteLine("Enjoy Your Movie");
                            }
                        }
                        else if (value.EndsWith("(12A)"))
                        {
                            if (age < 12)
                            {
                                Console.WriteLine("Do you have an adult with you? Answer Y or N.");
                                string adultPresence = Console.ReadLine();
                                if (adultPresence == "y" || adultPresence == "Y")
                                {
                                    Console.WriteLine("Enjoy Your Movie");
                                }
                                else
                                {
                                    Console.WriteLine("Access Denied - You are too young");
                                }
                            }
                            else
                            {
                                Console.WriteLine("Enjoy Your Movie");
                            }
                        }
                        else if (value.EndsWith("(18)"))
                        {
                            if (age < 18)
                            {
                                Console.WriteLine("Access Denied - You are too young");
                            }
                            else
                            {
                                Console.WriteLine("Enjoy Your Movie");
                            }
                        }
                        else if (value.EndsWith("(U)"))
                        {
                            if (age < 4)
                            {
                                Console.WriteLine("Access Denied - You are too young");
                            }
                            else
                            {
                                Console.WriteLine("Enjoy Your Movie");
                            }
                        }
                        else
                        {
                            Console.WriteLine("Enter a valid movie rating any of ( (12) or (12A) or (15) or  (18) or (U)) at the end  ");
                        }

                    }



                    catch (Exception e)
                    {
                    //Console.WriteLine("enter a whole number!");
                    Console.WriteLine(e.Message);
                    }
                    Console.WriteLine("another customer? ['y' or 'n']");
                    repeat = Console.ReadLine();
                
               
            
            }while (repeat == "y");
        }
    }
}



       

 
